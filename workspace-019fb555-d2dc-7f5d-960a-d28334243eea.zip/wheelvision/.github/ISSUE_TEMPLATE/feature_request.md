---
name: Feature Request
about: Suggest an idea for WheelVision
description: Propose new features or improvements
labels: ["enhancement", "platform"]
assignees: ''
---

## Description
A clear and concise description of the feature.

## Problem / Motivation
What problem does this solve? Why is it needed?

## Proposed Solution
Describe the solution you'd like.

## Alternatives Considered
Describe alternatives you've considered.

## Related Requirements
- FR-ID: [e.g. FR-001]
- Chapter Reference: [e.g. Chapter 2]
- Architecture Impact: [e.g. None / Minor / Major — note: architecture freeze requires CTO approval for structural changes]
