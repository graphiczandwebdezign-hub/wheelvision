---
name: Bug Report
about: Create a report to help us improve WheelVision
description: Report unexpected behavior, errors, or defects
labels: ["bug", "platform"]
assignees: ''
---

## Description
A clear and concise description of the bug.

## Environment
- OS: [e.g. macOS 14, Windows 11]
- Browser: [e.g. Chrome 120, Safari 17]
- Device: [e.g. MacBook Pro, iPad Pro 12.9"]
- Version: [e.g. v1.0.0]

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See error

## Expected Behavior
A clear description of what should happen.

## Actual Behavior
A clear description of what actually happens.

## Screenshots / Logs
If applicable, add screenshots or logs to help explain.

## Additional Context
Add any other context about the problem here.

## Related Requirements
- FR-ID: [e.g. FR-VE-001]
- Chapter Reference: [e.g. Chapter 7]
