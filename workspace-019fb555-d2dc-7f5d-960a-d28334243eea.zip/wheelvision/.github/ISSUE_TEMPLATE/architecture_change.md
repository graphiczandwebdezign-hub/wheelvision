---
name: Architecture Change
about: Propose structural architecture changes (requires CTO approval)
description: Request changes to frozen architecture
labels: ["architecture", "platform"]
assignees: ''
---

## Context
Why is this change needed? Reference architecture freeze notice.

## Proposed Change
Describe the structural change (database, renderer, multi-tenant, technology stack).

## Impact Assessment
- Affected chapters/modules
- Migration requirements
- Backward compatibility impact
- Performance impact
- Security impact

## Alternatives Considered
List alternatives.

## Engineering Rationale
Justify the change against architecture principles.

## Approval
Requires CTO approval before implementation. Architecture Freeze v1.0 applies.
