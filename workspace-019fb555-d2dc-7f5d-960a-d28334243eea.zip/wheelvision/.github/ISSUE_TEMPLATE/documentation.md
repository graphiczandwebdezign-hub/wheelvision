---
name: Documentation
about: Documentation updates or corrections
description: Update specification, README, or guides
labels: ["documentation", "platform"]
assignees: ''
---

## Type
- [ ] Specification update
- [ ] API documentation
- [ ] User guide
- [ ] Developer guide
- [ ] Other

## Section Updated
Specify chapter/file updated.

## Change Description
Brief description of documentation change.
