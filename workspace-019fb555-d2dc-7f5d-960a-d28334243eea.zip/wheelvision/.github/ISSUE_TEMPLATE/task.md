---
name: Task
about: Development or operational task
description: Track implementation work
labels: ["task", "platform"]
assignees: ''
---

## Description
Clear description of the task.

## Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

## Related Requirements
- FR-ID: [e.g. FR-001]
- Chapter Reference: [e.g. Chapter 3]

## Implementation Notes
Any architectural or engineering notes.
