# Security Policy

## Supported Versions

Only the latest release (`main` branch, production deployment) receives security updates.

## Reporting a Vulnerability

We take security seriously. If you discover a security vulnerability, please report it responsibly:

1. **Do not disclose publicly** (no public issues, no pull requests, no social media).
2. **Email:** security@wheelvision.com (monitored by the Security Lead and CTO).
3. **Response time:** We acknowledge receipt within 24 hours. Critical vulnerabilities receive initial assessment within 72 hours.
4. **Disclosure timeline:** After verification and patch deployment, we publish a security advisory with credit to the reporter (if desired) and provide a 30-day disclosure window for non-critical issues.

## Security Measures

- All tables use PostgreSQL Row-Level Security (RLS) for multi-tenant isolation.
- Authentication via Supabase Auth (JWT, secure cookies, refresh rotation).
- HTTPS enforced everywhere (TLS 1.3 minimum).
- File uploads validated (magic bytes, virus scanning, size limits).
- Rate limiting applied to all API endpoints.
- Security tests (`pgTap`) executed in CI pipeline.
- Dependency scanning and container image scanning performed regularly.
- Secrets managed through environment variables and secure vaults (never committed to repository).

---

*This policy aligns with the Security Architecture specified in Chapter 20.*
