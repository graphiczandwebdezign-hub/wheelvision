## Description
Brief description of changes.

## Related Issue(s)
Fixes # (issue number) or references architecture documentation.

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Architecture change (requires CTO approval — freeze v1.0 applies)
- [ ] Performance improvement
- [ ] Refactoring

## Testing
- [ ] Unit tests added/updated
- [ ] Integration tests pass
- [ ] E2E tests pass (if applicable)
- [ ] Visual regression tests pass (if rendering affected)
- [ ] Performance budget verified (if rendering/API affected)
- [ ] Security review completed (if database/auth/security affected)

## Implementation Notes
Any engineering decisions, trade-offs, or architectural compliance notes.

## Architecture Compliance
- [ ] Changes comply with architecture freeze (v1.0) — no structural changes without CTO approval
- [ ] Metadata-driven rendering preserved (if renderer affected)
- [ ] Multi-tenant isolation preserved (if database/auth affected)
- [ ] RLS policies intact (if database affected)

## Screenshots / Evidence
If UI/UX or rendering affected, include screenshots or test results.

## Checklist
- [ ] Code follows coding standards (TypeScript strict, ESLint, Prettier)
- [ ] Documentation updated (if applicable)
- [ ] CHANGELOG updated (if applicable)
- [ ] Branch created from `develop`
- [ ] Commit messages use Conventional Commits format
