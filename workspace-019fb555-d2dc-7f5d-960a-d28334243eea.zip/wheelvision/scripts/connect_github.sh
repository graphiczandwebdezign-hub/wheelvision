#!/bin/bash
# WheelVision — GitHub Connection Script
# Run this after configuring your GitHub authentication (SSH or PAT)

set -euo pipefail

GITHUB_USER="${GITHUB_USER:-wheelvision}"
REPO_NAME="${REPO_NAME:-wheelvision}"
REMOTE_URL="https://github.com/${GITHUB_USER}/${REPO_NAME}.git"

echo "=== WheelVision GitHub Connection ==="
echo "Remote URL: ${REMOTE_URL}"
echo "Branch: master -> main"
echo ""

# Check if remote already exists
if git remote get-url origin 2>/dev/null; then
    echo "Remote 'origin' already configured: $(git remote get-url origin)"
    echo "Update with: git remote set-url origin ${REMOTE_URL}"
else
    echo "Adding remote 'origin'..."
    git remote add origin "${REMOTE_URL}"
fi

# Rename master to main (standard workflow)
BRANCH=$(git branch --show-current)
if [ "${BRANCH}" = "master" ]; then
    echo "Renaming branch: master -> main"
    git branch -M main
fi

echo ""
echo "Ready to push. Execute:"
echo "  git push -u origin main"
echo "  git checkout -b develop"
echo "  git push -u origin develop"
echo ""
echo "Note: Requires GitHub authentication (SSH agent or personal access token in environment)."
echo "This script does NOT store credentials — it only configures the remote reference."
