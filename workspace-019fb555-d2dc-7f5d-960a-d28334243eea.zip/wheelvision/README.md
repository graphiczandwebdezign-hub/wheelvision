wheelvision/
├── .github/
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md
│   │   ├── feature_request.md
│   │   ├── task.md
│   │   ├── documentation.md
│   │   └── architecture_change.md
│   ├── workflows/
│   │   ├── ci.yml
│   │   ├── test.yml
│   │   ├── security.yml
│   │   └── deploy.yml
│   ├── PULL_REQUEST_TEMPLATE.md
│   ├── CODEOWNERS
│   ├── SECURITY.md
│   └── dependabot.yml
├── apps/
│   └── web/
│       ├── app/
│       │   ├── layout.tsx
│       │   ├── page.tsx
│       │   └── (routes)
│       ├── components/
│       │   ├── ui/
│       │   └── shared/
│       ├── lib/
│       │   ├── supabase/
│       │   └── utils/
│       ├── hooks/
│       ├── styles/
│       │   └── globals.css
│       ├── public/
│       │   ├── assets/
│       │   │   ├── vehicles/
│       │   │   ├── wheels/
│       │   │   └── logos/
│       │   └── images/
│       ├── .env.example
│       ├── .env.local
│       ├── next.config.js
│       ├── package.json
│       └── tailwind.config.ts
├── packages/
│   ├── renderer/
│   │   ├── src/
│   │   ├── package.json
│   │   └── tsconfig.json
│   ├── ui/
│   │   ├── src/
│   │   ├── package.json
│   │   └── tsconfig.json
│   ├── api/
│   │   ├── src/
│   │   ├── package.json
│   │   └── tsconfig.json
│   ├── shared/
│   │   ├── src/
│   │   │   ├── types/
│   │   │   ├── constants/
│   │   │   └── utils/
│   │   ├── package.json
│   │   └── tsconfig.json
│   ├── types/
│   │   ├── src/
│   │   ├── package.json
│   │   └── index.ts
│   └── config/
│       ├── src/
│       │   ├── tailwind/
│       │   ├── typescript/
│       │   └── eslint/
│       ├── package.json
│       └── index.ts
├── supabase/
│   ├── migrations/
│   │   └── 202607300001_complete_schema.sql
│   ├── seed/
│   └── config.toml
├── docs/
│   ├── architecture/
│   │   ├── chapter_01_executive_summary.md
│   │   ├── chapter_02_requirements_spec.md
│   │   └── ... (26 chapters + expansions + appendices)
│   ├── ai_pipeline/
│   │   ├── chapters/
│   │   └── appendices/
│   ├── ecosystem/
│   ├── expansions/
│   ├── runbooks/
│   └── readme.md
├── scripts/
│   ├── setup.sh
│   ├── seed-data.sh
│   ├── build-check.sh
│   └── deploy-check.sh
├── tests/
│   ├── unit/
│   ├── integration/
│   ├── e2e/
│   ├── renderer/
│   ├── security/
│   ├── performance/
│   └── visual/
├── .editorconfig
├── .gitignore
├── .gitattributes
├── README.md
├── LICENSE
├── CHANGELOG.md
├── CONTRIBUTING.md
└── CODE_OF_CONDUCT.md
