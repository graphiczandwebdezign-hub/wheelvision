# Contributing to WheelVision

Thank you for your interest in contributing to WheelVision.

This document provides guidelines and instructions for contributing to this enterprise multi-tenant SaaS project.

## Development Workflow

1. **Fork and Clone:** Fork the repository and clone to your local environment.
2. **Branch:** Create a feature branch from `develop` (not `main`).
   - Feature: `feature/<description>`
   - Bugfix: `bugfix/<description>`
   - Documentation: `docs/<description>`
3. **Develop:** Follow coding standards (TypeScript strict, ESLint, Prettier, Tailwind CSS conventions).
4. **Test:** Write tests for all new code. All tests must pass before PR submission.
5. **Commit:** Use Conventional Commits format.
6. **Pull Request:** Submit PR against `develop`. Fill out PR template completely.
7. **Review:** Address reviewer feedback promptly. PR requires at least one approval.
8. **Merge:** After approval and passing CI checks, maintainer merges.

## Branch Strategy

- `main`: Production releases only. Protected. Requires PR + approval + status checks.
- `develop`: Integration branch. All feature branches merge here. Protected.
- `feature/*`: Individual features.
- `release/*`: Release candidates for testing.
- `hotfix/*`: Critical production fixes.
- `bugfix/*`: Non-critical bug fixes.
- `docs/*`: Documentation updates.

## Commit Convention

We follow [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/):

```
feat(renderer): add shadow layer animation support
fix(api): resolve pagination offset error
docs(architecture): update rendering mathematics
refactor(shared): simplify coordinate transformation
test(renderer): add performance budget enforcement
ci(github): configure preview deployment workflow
build(platform): update dependency versions
```

## Coding Standards

- TypeScript with `strict: true` enabled.
- ESLint + Prettier configured via `packages/config/`.
- Component files use `.tsx` extension.
- Utility files use `.ts` extension.
- No `any` types without explicit justification.
- All functions require JSDoc comments describing purpose, parameters, return values.
- All components require TypeScript prop interfaces.
- All forms use React Hook Form + Zod validation.
- All async data fetching uses TanStack Query (`useQuery` / `useMutation`).

## Pull Request Requirements

Before submitting:
- [ ] All automated tests pass (`npm test`, `npm run lint`, `npm run type-check`).
- [ ] New code includes appropriate tests (unit, integration, or visual regression as applicable).
- [ ] Documentation updated if features changed.
- [ ] No console errors or warnings.
- [ ] Performance budgets respected (rendering updates < 500ms p95).
- [ ] Security review completed if new endpoints or database changes involved.
- [ ] Architecture review completed if structural changes proposed (note: Architecture Freeze v1.0 — structural changes require CTO approval).

## Issue Reporting

Use GitHub Issue Templates. Include reproduction steps, environment details, expected behavior, actual behavior, and relevant logs or screenshots.

## Code Review Process

- All PRs require at least one approval from a CODEOWNERS member.
- Critical sections (`renderer/`, `database/`, `security/`, `ai-pipeline/`) require specialized reviewer approval.
- Reviewers evaluate: correctness, performance, security, architecture compliance, documentation quality, test coverage.
- Review feedback must be addressed before merge.

## Architecture Freeze Notice

As of v1.0, the core architecture is frozen. Any proposed structural changes (database schema, rendering pipeline, multi-tenant model, technology stack) must be submitted as an Architecture Change Request using the `architecture_change.md` issue template and approved by the CTO before implementation.

## Getting Help

For questions, open a discussion issue or contact the Engineering Team through the repository.
