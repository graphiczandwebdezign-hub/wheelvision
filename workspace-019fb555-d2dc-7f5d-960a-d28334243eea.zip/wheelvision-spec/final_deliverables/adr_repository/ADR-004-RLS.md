# ADR-004 — WHY POSTGRESQL ROW-LEVEL SECURITY?

## Status

ACCEPTED — 30 July 2026

---

## Context

Multi-tenant isolation must be enforced mathematically at the database layer. The system must prevent any possibility of cross-tenant data access, even in the presence of application bugs, injection attempts, or middleware failures.

---

## Decision

Enable PostgreSQL Row-Level Security (RLS) on all tenant-related tables, with policies enforcing `tenant_id = current_setting('app.current_tenant_id')`.

---

## Alternatives Considered

- **Application-Level Filtering Only:** Filter queries in code (`WHERE tenant_id = ?`). Trade-off: Vulnerable to injection; requires every query to include filter manually; no defense-in-depth.
- **Schema-Per-Tenant:** Separate PostgreSQL schema per tenant. Trade-off: Strong isolation but complex migrations (must apply to all schemas); operational overhead; difficult cross-tenant analytics.
- **Dedicated Database Per Tenant:** Maximum isolation. Trade-off: Prohibitively expensive; complex connection management; impossible at scale for thousands of dealers.
- **Row-Level Security + Middleware (Selected):** RLS enforced at database; middleware sets session variable; application filters provide secondary defense.

---

## Trade-offs

- **Positive:** Mathematical isolation guarantee; single schema; simple migrations; automatic filtering (no manual `WHERE` clauses required); defense-in-depth.
- **Negative:** Slight query overhead (RLS applies implicit filters); requires careful middleware implementation; debugging RLS errors can be complex.

---

## Consequences

- Every table with `tenant_id` has RLS enabled (`ALTER TABLE ... ENABLE ROW LEVEL SECURITY`).
- Every table has `CREATE POLICY` statements for SELECT, INSERT, UPDATE, DELETE.
- Middleware must set `app.current_tenant_id` before every database request.
- Security tests (`pgTap`) verify RLS policies automatically in CI/CD.
- Service role bypasses RLS for administrative operations only.

---

*ADR-004 complete. PostgreSQL RLS selected as isolation mechanism.*
