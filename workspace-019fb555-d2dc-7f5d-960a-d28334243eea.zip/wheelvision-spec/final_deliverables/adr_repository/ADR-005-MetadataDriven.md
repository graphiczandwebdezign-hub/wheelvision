# ADR-005 — WHY METADATA-DRIVEN RENDERING?

## Status

ACCEPTED — 30 July 2026

---

## Context

The platform must support thousands of vehicle profiles without requiring code changes for each new vehicle. The renderer must be universal — given any valid vehicle asset package (images + JSON metadata), it must produce accurate visual output.

---

## Decision

Adopt a fully metadata-driven rendering architecture. The renderer interprets structured JSON metadata (coordinates, diameters, masks, perspective) and applies universal transformation, masking, and compositing logic. No hardcoded vehicle logic exists in renderer code.

---

## Alternatives Considered

- **Hardcoded Per-Vehicle Logic:** Each vehicle requires custom rendering code. Trade-off: Precise control but combinatorial maintenance cost; requires developer intervention for every new vehicle.
- **Template-Based Rendering:** Predefined templates for vehicle categories. Trade-off: Reduces code but still requires new templates for unique vehicles; inflexible.
- **Fully Data-Driven (Selected):** Metadata JSON defines all parameters. Trade-off: Requires rigorous metadata validation and comprehensive schema design; eliminates all per-vehicle code.

---

## Trade-offs

- **Positive:** Zero development cost for new vehicles; universal renderer; automated asset pipeline integration; future 3D migration protected by abstract scene graph.
- **Negative:** Metadata schema must be comprehensive and extensible; metadata errors directly affect visual output; requires robust validation pipeline.

---

## Consequences

- Every new vehicle requires only asset upload and `metadata.json` creation.
- Metadata schema version-controlled; backward compatibility enforced.
- Validation pipeline (JSON Schema, coordinate range checks, URL accessibility) mandatory for all metadata.
- Renderer code contains zero conditional branches based on manufacturer, model, or year.

---

*ADR-005 complete. Metadata-driven rendering selected.*
