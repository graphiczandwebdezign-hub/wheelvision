# ADR-002 — WHY REACT KONVA OVER PIXIJS?

## Status

ACCEPTED — 30 July 2026

---

## Context

The WheelVision renderer requires a 2D canvas engine capable of layered scene graphs, declarative React integration, event handling, and high-performance updates for commercial visualisation. The engine must support masking, transformation pipelines, and future 3D migration compatibility.

---

## Decision

Adopt React Konva as the primary rendering engine.

---

## Alternatives Considered

- **PixiJS:** Excellent performance; lower-level; requires custom React wrapper; less declarative layer management.
- **Fabric.js:** Canvas library with interactive objects; less performant for high-frequency updates; smaller ecosystem.
- **HTML Canvas + Custom:** Maximum control but requires rebuilding layer management, masking, and event systems from scratch.
- **SVG:** DOM-based; simpler but poor performance with complex scenes; cannot achieve pixel-level control required for commercial rendering.

---

## Trade-offs

- **Positive:** Declarative React bindings (`<Layer>`, `<Image>`, `<Shape>`); excellent masking support; caching capabilities; sufficient performance for scene complexity (few layers, static updates); active maintenance.
- **Negative:** Slightly lower raw performance than PixiJS; larger bundle size; event system less optimized for gaming-level interaction (acceptable for dealer tool).

---

## Consequences

- Renderer uses Konva's layer-based architecture (Vehicle, Wheel, Shadow, Overlay layers).
- All transformations applied through Konva's transform pipeline (scale, rotation, translation).
- Performance budget enforced (500ms per update cycle) to account for Konva overhead.
- Future 3D migration must maintain scene graph abstraction independently of Konva.

---

*ADR-002 complete. React Konva selected with full justification.*
