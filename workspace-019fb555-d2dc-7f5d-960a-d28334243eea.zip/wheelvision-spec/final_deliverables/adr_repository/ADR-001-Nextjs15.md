# ADR-001 — WHY NEXT.JS 15?

## Status

ACCEPTED — 30 July 2026

---

## Context

The WheelVision platform requires a modern web framework supporting server-side rendering, App Router conventions, edge deployment, TypeScript strict mode, and seamless integration with React 19 concurrent features. The framework must support preview deployments, automatic image optimization, and server actions.

---

## Decision

Adopt Next.js 15 (App Router) as the primary application framework.

---

## Alternatives Considered

- **Nuxt 3 (Vue):** Excellent Vue ecosystem but team expertise centered in React; React Konva integration required.
- **Remix:** Strong server rendering but lacks built-in image optimization and App Router-style nested layouts.
- **Express + React SPA:** Manual SSR implementation increases maintenance burden; loses performance benefits.
- **SvelteKit:** Excellent performance but smaller ecosystem; React Konva requires React specifically.

---

## Trade-offs

- **Positive:** App Router provides server components reducing bundle size; built-in image optimization; Vercel integration; TypeScript-first.
- **Negative:** App Router is newer (potential instability); some features still evolving; learning curve for team members unfamiliar with server components.

---

## Consequences

- All pages use App Router (`app/` directory) with server components where possible.
- Client-side rendering restricted to Konva canvas components (necessary limitation).
- Deployment targets Vercel exclusively (leveraging framework optimization).
- TypeScript strict mode enforced globally.

---

*ADR-001 complete. Next.js 15 selected with full rationale documented.*
