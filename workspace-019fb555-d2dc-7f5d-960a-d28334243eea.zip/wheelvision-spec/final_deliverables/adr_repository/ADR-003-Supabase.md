# ADR-003 — WHY SUPABASE?

## Status

ACCEPTED — 30 July 2026

---

## Context

The platform requires a backend database with built-in authentication, real-time capabilities, storage integration, and PostgreSQL compatibility. The solution must support multi-tenant isolation (RLS), provide hosted infrastructure (reducing DevOps overhead), and offer TypeScript-compatible clients.

---

## Decision

Adopt Supabase (hosted PostgreSQL with Auth, Storage, and RLS) as the primary data and authentication layer.

---

## Alternatives Considered

- **Self-hosted PostgreSQL + Custom Auth:** Maximum control but high operational overhead; requires separate identity provider (Keycloak/Auth0 integration); manual RLS implementation.
- **Firebase (Firestore):** Excellent real-time but NoSQL schema limits complex queries; RLS more complex; vendor lock-in.
- **AWS RDS + Cognito:** Enterprise-grade but requires significant infrastructure management; RLS requires custom middleware; no built-in storage integration.
- **Planetscale (MySQL):** Excellent scaling but lacks RLS and built-in auth; requires significant custom development.

---

## Trade-offs

- **Positive:** Built-in PostgreSQL RLS; integrated auth (JWT); TypeScript client; hosted infrastructure; storage integration; real-time subscriptions available (future); lower operational overhead.
- **Negative:** Vendor dependency; pricing scales with usage; customization limits (some PostgreSQL extensions restricted); performance dependent on Supabase infrastructure decisions.

---

## Consequences

- All database queries use Supabase client with RLS enforcement.
- Authentication handled through Supabase Auth (email/password + OAuth).
- Storage initially through Supabase (staging); production assets on Cloudflare R2 (S3-compatible) for cost efficiency.
- Migration strategy uses Supabase CLI (`supabase migrate`).
- Backup and point-in-time recovery handled by Supabase (verified in disaster recovery planning).

---

*ADR-003 complete. Supabase selected with full justification.*
