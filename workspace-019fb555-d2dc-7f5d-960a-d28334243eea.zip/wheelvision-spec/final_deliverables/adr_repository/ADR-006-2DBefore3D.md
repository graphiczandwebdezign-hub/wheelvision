# ADR-006 — WHY 2D BEFORE 3D?

## Status

ACCEPTED — 30 July 2026

---

## Context

The platform's commercial objective requires immediate value delivery (quotation generation, dealer branding, inventory management). A full 3D renderer would significantly delay initial deployment and increase complexity. The architecture must support future 3D migration without structural redesign.

---

## Decision

Implement 2D canvas-based rendering (React Konva) as the initial production renderer. Design metadata schema and scene graph abstraction to be technology-independent, enabling future migration to 3D (WebGL/Three.js) without structural changes.

---

## Alternatives Considered

- **Full 3D from Day One:** Three.js or custom WebGL renderer. Trade-off: Longer development timeline (6+ months additional); higher GPU requirements; more complex asset pipeline (3D models, textures, lighting); unnecessary for quotation-quality 2D previews.
- **Hybrid (2D + 3D Toggle):** Both renderers maintained simultaneously. Trade-off: Double maintenance burden; no commercial need for 3D toggle in initial release.
- **2D First (Selected):** Immediate commercial value; simpler asset pipeline (2D images + masks); lower GPU requirements; clear migration path to 3D through abstract scene graph.

---

## Trade-offs

- **Positive:** Faster time-to-market; lower infrastructure cost; simpler asset creation; proven commercial viability (dealers need accurate previews, not 3D showrooms initially).
- **Negative:** Future 3D migration requires new renderer implementation (though scene graph abstraction minimizes redesign); some visual effects (true perspective rotation, environment lighting) limited in 2D.

---

## Consequences

- Initial release uses Konva 2D renderer.
- Metadata schema includes extensible fields (`rotation_axis`, `lighting_angle`) for future 3D parameters (optional, default null).
- Scene graph abstraction (layers, transformations, masks) maintained independently of rendering technology.
- 3D renderer migration planned for future roadmap (Chapter 26) with no core architecture changes required.

---

*ADR-006 complete. 2D-first approach selected with 3D migration path preserved.*
