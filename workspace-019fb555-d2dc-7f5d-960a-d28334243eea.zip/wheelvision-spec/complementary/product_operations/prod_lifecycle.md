# PRODUCT OPERATIONS MANUAL — ASSET LIFECYCLE & FEATURE FLAGS

## Section: LIF-001 — Asset Lifecycle Management

Every asset (vehicle image, wheel PNG, mask, metadata) follows lifecycle stages:

| Stage | Status | Duration | Action Required |
|---|---|---|---|
| Draft | `draft` | Variable | Complete metadata; upload assets |
| Review | `pending_review` | < 5 business days | Human review; approve/reject/correct |
| Published | `published` | Permanent (until rollback) | Available in renderer |
| Archived | `archived` | 7 years | Audit storage; not in production |
| Deleted | `deleted` | Permanent (audit retained) | Only on admin action; audit log preserved |

---

## Section: FLG-001 — Feature Flag Operations

Feature flags managed through database (`feature_flags` JSON per tenant) and middleware evaluation:

- **Activation:** Flags set via Admin interface; validated against schema; propagated to middleware within 30 seconds (cached refresh interval).
- **Monitoring:** Every feature flag evaluation logged (feature name, tenant, user, timestamp, result: enabled/disabled).
- **Rollback:** If feature causes errors, flag disabled immediately; previous behavior restored without deployment.
- **Audit:** All flag changes logged (`feature_flag_changes` table) with admin ID, timestamp, previous/new value, justification.

---

*Product Operations Manual — Asset lifecycle and feature flag operations fully specified.*
