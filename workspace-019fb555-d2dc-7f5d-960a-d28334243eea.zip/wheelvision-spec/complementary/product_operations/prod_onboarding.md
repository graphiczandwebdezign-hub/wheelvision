# PRODUCT OPERATIONS MANUAL — DEALER ONBOARDING

## Section: ONB-001 — Dealer Registration Workflow

### Registration Steps

1. **Application:** Dealer completes online registration form (company name, location, contact, website, expected volume).
2. **Verification:** Operations team verifies business registration (ABN/company number), physical address, and contact details. Verification target: < 24 hours.
3. **Account Creation:** Upon verification, tenant created in database (`tenants` table); primary owner assigned (`primary_owner_id`); subscription tier set based on selected plan.
4. **Branding Setup:** Dealer uploads logo, selects colour palette, configures company details. Branding JSON validated against schema.
5. **Initial Training:** Dealer receives access to documentation, video tutorials, and scheduled onboarding call (target: within 3 business days of account creation).
6. **First Asset Upload:** Dealer guided through first vehicle upload process; AI pipeline processes initial assets; results reviewed together during onboarding call.
7. **Go-Live Approval:** After dealer confirms satisfaction with initial assets, account status set to `active`; dealer can begin generating quotations for customers.

---

## Section: ONB-002 — Onboarding Quality Gates

Every onboarding must pass:
- Business verification completed (documented in `tenant_verification_log`).
- Branding JSON passes schema validation.
- Initial asset upload produces at least one approved asset (demonstrates pipeline functionality).
- Dealer completes onboarding tutorial (tracked in `user_training_log`).
- First quotation generated successfully (tracked in `quotes` table with `onboarding` tag).

---

## Section: ONB-003 — Onboarding Metrics

| Metric | Target | Measurement |
|---|---|---|
| Verification Time | < 24 hours | Time from application to verification complete |
| First Asset Approval | < 5 business days | Time from account creation to first approved asset |
| Onboarding Completion | > 95% | Percentage of registered dealers reaching go-live |
| Dealer Satisfaction (Post-Onboarding) | > 4.5/5 | Survey completed within 7 days of go-live |

---

*Product Operations Manual — Dealer onboarding fully specified with verification, quality gates, and metrics.*
