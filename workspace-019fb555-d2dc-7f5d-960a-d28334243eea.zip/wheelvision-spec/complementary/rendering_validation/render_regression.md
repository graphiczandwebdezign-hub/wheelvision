# RENDERING VALIDATION — GOLDEN REFERENCE & VISUAL REGRESSION

## Section: GOLD-001 — Golden Reference Images

Every approved vehicle/wheel/finish combination requires an approved golden reference image (PNG, 300 DPI, full resolution). Golden references stored in `/tests/baselines/{vehicle_id}/` with version tracking (`v1`, `v2` for updated assets).

Golden images must include:
- Full preview render (vehicle + selected wheel + shadow + overlay).
- Metadata JSON used (linked by hash reference).
- Approval timestamp and reviewer ID.
- Environment details (browser version, screen resolution, OS).

---

## Section: VIS-001 — Visual Regression Protocol

Every production build executes visual regression tests:
1. Load all golden reference configurations.
2. Generate current output for each.
3. Compute pixel difference (threshold: <= 1%).
4. Compute SSIM (threshold: >= 0.95).
5. Any deviation > 1% triggers manual review.
6. Any SSIM < 0.95 triggers automatic failure.
7. Results stored in regression database (`visual_regression_results`).

---

*Rendering Validation Manual — Golden references and regression protocols fully specified.*
