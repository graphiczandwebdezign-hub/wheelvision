# RENDERING VALIDATION — PIXEL TOLERANCE & GEOMETRIC ACCURACY

## Section: PIX-001 — Pixel Tolerance Specification

### Tolerance Definition

Every pixel in the rendered output is measured against the mathematically predicted position derived from metadata (Chapter 12: Rendering Mathematics). Tolerance is defined as the maximum acceptable deviation between predicted pixel position and actual rendered pixel position.

### Tolerance Levels

| Tolerance Level | Max Deviation (pixels) | Application | Action if Exceeded |
|---|---|---|---|
| Critical | ±2 px | Wheel centre coordinates | Reject; review metadata |
| High | ±5 px | Wheel diameter measurement | Flag for correction |
| Standard | ±10 px | Shadow position, overlay text | Accept with warning |
| Low | ±20 px | Background elements | Accept; log deviation |

---

## Section: ALIGN-001 — Alignment Validation Protocol

### Validation Procedure

1. Load approved metadata JSON (version-controlled, audited).
2. Generate reference image using reference renderer (same version as production).
3. Capture production rendered output (same configuration).
4. Compute structural similarity index (SSIM) between reference and production.
5. Measure geometric alignment: extract wheel centres from both images; compute Euclidean distance.
6. Compare distances against tolerance table.
7. Generate validation report: PASS / FAIL / REVIEW with deviation measurements.

---

## Section: WHEEL-001 — Wheel Placement Verification

### Verification Criteria

For each visible wheel (front/rear):
- Centre coordinates must match metadata `x`, `y` within Critical tolerance (±2 px).
- Diameter must match calculated diameter (`2 * radius`) within High tolerance (±5 px).
- Rotation must match metadata `rotation_angle_degrees` within ±1°.
- Circular mask must have IoU >= 0.92 with perfect circle of specified radius.

---

*Rendering Validation Manual — Pixel tolerance, geometric accuracy, and wheel verification protocols fully specified.*
