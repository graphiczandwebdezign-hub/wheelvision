# RENDERING VALIDATION MANUAL — MASTER INDEX

**Volume:** 4 of 5 (Complementary Engineering Volumes)
**Status:** ARCHITECTURE FREEZE v1.0 — VERIFICATION PHASE
**Specification Code:** WV-REND-VAL-2026-001

---

## MANUAL PURPOSE

This manual defines the complete validation protocol for rendered output from the WheelVision rendering engine. It ensures that every visual output is accurate to millimetre-level scale, geometrically consistent with selected parameters, and commercially acceptable for quotation purposes.

---

## VALIDATION CATEGORIES

| Category | Chapter | Focus | Method |
|---|---|---|---|
| Pixel Tolerance | PIX-001 – PIX-060 | Pixel-level accuracy measurement | Automated pixel comparison (
| Alignment Validation | ALIGN-001 – ALIGN-080 | Wheel position, rotation, perspective | Geometric verification scripts |
| Wheel Placement Verification | WHEEL-001 – WHEEL-100 | Coordinate accuracy, diameter accuracy | Mathematical comparison with metadata |
| Metadata Accuracy Thresholds | META-001 – META-080 | JSON schema compliance, value ranges | Schema validation + statistical analysis |
| Export Quality Checks | EXPORT-001 – EXPORT-080 | PDF, print, image export quality | Visual inspection + automated metrics |
| Golden Reference Images | GOLD-001 – GOLD-060 | Baseline comparison, version tracking | Image difference analysis |
| Visual Regression Baselines | VIS-001 – VIS-080 | Pixel difference thresholds, SSIM | Automated regression pipeline |

---

*Volume 4 Master Index complete. Rendering validation fully organized with geometric, pixel-level, and export validation protocols.*
