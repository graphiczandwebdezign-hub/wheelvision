# UX & INTERACTION SPECIFICATION — EMPTY, ERROR, LOADING STATES

## Section: EMPTY-001 — Empty State Patterns

Every module defines empty states for zero-data conditions:

| Module | Empty Condition | Visual | Message | Action |
|---|---|---|---|---|
| Vehicle List | No vehicles uploaded | Illustration + text | "No vehicles available. Upload your first vehicle in Admin." | CTA to Admin Upload |
| Quotes | No saved quotes | Illustration + text | "Save your first configuration to generate a quote." | CTA to Preview |
| Inventory | No inventory tracked | Illustration + text | "Add inventory in Admin settings." | CTA to Admin |

---

## Section: ERR-001 — Error State Patterns

Every error includes:
- Error code (e.g., `RENDER_003`, `AUTH_002`).
- Human-readable message (not technical stack trace to user; detailed log to system).
- Suggested action (retry, contact support, check input).
- Visual indicator (red outline, icon, text).
- Accessibility: `aria-live="assertive"` announces error to screen readers; focus moved to error message.

---

## Section: LOAD-001 — Loading State Patterns

Every asynchronous action shows loading state:
- Button: Spinner replaces text; disabled; `aria-busy="true"`.
- Page: Skeleton screens for lists; progress bar for uploads; spinner for single actions.
- Canvas: Loading overlay with message; prevents interaction until complete.
- Timeout: After 10 seconds, loading state replaced with timeout message + retry option.
