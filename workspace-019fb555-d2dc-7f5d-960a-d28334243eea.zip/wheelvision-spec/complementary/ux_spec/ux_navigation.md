# UX & INTERACTION SPECIFICATION — NAVIGATION ARCHITECTURE

## Section: NAV-001 — Global Navigation

### Navigation Structure

The platform uses a persistent top navigation bar (desktop) and bottom navigation (mobile) with the following hierarchy:

| Level | Label | Route | Access Level |
|---|---|---|---|
| Primary | Vehicle Selector | `/vehicles` | All users |
| Primary | Wheel Selector | `/wheels` | All users |
| Primary | Preview | `/preview` | All users |
| Primary | Quotes | `/quotes` | All users |
| Primary | Inventory | `/inventory` | Admin/Dealer |
| Primary | Admin | `/admin` | Admin only |
| Secondary | Branding Settings | `/admin/branding` | Dealer Owner |
| Secondary | User Management | `/admin/users` | Dealer Owner |

---

### Navigation Behavior

- **Desktop:** Persistent top bar; dropdown menus for secondary navigation; hover states reveal submenus.
- **Mobile:** Collapsible hamburger menu; bottom tab bar for primary actions; swipe gestures for quick navigation between Vehicle, Wheel, and Preview.
- **Keyboard Navigation:** `Tab` moves through navigation items; `Enter` activates; `Escape` closes dropdowns; `Arrow` keys navigate within dropdown menus.
- **Accessibility:** `aria-label` on all navigation links; current page indicated by `aria-current="page"`; focus indicators visible (minimum 2px outline, high contrast).

---

## Section: NAV-002 — Component Behavior Specification

Every interactive component follows standardized behavior patterns:

### Button Component Behavior

| State | Visual | Interaction | Accessibility |
|---|---|---|---|
| Default | Primary color; shadow | Click navigates or triggers action | `aria-label` describes action |
| Hover | Darker shade; shadow increase | Cursor pointer | Focus ring visible |
| Active | Depressed appearance; shadow reduced | Action executed; loading state may follow | `aria-pressed` for toggle buttons |
| Disabled | Grayscale; reduced opacity; no shadow | No click; cursor `not-allowed` | `aria-disabled="true"`; excluded from tab order |
| Loading | Spinner replaces text; disabled | No interaction; action in progress | `aria-busy="true"` |

---

*Navigation Architecture fully specified with hierarchy, behavior patterns, keyboard navigation, and accessibility requirements.*
