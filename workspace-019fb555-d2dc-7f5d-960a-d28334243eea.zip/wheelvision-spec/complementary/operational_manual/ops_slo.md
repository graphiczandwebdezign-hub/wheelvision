# OPERATIONAL EXCELLENCE MANUAL — SERVICE LEVEL OBJECTIVES

## Section: SLO-001 — Availability SLO

### SLO Definition

The WheelVision platform must be available 99.95% of the time during business hours (06:00–22:00, all active time zones) over any 30-day rolling window.

**Calculation:**
`Availability = (Total Time - Unavailable Time) / Total Time × 100%`

**Unavailable Time Definition:** Any period where the core application (Next.js web app, API endpoints, rendering service) is unreachable by users OR responds with HTTP 5xx errors for > 50% of requests during a 5-minute measurement window.

---

### Measurement Protocol

- Synthetic health checks executed every 30 seconds from 3 geographic regions.
- Results aggregated every 5 minutes.
- Daily availability computed; 30-day rolling average reported.
- Measurement stored in metrics database (`metrics_daily` table).

---

### Error Budget

- Target: 99.95% = maximum 21.6 minutes of downtime per 30 days.
- Budget consumption tracked daily.
- Budget depleted (> 21.6 minutes used) triggers operational review.
- Budget replenished on rolling basis.

---

### Alert Thresholds

| Condition | Severity | Response Time | Action |
|---|---|---|---|
| Availability < 99.99% (1 min downtime) | Warning | 30 minutes | Investigate; prepare mitigation |
| Availability < 99.95% (21.6 min budget used) | Critical | 5 minutes | Activate incident response |
| Availability < 99.0% (major outage) | Emergency | 1 minute | CTO escalation; full response |

---

### Engineering Rationale

SLOs must be quantitative, measurable, and enforceable. The 99.95% target balances commercial reliability with operational reality. Error budgets prevent overreaction to minor outages while ensuring significant failures trigger appropriate response.

---

## Section: SLO-002 — Latency SLO

### SLO Definition

- API endpoint p95 latency: < 200ms.
- Rendering update p95: < 500ms.
- Quotation PDF generation p95: < 3,000ms.

**Measurement:** Synthetic transactions executed every minute from production environment. Latency measured from request initiation to complete response (for API) or render complete (for rendering).

---

## Section: SLO-003 — Accuracy SLO (AI Pipeline)

### SLO Definition

- Automatic approval rate: >= 92% of processed assets.
- False positive rate (bad assets published): <= 0.1%.
- Human review queue depth: <= 50 assets (average over 1 hour).

**Measurement:** Pipeline metrics aggregated hourly; monthly averages reported.

---

## Section: SLO-080 — Service Level Objectives — Implementation Requirements

Every SLO must include:
- Quantitative target with units.
- Measurement method (what is measured, how, frequency).
- Alert thresholds (warning, critical, emergency).
- Error budget definition (for availability SLOs).
- Response timeline.
- Audit mechanism (how measurements are verified).
- Review schedule (monthly for operational SLOs; quarterly for strategic SLOs).

---

*Operational Excellence Manual Section: SLOs fully defined with measurement protocols, alert thresholds, error budgets, and audit requirements.*
