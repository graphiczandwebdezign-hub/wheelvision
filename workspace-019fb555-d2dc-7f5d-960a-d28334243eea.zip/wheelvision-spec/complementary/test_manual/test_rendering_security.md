# ENTERPRISE TEST MANUAL — RENDERING VALIDATION & SECURITY TEST PROTOCOLS

## Module: RENDERING ENGINE (Chapter 7, 12)

---

## TEST-RND-001 — Scene Graph Integrity

| Attribute | Specification |
|---|---|
| Requirement Trace | FR-VE-001, Chapter 7, Section 7.3 |
| Test ID | RND-001 |
| Title | Scene graph contains exactly 5 layers in correct order |
| Preconditions | Konva Stage initialized; metadata loaded; assets accessible |
| Inputs | Standard vehicle metadata (Toyota Hilux 2025) |
| Expected Outputs | Layer count = 5; order = Vehicle, Front Wheel, Rear Wheel, Shadow, Overlay; all children present |
| Failure Modes | Missing layer; wrong order; missing child; duplicate layer |
| Automation | AUTOMATED (unit test with Konva mock) |
| Priority | P0 |
| Validation Method | Programmatic layer inspection; count and name verification |
| Performance Target | Construction < 50ms |
| Regression Baseline | Baseline image stored; SSIM >= 0.99 for identical input |

---

## TEST-RND-002 — Mathematical Scaling Accuracy

| Attribute | Specification |
|---|---|
| Requirement Trace | Chapter 12, Section 12.2; FR-WD-002 |
| Test ID | RND-002 |
| Title | Scale factor equals selected diameter divided by reference diameter within ±0.001 |
| Preconditions | Reference diameter known; selected diameter specified; native image loaded |
| Inputs | Reference = 340px; Selected = 18" (equivalent to 408px) |
| Expected Outputs | Scale = 1.200 ± 0.001; rendered dimensions = native * scale ± 2px |
| Failure Modes | Non-uniform scale; scale = 0; scale > 5.0; aspect ratio distortion |
| Automation | AUTOMATED (mathematical script compares calculated vs measured) |
| Priority | P0 |
| Validation Method | Pixel measurement on exported PNG at native resolution |

---

## TEST-RND-003 — Performance Budget Enforcement

| Attribute | Specification |
|---|---|
| Requirement Trace | NFR-PRF-002; Chapter 7, Section 7.10 |
| Test ID | RND-003 |
| Title | Full render update completes within 500ms (p95) |
| Preconditions | Assets cached; standard scene; no network latency |
| Inputs | User selects new wheel finish |
| Expected Outputs | p50 <= 300ms; p95 <= 500ms; p99 <= 800ms; max <= 1,000ms |
| Failure Modes | Budget exceeded; memory leak detected (heap growth > 10% between updates); layer recreation instead of update |
| Automation | SEMIAUTOMATED (Playwright synthetic; manual review if budget exceeded) |
| Priority | P0 |
| Implementation Notes | Measure with `performance.now()` before/after update. Monitor heap with Chrome DevTools. If budget exceeded twice consecutively, block deployment. |

---

## Module: SECURITY & RLS (Chapter 20, 5)

---

## TEST-SEC-001 — RLS Policy Enforcement (pgTap)

| Attribute | Specification |
|---|---|
| Requirement Trace | Chapter 5 (DDL), Chapter 20 (Security), Chapter 4 (DDD Aggregates) |
| Test ID | SEC-001 |
| Title | Every table with RLS returns zero foreign rows |
| Preconditions | Tables `tenants`, `users`, `vehicles`, `wheels`, `tyres`, `quotes`, `inventory`, `tenant_memberships` exist; RLS enabled; policies created |
| Inputs | Insert sample data for tenant_A and tenant_B; set session to tenant_A; query all tables |
| Expected Outputs | SELECT returns only tenant_A rows; INSERT with wrong tenant_id blocked; UPDATE foreign rows blocked; DELETE foreign rows blocked |
| Failure Modes | Policy missing; `current_setting` returns null incorrectly; service role accidentally bypasses RLS |
| Automation | AUTOMATED (pgTap script executed in CI pipeline) |
| Priority | P0 |
| Implementation Notes | Use `pgTap` framework. Test each policy individually. Verify `WITH CHECK` clauses for INSERT and UPDATE. Document any failures in security audit log. |

---

## TEST-SEC-002 — Cross-Tenant Quote Access Blocked

| Attribute | Specification |
|---|---|
| Requirement Trace | FR-MT-002; Chapter 16 (Multi-Tenant) |
| Test ID | SEC-002 |
| Title | User from tenant_A cannot access quote from tenant_B via API or direct DB query |
| Preconditions | User_A (tenant_A) authenticated; Quote_B exists |
| Inputs | `GET /api/quotes/{quote_B_id}`; direct PostgreSQL SELECT with user_A role |
| Expected Outputs | HTTP 403 (API); 0 rows (DB query) |
| Failure Modes | Middleware fails; RLS bypassed; application filter missing |
| Automation | AUTOMATED |
| Priority | P0 |

---

*Enterprise Test Manual sections delivered with full traceability matrices, failure mode documentation, automation status, and validation protocols for rendering and security.*
