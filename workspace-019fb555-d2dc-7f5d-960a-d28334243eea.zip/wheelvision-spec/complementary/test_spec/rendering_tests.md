# RENDERING ENGINE & VISUAL REGRESSION TEST CASES

## Module Reference
Core Architecture: Chapter 7 (Rendering Engine), Chapter 12 (Rendering Mathematics)
Functional Requirements: FR-VE-001, FR-VE-002, FR-VE-003
Performance Requirements: NFR-PRF-002 (Interactive < 500ms)

---

## RND-001 — Scene Graph Construction from Metadata

| Field | Value |
|---|---|
| Requirement ID | FR-VE-001 |
| Test ID | RND-001 |
| Title | Metadata JSON produces correct Konva scene graph |
| Preconditions | `metadata.json` exists; Konva stage initialized; all assets accessible |
| Inputs | Sample metadata: Toyota Hilux 2025 |
| Expected Output | Scene graph contains Vehicle Layer, Front Wheel Layer, Rear Wheel Layer, Shadow Layer, Overlay Layer in correct order |
| Failure Modes | Missing layer; incorrect layer order; missing image asset; coordinate out of bounds |
| Automation Status | AUTOMATED (unit test with mock metadata) |
| Priority | P0 |
| Traceability | Chapter 7 (Layer Architecture), Chapter 6 (Metadata Schema) |
| Validation Rules | Every layer must exist; layer order must match specification (vehicle → wheels → shadow → overlay); all image URLs must resolve |

---

## RND-002 — Scaling Transformation Accuracy

| Field | Value |
|---|---|
| Requirement ID | FR-WD-002 (Diameter triggers scaling) |
| Test ID | RND-002 |
| Title | Scaling pipeline applies exact mathematical transformation |
| Preconditions | Wheel image loaded; reference diameter known; selected diameter provided |
| Inputs | Reference: 340px; Selected: 18 inches (converted to 408px equivalent) |
| Expected Output | Scale factor = 408/340 = 1.2; rendered wheel width = native_width * 1.2; aspect ratio preserved |
| Failure Modes | Non-uniform scaling (aspect ratio distorted); scale < 0 (invalid); scale > 5.0 (excessive magnification) |
| Automation Status | AUTOMATED (mathematical verification script) |
| Priority | P0 |
| Traceability | Chapter 12 (Rendering Mathematics), Section 12.2 (Scaling Formula) |
| Implementation Notes | Verify using pixel measurement on rendered output canvas. Compare rendered dimensions to calculated dimensions with tolerance ±2 pixels. |

---

## RND-003 — Performance Budget Enforcement

| Field | Value |
|---|---|
| Requirement ID | NFR-PRF-002 |
| Test ID | RND-003 |
| Title | Full update cycle completes within 500ms budget |
| Preconditions | Cached assets; standard scene complexity |
| Inputs | User selects new wheel variant |
| Expected Output | Complete render cycle (scene reconstruction → image load → transformation → composite → display) <= 500ms (p95); <= 800ms (absolute maximum) |
| Failure Modes | Budget exceeded; memory leak detected; layer recreation instead of update |
| Automation Status | SEMIAUTOMATED (automated measurement; manual review if budget exceeded) |
| Priority | P0 |
| Traceability | Chapter 7, Section 7.10 (Performance Budget), Chapter 21 |
| Performance Targets | p50: 300ms; p95: 500ms; p99: 800ms; max: 1,000ms |

---

## RND-004 — Visual Regression Baseline


| Field | Value |
|---|---|
| Requirement ID | FR-VE-003 (Realistic visual output) |
| Test ID | RND-004 |
| Title | Rendered output matches approved baseline within pixel tolerance |
| Preconditions | Baseline image stored in `/tests/baselines/`; same vehicle/wheel/colour configuration |
| Inputs | Current render output (PNG export at 300 DPI) |
| Expected Output | Pixel difference <= 1% from baseline; structural similarity index (SSIM) >= 0.95 |
| Failure Modes | Difference > 1%; SSIM < 0.95; structural change (missing layer, wrong position) |
| Automation Status | SEMIAUTOMATED (automated comparison; manual approval required for any deviation > 1%) |
| Priority | P1 |
| Traceability | Chapter 23 (Visual Regression), Chapter 7 (Rendering Engine) |
| Validation Rules | Baseline must include all standard configurations (front/rear angles, all finish types). Any new vehicle requires new baseline approval before production release. |

---

*Module complete. Rendering tests include mathematical verification, performance budget enforcement, and visual regression protocols.*
