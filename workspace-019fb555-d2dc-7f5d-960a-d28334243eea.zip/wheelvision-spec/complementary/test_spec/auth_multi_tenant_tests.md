# AUTHENTICATION & MULTI-TENANT TEST CASES

## Module Reference
Core Architecture: Chapter 15 (Authentication), Chapter 16 (Multi-Tenant Architecture)
Functional Requirements: FR-MT-001, FR-MT-002, SR-002
Non-Functional Requirements: NFR-AVL-001, NFR-SCL-001
Database Tables: `tenants`, `users`, `tenant_memberships`
Security Policies: `tenant_isolation_tenants`, `user_access_users`

---

## AUTH-001 — User Login with Valid Credentials

| Field | Value |
|---|---|
| Requirement ID | FR-001 (Implied — User Access) |
| Test ID | AUTH-001 |
| Title | Valid user login produces session and resolves tenant |
| Preconditions | User exists in `users` table; `tenant_id` set; RLS enabled |
| Inputs | Email: `dealer@example.com`; Password: valid |
| Expected Output | JWT cookie set; `app.current_tenant_id` set; redirect to dashboard |
| Failure Modes | Invalid password (401); Account inactive (403); Missing tenant (500) |
| Automation Status | AUTOMATED |
| Priority | P0 (Critical) |
| Traceability | FR-001, Chapter 15, `users` table, RLS policies |
| Implementation Notes | Test uses synthetic browser (Playwright). Verify cookie attributes (`HttpOnly`, `Secure`, `SameSite=Lax`). Verify session variable set in middleware. |

---

## AUTH-002 — Cross-Tenant Data Access Blocked

| Field | Value |
|---|---|
| Requirement ID | FR-MT-002 |
| Test ID | AUTH-002 |
| Title | User cannot access data from another tenant |
| Preconditions | User A (tenant_1) logged in; User B's quote exists in `quotes` table |
| Inputs | User A requests User B's quote: `GET /api/quotes/b-quote-id`
| Expected Output | HTTP 403 Forbidden; zero rows returned; audit log entry created |
| Failure Modes | RLS failure (user sees foreign data — CRITICAL BUG) |
| Automation Status | AUTOMATED |
| Priority | P0 (Critical) |
| Traceability | FR-MT-002, Chapter 16, `quotes` table, `tenant_isolation` policies |
| Implementation Notes | Test must verify database query result is empty, not just HTTP response. Use `pgTap` security test: `SET ROLE user; SELECT * FROM quotes WHERE id = b-quote-id;` must return 0 rows. |

---

## AUTH-003 — Multi-Tenant RLS Policy Enforcement (pgTap)

| Field | Value |
|---|---|
| Requirement ID | SR-002 |
| Test ID | AUTH-003 |
| Title | PostgreSQL RLS policies enforce isolation for all relevant tables |
| Preconditions | `tenants`, `users`, `vehicles`, `wheels`, `tyres`, `quotes`, `inventory` tables exist with RLS enabled |
| Inputs | Service role inserts sample data for tenant_1 and tenant_2; user role switches to tenant_1 user |
| Expected Output | Queries return only tenant_1 rows; no tenant_2 data visible |
| Failure Modes | RLS disabled; policy incorrect; `current_setting` not set (defaults to null, blocking all access — acceptable defensive behavior) |
| Automation Status | AUTOMATED (pgTap script executed in CI) |
| Priority | P0 (Critical) |
| Traceability | Chapter 5 (Database), Chapter 20 (Security), `ALTER TABLE ENABLE ROW LEVEL SECURITY` statements |
| Implementation Notes | Use `tests/authenticate_as(user_id)` pattern from Supabase documentation. Test every table with RLS. Verify `WITH CHECK` policies for INSERT and UPDATE. |

---

## AUTH-004 — Role-Based Access Control (RBAC) Matrix Validation

| Field | Value |
|---|---|
| Requirement ID | FR-MT-002, Chapter 15 |
| Test ID | AUTH-004 |
| Title | User roles restrict actions according to permissions matrix |
| Preconditions | Users with roles `user`, `admin`, `dealer_owner`, `platform_admin` exist |
| Inputs | Each role attempts: view assets, write assets, manage inventory, manage users, create quotes |
| Expected Output | Actions permitted/denied exactly per matrix in Chapter 15, Table 15.6.1 |
| Failure Modes | Incorrect role assignment allows unauthorized action |
| Automation Status | SEMIAUTOMATED (automated test + manual audit of matrix accuracy) |
| Priority | P1 (High) |
| Traceability | Chapter 15, Table 15.6.1, `users.role` column |

---

*Module complete. Authentication and multi-tenant test cases defined with full traceability, pgTap security protocols, and RBAC validation.*
