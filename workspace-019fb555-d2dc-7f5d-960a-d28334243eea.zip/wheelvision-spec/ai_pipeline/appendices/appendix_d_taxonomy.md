# APPENDIX D — CLASS TAXONOMY

| ID | Name | Description | Annotation Type | Parent |
|---|---|---|---|---|
| 1 | vehicle_body | Vehicle body excluding wheels | Polygon | root |
| 2 | wheel | Visible wheel (rim + tyre) | Circle | root |
| 3 | tyre | Tyre sidewall region | Mask | wheel |
| 4 | background | Non-vehicle region | Binary mask | root |
| 5 | occlusion_object | Overlapping non-vehicle object | Bounding box + class | root |
| 6 | reflection_region | Significant reflection area | Polygon | root |
| 7 | shadow_region | Vehicle cast shadow | Polygon | root |

---

*Appendix D complete.*
