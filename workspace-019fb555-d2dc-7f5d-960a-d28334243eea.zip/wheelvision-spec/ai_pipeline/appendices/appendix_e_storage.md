# APPENDIX E — DIRECTORY STRUCTURES AND STORAGE LAYOUT

```
/ai_pipeline/
  /datasets/
    /v{version}/
      /images/
      /annotations/
      /metadata/
  /models/
    /v{version}/
      /weights/
      /config/
      /registry/
  /staging/
    /images/
    /annotations/
  /production/
    /assets/
    /metadata/
  /archive/
    /v{version}/
  /logs/
    /pipeline/
    /inference/
    /training/
  /checkpoints/
    /{experiment_id}/
```

---

*Appendix E complete.*
