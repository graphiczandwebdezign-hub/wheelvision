# APPENDIX B — COMPLETE CONFIDENCE TABLES

## B.1 Component Confidence Thresholds

| Component | Auto-Approve Min | Review Min | Reject Max | Weight |
|---|---|---|---|---|
| Background Segmentation | 0.85 | 0.70 | < 0.70 | 0.15 |
| Vehicle Segmentation | 0.85 | 0.70 | < 0.70 | 0.15 |
| Wheel Detection | 0.90 | 0.75 | < 0.75 | 0.20 |
| Keypoint Detection | 0.80 | 0.65 | < 0.65 | 0.15 |
| Perspective Estimation | 0.75 | 0.60 | < 0.60 | 0.10 |
| Metadata Validation | 1.00 | 1.00 | < 1.00 | 0.15 |
| Image Quality | 0.85 | 0.65 | < 0.65 | 0.10 |

---

## B.2 Composite Score Thresholds

| Score Range | Decision | Human Review Required | Automatic Action |
|---|---|---|---|
| >= 0.92 | Approve | No | Publish immediately |
| 0.75 – 0.91 | Review | Yes (mandatory) | Queue for human verification |
| < 0.75 | Reject | No (optional audit) | Do not publish; log reason |

---

*Appendix B complete.*
