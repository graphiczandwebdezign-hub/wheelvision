# APPENDIX A — COMPLETE JSON SCHEMAS

## A.1 Pipeline Output Metadata Schema (v1.0)

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "WheelVision AI Pipeline Output",
  "type": "object",
  "required": ["pipeline_version", "asset_id", "metadata_version", "vehicle", "layers", "confidence", "audit"],
  "properties": {
    "pipeline_version": { "type": "string" },
    "asset_id": { "type": "string", "format": "uuid" },
    "metadata_version": { "const": "1.0" },
    "confidence": {
      "composite_score": { "type": "number", "minimum": 0, "maximum": 1 },
      "component_scores": { "type": "object" },
      "threshold_met": { "type": "boolean" },
      "review_required": { "type": "boolean" }
    },
    "vehicle": {
      "manufacturer": { "type": "string" },
      "model": { "type": "string" },
      "year": { "type": "integer" },
      "center": { "type": "object", "properties": { "x": {"type":"number"}, "y": {"type":"number"} } },
      "scale_reference": { "type": "number" }
    },
    "layers": { "type": "object" },
    "perspective": { "type": "object" },
    "audit": {
      "pipeline_run_id": { "type": "string" },
      "model_versions": { "type": "object" },
      "timestamp": { "type": "string", "format": "date-time" },
      "user_approval": { "type": "boolean" }
    }
  },
  "additionalProperties": false
}
```

---

## A.2 Confidence Score Schema

```json
{
  "type": "object",
  "required": ["composite", "components", "threshold", "decision"],
  "properties": {
    "composite": { "type": "number", "minimum": 0, "maximum": 1 },
    "components": {
      "background_segmentation": { "type": "number" },
      "vehicle_segmentation": { "type": "number" },
      "wheel_detection": { "type": "number" },
      "keypoint_detection": { "type": "number" },
      "perspective_estimation": { "type": "number" },
      "metadata_validation": { "type": "number" },
      "image_quality": { "type": "number" }
    },
    "threshold": { "type": "number" },
    "decision": { "enum": ["approve", "review", "reject"] }
  }
}
```

---

*Appendix A complete.*
