# APPENDIX I — OPERATIONAL RUNBOOKS

## I.1 Model Deployment Runbook

1. Complete validation checklist.
2. Run benchmark on golden dataset.
3. Update model registry.
4. Deploy to staging environment.
5. Execute integration tests.
6. Execute performance tests.
7. Human review sample outputs.
8. Promote to production (gradual rollout: 10% → 50% → 100%).
9. Monitor metrics for 24 hours.
10. Confirm stable; finalize deployment.

---

## I.2 Incident Response Runbook

- Detect alert.
- Assess severity (warning / critical / emergency).
- Contain (isolate affected service, disable automatic publishing if unsafe).
- Notify (appropriate team based on severity).
- Recover (restore service, replay queue, rollback model if needed).
- Root cause analysis (document, implement fix).
- Post-incident review.

---

*Appendix I complete.*
