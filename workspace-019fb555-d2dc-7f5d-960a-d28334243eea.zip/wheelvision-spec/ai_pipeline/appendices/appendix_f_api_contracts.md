# APPENDIX F — API CONTRACTS

## F.1 Inference Request

```json
{
  "request_id": "uuid",
  "image_url": "https://staging.../image.jpg",
  "model_version": "v3.0.1",
  "priority": "standard",
  "callback_url": "https://api.../results"
}
```

---

## F.2 Inference Response

```json
{
  "request_id": "uuid",
  "status": "completed",
  "results": {
    "predictions": {...},
    "confidence": {...},
    "metadata_url": "https://production.../metadata.json"
  },
  "processing_time_ms": 1850
}
```

---

*Appendix F complete.*
