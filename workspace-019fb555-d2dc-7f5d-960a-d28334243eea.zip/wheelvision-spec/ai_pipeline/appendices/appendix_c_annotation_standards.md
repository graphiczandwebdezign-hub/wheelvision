# APPENDIX C — ANNOTATION STANDARDS

## C.1 Annotation Quality Levels

| Level | Requirements | Inter-Annotator Agreement | Use Case |
|---|---|---|---|
| Gold | Professional annotator; double-checked | >= 0.95 IoU | Validation and test sets |
| Silver | Trained annotator; single pass; spot-checked | >= 0.90 IoU | Training set |
| Bronze | Initial annotation; requires senior review | < 0.90 IoU (before review) | Raw data for review |

---

## C.2 Annotation Format

Annotations stored as JSON files alongside images. Each file contains:
- `image_path`: Relative path to image.
- `annotations`: Array of annotation objects (polygons, circles, keypoints).
- `metadata`: Image conditions, annotator ID, timestamp, quality rating.
- `quality_check`: Boolean; indicates whether annotation passed quality review.

---

*Appendix C complete.*
