# APPENDIX G — REVIEW FORMS

## G.1 Human Review Form Template

Fields:
- Review ID (auto-generated).
- Asset ID (checksum/reference).
- Reviewer ID.
- Review timestamp (start/end).
- Original image URL.
- Rendered preview URL.
- Predicted metadata (read-only display).
- Action: Approve / Reject / Correct.
- If Correct: List of modified fields with before/after values.
- If Reject: Reason selection (corruption, occlusion, wrong vehicle, poor quality, other) + optional comment.
- Duration (calculated).
- Audit confirmation (digital signature / user confirmation).

---

*Appendix G complete.*
