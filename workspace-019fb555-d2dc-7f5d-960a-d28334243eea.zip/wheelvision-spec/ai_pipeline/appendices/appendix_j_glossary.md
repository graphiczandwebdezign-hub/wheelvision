# APPENDIX J — GLOSSARY

**IoU (Intersection over Union):** Ratio of overlap between predicted and ground truth regions to total combined area. Key accuracy metric for segmentation.
**mAP (mean Average Precision):** Average precision across all classes; key accuracy metric for object detection.
**RMSE (Root Mean Square Error):** Square root of mean squared differences; key accuracy metric for regression (coordinates, diameters).
**F1 Score:** Harmonic mean of precision and recall; balanced accuracy metric.
**NeRF:** Neural Radiance Field; 3D scene representation using neural networks.
**Gaussian Splatting:** Alternative 3D representation using 3D Gaussian primitives for faster rendering.
**RANSAC:** Random Sample Consensus; robust algorithm for fitting geometric models (circles, lines) to noisy data.
**ONNX:** Open Neural Network Exchange; standard format for model interoperability.
**RLP (Row-Level Policy):** Not applicable to AI pipeline; included for consistency with database architecture.
**SLO (Service Level Objective):** Quantitative target for service performance (latency, availability, accuracy).

---

*Appendix J complete. AI Engineering Specification fully finalized.*
