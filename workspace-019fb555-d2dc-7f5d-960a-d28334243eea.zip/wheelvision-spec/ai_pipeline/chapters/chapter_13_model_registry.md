# CHAPTER 13 — MODEL REGISTRY

## 13.1 Purpose

Defines version numbering, semantic versioning, dataset linkage, model lineage, rollback, promotion, approval gates, and compatibility matrix.

---

## 13.2 Version Numbering

Semantic versioning (`MAJOR.MINOR.PATCH`):

- **MAJOR:** Architecture change (new backbone, different model family); requires full validation and approval cycle.
- **MINOR:** Performance improvement or dataset update; requires validation but faster approval.
- **PATCH:** Bug fix, hyperparameter adjustment; minimal validation, rapid deployment.

---

## 13.3 Dataset Linkage

Every model version linked to dataset version (`dataset_version` field). Training dataset cannot change without creating new model version. Linkage ensures reproducibility: same dataset + same hyperparameters = same model (within random seed variation).

---

## 13.4 Model Lineage

Lineage tracked in registry:
- Parent model (previous version this model builds upon).
- Training dataset version.
- Experiment ID.
- Training code commit hash.
- Hyperparameters file.

Lineage graph supports rollback to any previous version with full reproducibility.

---

## 13.5 Compatibility Matrix

Every model version includes compatibility matrix:

| Image Format | Min Resolution | Supported | Notes |
|---|---|---|---|
| JPEG | 1024x768 | Yes | Baseline |
| PNG | 1024x768 | Yes | Alpha preserved |
| TIFF | 1024x768 | Yes | Professional |
| WebP | 1024x768 | Yes | Modern |
| RAW | Any | No (Future) | Requires conversion |

---

## 13.6 Approval Gates

Every model promotion requires:
- Technical validation (metrics exceed thresholds).
- Security review (no vulnerabilities in weights).
- Human review of sample outputs (minimum 50 random predictions reviewed by senior engineer).
- Documentation update (changelog, compatibility matrix, limitations).

---

## 13.7 Engineering Rationale

Model registry is the source of truth for all deployed AI. Version control, lineage, and compatibility tracking prevent deployment errors and support audit requirements.
