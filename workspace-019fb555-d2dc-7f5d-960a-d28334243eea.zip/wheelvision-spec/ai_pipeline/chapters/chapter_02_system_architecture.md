# CHAPTER 2 — OVERALL AI SYSTEM ARCHITECTURE

## 2.1 Purpose

Defines the complete system architecture for the AI pipeline, including context, container, component, deployment, communication, and sequence diagrams.

---

## 2.2 Scope

Covers all pipeline stages from image ingestion through asset publication, including external integrations (storage, database, CDN, review interface).

---

## 2.3 System Context Diagram

```mermaid
graph TD
    A[Raw Vehicle Image] --> B[Ingestion Queue]
    B --> C[Image Quality Assessment]
    C --> D[Computer Vision Pipeline]
    D --> E[Metadata Generation]
    E --> F[Confidence Scoring]
    F -->|Pass| G[Automatic Publishing]
    F -->|Fail| H[Human Review Queue]
    H --> I[Correction & Approval]
    I --> G
    G --> J[Production Assets]
    J --> K[CDN Distribution]
    L[Model Registry] --> D
    M[Training Pipeline] --> L
    N[Ground Truth Database] --> M
```

---

## 2.4 Container Diagram

```mermaid
C4Container
    title AI Pipeline Container Diagram
    System_Ext(S3, "Object Storage", "Staging + Production Assets")
    System_Ext(DB, "PostgreSQL", "Pipeline State + Metadata")
    System_Ext(CDN, "Cloudflare CDN", "Asset Distribution")
    System_Ext(UI, "Review Interface", "Admin Human Review Portal")

    System_Boundary(Pipeline, "AI Pipeline") {
        Container(Ingest, "Ingestion Service", "Python/FastAPI", "File validation, queue management")
        Container(Quality, "Quality Assessment", "Python/CV", "Blur, noise, occlusion detection")
        Container(CV, "CV Engine", "Python/PyTorch", "Segmentation, detection, keypoints")
        Container(Meta, "Metadata Engine", "Python", "JSON generation, validation")
        Container(Score, "Confidence Engine", "Python", "Weighted scoring, thresholds")
        Container(Publish, "Publishing Service", "Python/FastAPI", "CDN invalidation, versioning")
        Container(Registry, "Model Registry", "MLflow/Custom", "Version tracking, rollback")
        Container(Train, "Training Pipeline", "Python/PyTorch", "GPU training, validation")
    }

    Rel(S3, Ingest, "Upload")
    Rel(Ingest, DB, "State")
    Rel(Ingest, Quality, "Image")
    Rel(Quality, CV, "Filtered Image")
    Rel(CV, Meta, "Segmentations + Detections")
    Rel(Meta, Score, "JSON Draft")
    Rel(Score, Publish, "Approved Assets")
    Rel(Score, UI, "Review Queue")
    Rel(UI, Publish, "Approved Corrections")
    Rel(Publish, S3, "Production Upload")
    Rel(Publish, CDN, "Cache Invalidation")
    Rel(CV, Registry, "Load Model")
    Rel(Registry, Train, "New Versions")
    Rel(Train, DB, "Experiment Tracking")
```

---

## 2.5 Component Architecture

Each container consists of modular components:

**Ingestion Service Components:** File validator, Virus scanner, EXIF extractor, Queue publisher, Duplicate detector.
**Quality Assessment Components:** Blur detector, Noise estimator, Exposure analyzer, Occlusion detector, Reflection detector, Scoring aggregator.
**CV Engine Components:** Background segmentation model, Vehicle segmentation model, Wheel instance segmentation model, Tyre edge detector, Keypoint regressor, Circle fitter, Perspective estimator, Pose estimator.
**Metadata Engine Components:** Coordinate calculator, Diameter estimator, Mask generator, Shadow mask generator, JSON assembler, Schema validator.
**Confidence Engine Components:** Per-stage score aggregator, Weighted composite calculator, Threshold comparator, Decision logic (approve/reject/review).
**Publishing Service Components:** Asset uploader, Metadata writer, CDN invalidator, Version manager, Audit logger.

---

## 2.6 Deployment Diagram

```mermaid
graph TD
    A[Vercel / Cloud GPU Cluster] --> B[Ingestion Service]
    B --> C[Quality Assessment]
    C --> D[CV Engine - GPU Nodes]
    D --> E[Metadata Engine]
    E --> F[Confidence Engine]
    F --> G[Publishing Service]
    G --> H[Cloudflare R2 + CDN]
    I[Review Interface - Vercel] --> F
    J[Model Registry - Persistent Storage] --> D
    K[PostgreSQL - Pipeline State] --> A
    L[Training Cluster - Dedicated GPUs] --> J
```

---

## 2.7 Sequence Diagram — Full Pipeline Flow

```mermaid
sequenceDiagram
    participant User as Admin/Dealer
    participant Queue as Ingestion Queue
    participant QA as Quality Assessment
    participant CV as CV Engine
    participant Meta as Metadata Engine
    participant Conf as Confidence Engine
    participant Pub as Publishing Service
    participant CDN as CDN
    participant Rev as Review Interface

    User->>Queue: Upload image
    Queue->>QA: Validate & assess quality
    QA->>CV: Pass quality filter
    CV->>Meta: Output segmentations, detections
    Meta->>Conf: Generate draft metadata
    Conf->>Conf: Calculate composite score
    alt Score >= Threshold
        Conf->>Pub: Auto-approve
        Pub->>CDN: Publish assets
    else Score < Threshold
        Conf->>Rev: Queue for review
        Rev->>Pub: Human approval
        Pub->>CDN: Publish corrected assets
    end
```

---

## 2.8 Communication Flow

All inter-service communication uses HTTPS with TLS 1.3. Internal service communication uses service mesh or direct HTTPS with internal certificates. Message queuing uses a durable queue (e.g., RabbitMQ, AWS SQS, or Redis Streams) with at-least-once delivery semantics. Every message includes a correlation ID and timestamp.

---

## 2.9 Engineering Rationale (Architecture)

The architecture separates concerns into independent, scalable services. Each stage can be scaled horizontally (additional instances) without affecting other stages. The queue-based design provides backpressure management and failure isolation. The deployment topology supports GPU-intensive CV stages independently from lightweight ingestion and publishing services.

---

## 2.10 Trade-offs and Alternatives

**Alternative A — Monolithic Pipeline:** All stages in a single process. Trade-off: Simpler deployment but no independent scaling; GPU stages block ingestion; harder to maintain.
**Alternative B — Microservices (Selected):** Independent services with queues. Trade-off: Higher operational complexity but independent scaling, failure isolation, and technology optimization per stage.
**Alternative C — Serverless Per Image:** Each image triggers independent serverless functions. Trade-off: Excellent isolation but high cold-start latency and cost; not suitable for real-time batch processing.

---

## 2.11 Implementation Notes (Architecture)

- Every service exposes a health check endpoint (`/health`) for load balancer monitoring.
- Every service logs structured JSON with correlation IDs.
- Queue messages include retry counts; after 3 failures, messages moved to dead-letter queue for manual inspection.
- The architecture must support canary deployment of new model versions (traffic split between old and new CV engine versions).

---

*Chapter 2 complete. Full architecture with 6 diagram types defined.*
