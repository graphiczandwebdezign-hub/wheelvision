# CHAPTER 9 — METADATA GENERATION

## 9.1 Purpose

Defines how computer vision outputs are converted into structured metadata JSON for the WheelVision renderer.

---

## 9.2 Vehicle Coordinates

From vehicle segmentation mask, compute:
- Bounding box: `(x_min, y_min, x_max, y_max)`.
- Centre: `( (x_min + x_max)/2, (y_min + y_max)/2 )`.
- Scale factor: `max(width, height) / reference_dimension`.

Output stored in metadata: `vehicle_center`, `vehicle_scale`.

---

## 9.3 Wheel Coordinates

From circle detection results:
- Per wheel: `(centre_x, centre_y, radius_px)`.
- Diameter (pixels): `2 * radius_px`.

Output: `front_wheel`, `rear_wheel` objects with `x`, `y`, `diameter_pixels`.

---

## 9.4 Perspective and Camera Geometry

From keypoint detection and PnP:
- Rotation angles: `(roll, pitch, yaw)` in degrees.
- Translation: `(tx, ty, tz)` in normalized units (relative to vehicle size).
- Focal length estimate: `focal_length_px`.

Output: `perspective` and `camera` objects in metadata JSON.

---

## 9.5 Masks

Generated masks (binary PNG or WebP):
- `vehicle_mask.webp`: Vehicle body mask.
- `front_wheel_mask.webp`: Circular mask for front wheel.
- `rear_wheel_mask.webp`: Circular mask for rear wheel.
- `shadow_mask.webp`: Shadow region mask (derived from vehicle position + lighting direction).

Mask format: Grayscale (0 = transparent, 255 = opaque) or alpha channel in PNG/WebP.

---

## 9.6 Shadow Masks

Shadow generation uses vehicle geometry, estimated light direction (from exposure analysis and reflection patterns), and perspective transformation. Shadow mask is a soft-edged polygon projected onto ground plane. Intensity scaled by `shadow_opacity` (default 0.35, adjustable by metadata).

---

## 9.7 Lighting and Crop Regions

Lighting estimation: Mean direction of highlights (reflection analysis) provides approximate light source position. Crop regions (`crop_region`) define the recommended display area for the renderer scene.

---

## 9.8 Scaling and JSON Generation

Scale factor computed for renderer compatibility. Final JSON assembled following schema version 1.1 (see Appendix A). JSON validated against schema before publication.

---

## 9.9 Schema Validation

Every generated metadata file validated using JSON Schema validator (Python `jsonschema` or equivalent). Validation checks:
- All required fields present.
- Data types match schema.
- Coordinate values within valid ranges (non-negative, within image dimensions).
- No extra fields (if `additionalProperties: false`).

---

## 9.10 Engineering Rationale (Metadata)

Metadata generation is the bridge between computer vision outputs and the renderer. Accurate coordinates, diameters, masks, and perspective parameters are required for realistic visual output. Schema validation ensures renderer compatibility.

---

## 9.11 Implementation Notes

- Metadata files named `metadata.json` and stored alongside image assets.
- Every metadata generation produces audit entry linking to input image, model versions used, confidence scores, and output file hashes.
- Shadow mask generation can be disabled (`generate_shadow: false`) for indoor/studio images where shadow is not appropriate.

---

*Chapter 9 complete. Metadata generation fully specified with coordinate, mask, shadow, and schema validation requirements.*
