# CHAPTER 18 — TESTING STRATEGY

## 18.1 Purpose

Defines unit testing, integration testing, inference testing, performance testing, regression testing, visual testing, acceptance testing, benchmarking, and golden dataset protocols.

---

## 18.2 Unit Testing

Every model component tested independently:
- Segmentation: Test with synthetic images of known geometry (circle, rectangle, irregular shapes).
- Detection: Test with images containing 0, 1, 2, 4 wheels; verify recall and false positive rates.
- Keypoint: Test with known keypoint positions; measure RMSE.
- Metadata: Test JSON generation against schema; verify all required fields present and valid.

---

## 18.3 Integration Testing

Full pipeline tested with representative dataset (100 images covering diverse conditions):
- End-to-end processing time measured.
- Output metadata validated against schema.
- Published assets accessible via CDN.
- Human review interface functional.

---

## 18.4 Inference Testing

Every model version tested on golden dataset (500 images with ground truth annotations) before promotion:
- Accuracy metrics (IoU, mAP, RMSE, F1) computed.
- Performance metrics (latency, memory) recorded.
- Comparison with previous version documented.
- Results stored in experiment registry.

---

## 18.5 Performance Testing

Benchmark tests executed on dedicated hardware matching production configuration:
- Batch throughput: Process 1,000 images; measure total time and per-image average.
- Real-time latency: Process 100 images individually; compute p50, p95, p99.
- Load test: Simulate peak load (maximum concurrent requests) for 30 minutes; verify no failures or performance degradation.

---

## 18.6 Regression Testing

Every new model version tested against previous version's predictions on same dataset. Any significant regression (> 2% accuracy drop) triggers investigation and potential rollback.

---

## 18.7 Visual Testing

Sample outputs (rendered previews using generated metadata) visually inspected by engineering team. Any visual anomalies (incorrect wheel position, wrong scale, distorted perspective) trigger correction or rejection.

---

## 18.8 Acceptance Testing

Before production promotion, model version must pass:
- All unit tests (100% pass).
- Integration tests (100% pass).
- Inference tests (metrics exceed thresholds).
- Performance tests (targets met).
- Security review (passed).
- Human review of sample outputs (approved by senior engineer).

---

## 18.9 Golden Datasets

Fixed validation dataset (`golden_dataset_v1.0`) never modified. Used for regression testing, model comparison, and performance benchmarking. Dataset includes diverse vehicle types, lighting conditions, and background types.

---

## 18.10 Benchmarking Protocol

Standard benchmark procedure:
1. Load golden dataset.
2. Execute inference on all images.
3. Compute accuracy and performance metrics.
4. Compare with previous version.
5. Generate benchmark report (stored in registry).
6. Report reviewed by engineering lead before promotion.

---

## 18.11 Engineering Rationale

Comprehensive testing ensures reliability, performance, and quality. Golden datasets provide consistent comparison. Acceptance criteria prevent promotion of inadequate models.
