# CHAPTER 16 — PERFORMANCE ENGINEERING

## 16.1 Purpose

Defines latency targets, throughput, scalability, parallel processing, GPU sizing, autoscaling, load balancing, caching, and batch optimization.

---

## 16.2 Latency Targets (Detailed)

| Stage | Target p50 | Target p95 | Target p99 | Timeout |
|---|---|---|---|---|
| Ingestion | 200ms | 500ms | 1.0s | 2.0s |
| Quality Assessment | 300ms | 500ms | 800ms | 1.5s |
| CV Inference (Batch) | 1.5s/img | 2.5s/img | 4.0s/img | 5.0s/img |
| CV Inference (Real-Time) | 1.0s | 2.5s | 4.0s | 5.0s |
| Metadata Generation | 200ms | 400ms | 600ms | 1.0s |
| Confidence Scoring | 50ms | 100ms | 200ms | 500ms |
| Publishing | 300ms | 800ms | 1.5s | 3.0s |
| End-to-End (Batch) | 3.0s/img | 5.0s/img | 8.0s/img | 10.0s/img |
| End-to-End (Real-Time) | 2.5s | 5.0s | 8.0s | 10.0s |

---

## 16.3 Throughput Targets

- **Batch Mode:** >= 500 images/hour per GPU node (4x A100 cluster = 2,000 images/hour minimum).
- **Real-Time Mode:** >= 30 concurrent real-time requests per GPU node (with < 10% latency degradation).
- **Peak Capacity:** System must scale to 10,000 images/day (416/hour) without manual intervention.

---

## 16.4 Scalability

Horizontal scaling: Additional GPU nodes added automatically when queue depth exceeds threshold or latency exceeds target. Scaling limits: Maximum 32 GPU nodes (configuration limit to prevent resource exhaustion and cost overrun). Scaling down: Nodes removed when utilization < 30% for > 30 minutes.

---

## 16.5 GPU Sizing and Autoscaling

Autoscaling rules:
- Scale out: Queue depth > 200 OR p95 latency > 3.5s OR GPU utilisation > 85% for > 5 minutes.
- Scale in: Queue depth < 50 AND p95 latency < 2.0s AND GPU utilisation < 30% for > 30 minutes.
- Minimum nodes: 2 (high availability). Maximum nodes: 32.

---

## 16.6 Load Balancing

Load balancer distributes requests using weighted round robin (considering node load and GPU memory availability). Health checks every 15 seconds; unhealthy nodes removed from rotation within 30 seconds.

---

## 16.7 Caching

- Model weights cached in GPU memory for active versions (reduces load time from 5s to < 100ms).
- Image pre-processing results cached for duplicate images (checksum-based cache in Redis, TTL 24 hours).
- Metadata templates cached for common vehicle types.

---

## 16.8 Batch Optimization

Batch size optimized per model based on memory profiling. Dynamic batch sizing: Batch size reduced automatically if out-of-memory errors detected; increased if throughput below target with available memory.

---

## 16.9 Engineering Rationale

Performance targets must be quantitative and enforceable. Autoscaling ensures cost-efficiency during low-demand periods and capacity during peaks. Caching reduces redundant computation.
