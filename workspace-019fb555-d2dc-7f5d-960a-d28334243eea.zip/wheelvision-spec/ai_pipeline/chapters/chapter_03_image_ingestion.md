# CHAPTER 3 — IMAGE INGESTION

## 3.1 Purpose

Defines the complete ingestion architecture for vehicle images entering the AI pipeline.

---

## 3.2 Supported Formats

| Format | Extension | MIME Type | Max Size | Colour Profile | Notes |
|---|---|---|---|---|---|
| JPEG | .jpg, .jpeg | image/jpeg | 50 MB | sRGB, Adobe RGB | Baseline accepted; progressive preferred |
| PNG | .png | image/png | 50 MB | sRGB, Adobe RGB | Transparency preserved for masks |
| TIFF | .tif, .tiff | image/tiff | 100 MB | Any ICC profile | Professional source preferred |
| WebP | .webp | image/webp | 30 MB | sRGB | Modern format; lossless/lossy |
| RAW (optional) | .cr2, .nef, .arw | various | 200 MB | Camera native | Future expansion; requires conversion |

---

## 3.3 Resolution Requirements

| Parameter | Minimum | Recommended | Maximum |
|---|---|---|---|
| Width (pixels) | 1,024 | 2,048 | 8,192 |
| Height (pixels) | 768 | 1,536 | 8,192 |
| Aspect Ratio | Any | 4:3 or 3:2 | 21:9 |
| DPI (if embedded) | 72 | 150+ | Any |

Images below minimum dimensions are rejected automatically (insufficient detail for accurate segmentation). Images above maximum are downscaled using Lanczos resampling to recommended dimensions before processing.

---

## 3.4 Colour Profiles and EXIF

Every image must include EXIF data. Required EXIF fields extracted:

- `Make`, `Model`: Camera manufacturer and model.
- `DateTimeOriginal`: Capture timestamp.
- `ExposureTime`: Shutter speed (for motion blur estimation).
- `FNumber`: Aperture (for depth of field estimation).
- `ISOSpeedRatings`: ISO value (for noise estimation).
- `FocalLength`: Lens focal length in mm (for perspective estimation).
- `GPSLatitude`, `GPSLongitude`: Optional; for geolocation metadata.
- `Orientation`: Image orientation tag; corrected before processing.

Images missing critical EXIF (`Make`, `Model`, `DateTimeOriginal`) trigger a warning but are not rejected (manual metadata entry possible). Images missing `FocalLength` receive a default perspective assumption (standard 50mm equivalent) with reduced confidence score.

---

## 3.5 Integrity Verification

Every uploaded file undergoes:

1. **File Size Validation:** Must be within format limits.
2. **Magic Byte Verification:** File header bytes verified against format specification (not relying on file extension alone).
3. **Image Integrity:** Image library (PIL, OpenCV) attempts to open file; corrupt files rejected.
4. **Checksum Calculation:** SHA-256 hash computed and stored for duplicate detection and audit.
5. **Duplicate Detection:** Hash compared against database of previously processed assets; exact duplicates rejected with message `DUPLICATE_IMAGE`.

---

## 3.6 Virus Scanning

Every file scanned using ClamAV or commercial equivalent before storage. Infected files rejected immediately; upload event logged with virus signature. No infected file is written to persistent storage.

---

## 3.7 Queue Architecture

Ingestion uses a durable message queue (e.g., RabbitMQ with persistent queues, AWS SQS, or Redis Streams with AOF persistence). Queue configuration:

- **Durability:** Messages persisted to disk; survive broker restart.
- **Delivery Guarantee:** At-least-once; idempotency enforced by checksum (duplicate messages with same checksum processed once, acknowledged as complete).
- **Queue Priority:** High-quality uploads (from trusted sources) processed in priority queue; bulk uploads processed in standard queue.
- **Backpressure:** If queue depth exceeds 10,000 messages, ingestion rate limited; alerts triggered.

---

## 3.8 Storage Architecture

Staging storage: `/staging/{year}/{month}/{checksum}.ext` — temporary storage for processing. Production storage: `/production/assets/{vehicle_id}/images/` — permanent storage after approval. Archive storage: `/archive/{checksum}/` — long-term retention for audit (retained for 7 years per compliance requirements).

---

## 3.9 Failure Handling (Ingestion)

Every possible ingestion failure is documented with recovery strategy:

| Failure Scenario | Detection | Response | Recovery |
|---|---|---|---|
| Corrupt file | Integrity check fails | Reject upload; log error | User re-uploads |
| Virus detected | ClamAV positive | Reject; alert security | Security review; delete file |
| Duplicate image | Hash match | Reject; return reference ID | Link to existing asset |
| Queue overflow | Queue depth > 10,000 | Rate limit ingestion; alert ops | Scale ingestion nodes |
| Storage failure | Write error | Retry 3 times; then dead-letter queue | Restore storage; replay queue |
| Network timeout | No response within 30s | Retry with exponential backoff | Restore connectivity |

---

## 3.10 Engineering Rationale (Ingestion)

Ingestion must be defensive because it is the entry point for all untrusted input. Integrity verification prevents corrupt images from consuming processing resources. Duplicate detection prevents redundant processing. Virus scanning protects infrastructure. Queue architecture provides backpressure and failure isolation.

---

## 3.11 Implementation Notes

- Every ingestion event creates a database record (`ingestion_logs`) with timestamp, checksum, user/tenant reference, file size, format, and outcome.
- EXIF extraction performed using `exifread` or `Pillow` library; extraction failures logged but do not block processing.
- Queue messages include priority level (high/standard) derived from upload source.

---

*Chapter 3 complete. Ingestion fully specified with integrity, security, and failure protocols.*
