# CHAPTER 11 — HUMAN REVIEW SYSTEM

## 11.1 Purpose

Defines reviewer workflow, approval workflow, correction tools, metadata editing, side-by-side comparison, audit trail, permissions, and queue management.

---

## 11.2 Reviewer Workflow

```mermaid
stateDiagram-v2
    [*] --> Queued
    Queued --> Reviewing: Reviewer claims task
    Reviewing --> Approved: Confirm metadata
    Reviewing --> Rejected: Incorrect
    Reviewing --> Corrected: Edit metadata
    Corrected --> Publishing: Confirm corrections
    Approved --> Publishing
    Rejected --> [*] : Log reason
    Publishing --> [*]
```

---

## 11.3 Approval Workflow

Reviewer actions:
- **Approve:** Confirm all predictions correct; asset published automatically.
- **Correct:** Modify metadata values (coordinates, diameters, masks) using correction interface; asset published after correction confirmation.
- **Reject:** Asset removed from pipeline; reason selected from predefined list (corruption, occlusion, wrong vehicle, poor quality, other); log created.

---

## 11.4 Correction Tools

Review interface provides:
- Side-by-side comparison: original image vs. rendered preview (using generated metadata).
- Interactive coordinate editor: drag wheel centre points; adjust diameter via slider.
- Mask editor: brush tool to correct segmentation masks.
- Perspective editor: adjust rotation angles and focal length estimates.
- Metadata panel: display all JSON fields; edit any value with validation.

---

## 11.5 Audit Trail

Every review action logged in `human_review_log` table:
- Review ID.
- Asset ID (checksum/reference).
- Reviewer user ID.
- Timestamp (start and end of review session).
- Action (approve/reject/correct).
- Fields modified (if corrected) with before/after values.
- Duration of review session.

---

## 11.6 Reviewer Permissions

- **Standard Reviewer:** Can approve/reject; cannot modify metadata (must escalate correction to senior reviewer).
- **Senior Reviewer:** Full correction capabilities.
- **Admin:** Queue management (reassign tasks, bulk approve/reject, view analytics).

---

## 11.7 Queue Management

Queue sorted by:
1. Priority (high-confidence review first; rejected items for audit).
2. Time in queue (oldest first to prevent stagnation).
3. Reviewer workload (balanced across team).

Queue depth alerts: > 50 items triggers additional reviewer assignment notification.

---

## 11.8 Engineering Rationale

Human review is the final quality gate. The review interface must provide sufficient context (original image, predictions, rendered preview, metadata) for accurate assessment. Audit trails ensure accountability and support continuous improvement analysis.

---

*Chapter 11 complete.*
