# CHAPTER 15 — SECURITY

## 15.1 Purpose

Defines model security, dataset security, access control, encryption, secrets management, audit logs, supply chain security, and adversarial defenses.

---

## 15.2 Model Security

- **Weight Encryption:** Model weights stored encrypted at rest (AES-256-GCM). Decryption occurs only at inference time in secure GPU memory.
- **Access Control:** Only authorized services can load model weights (service-to-service authentication with signed tokens).
- **Version Integrity:** Each model version signed with HMAC using secret key stored in secure vault (HashiCorp Vault, AWS Secrets Manager). Signature verified before loading.

---

## 15.3 Dataset Security

- **Access Control:** Dataset access restricted by role. Only training pipeline and approved researchers can access full dataset.
- **Encryption:** Datasets encrypted at rest and in transit (TLS 1.3 for transfers).
- **Audit:** Every dataset access logged (user/service, timestamp, files accessed, action: read/download/copy).

---

## 15.4 Adversarial Attack Defense

- **Adversarial Input Detection:** Input image analyzed for adversarial perturbations (gradient-based detection, statistical outlier analysis). Suspicious inputs rejected or flagged for review.
- **Model Robustness:** Adversarial training (FGSM, PGD attacks) included in training pipeline to improve robustness.
- **Poisoned Dataset Detection:** Statistical analysis of dataset distributions; outlier samples investigated; annotation consistency checked.

---

## 15.5 Supply Chain Security

- **Dependency Scanning:** All software dependencies (PyTorch, OpenCV, Python packages) scanned for known vulnerabilities (CVEs) before deployment.
- **Container Security:** Docker images scanned; only minimal base images used (distroless, alpine); no unnecessary packages.
- **Build Verification:** All builds signed; deployment verifies build signature.

---

## 15.6 Prompt Injection / Model Theft

- **Prompt Injection:** Not applicable for vision-only pipeline (no text input). However, metadata JSON inputs (if used for future text-based features) validated strictly against schema; no arbitrary code execution permitted.
- **Model Theft:** Model weights never transmitted over unencrypted channels. Inference endpoints require authentication. Rate limiting prevents bulk extraction attempts.

---

## 15.7 Secrets Management

- All secrets (database credentials, API keys, model decryption keys) stored in secure vault (not environment variables in code).
- Secrets rotated every 90 days (automatic rotation for database credentials; manual rotation for high-security keys).
- Access to secrets audited.

---

## 15.8 Engineering Rationale

Security is a design constraint, not a feature. Every layer (data, model, infrastructure) includes defense mechanisms. Adversarial defense is critical because malicious inputs could corrupt output metadata, affecting commercial quotations.
