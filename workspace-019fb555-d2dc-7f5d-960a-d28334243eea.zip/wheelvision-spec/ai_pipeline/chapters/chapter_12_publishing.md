# CHAPTER 12 — PUBLISHING PIPELINE

## 12.1 Purpose

Defines publishing workflow, versioning, CDN invalidation, rollback, asset lifecycle, promotion rules, and archive strategy.

---

## 12.2 Publishing Workflow

```mermaid
sequenceDiagram
    participant Conf as Confidence Engine
    participant Publish as Publishing Service
    participant DB as Pipeline DB
    participant R2 as R2 Storage
    participant CDN as CDN
    Conf->>Publish: Approved Asset
    Publish->>DB: Insert Asset Record
    Publish->>R2: Upload Images + JSON
    R2-->>Publish: Upload Confirmed
    Publish->>CDN: Invalidate Cache
    Publish->>DB: Update Status = Published
    DB-->>Publish: Confirm
```

---

## 12.3 Versioning

Every published asset assigned a version identifier derived from:
- Pipeline software version.
- Model versions used.
- Dataset version reference.
- Timestamp.

Version format: `{pipeline_version}-{model_version_hash}-{timestamp}` (e.g., `v2.1.0-m3.0.1-20260730`). Previous versions retained in archive; never overwritten (immutable publication).

---

## 12.4 CDN Invalidation

Upon publication, CDN cache invalidated for asset paths using purge request. Invalidation completes within 30 seconds (target). During invalidation window, users may see cached old version or new version depending on edge server; acceptable transient inconsistency.

---

## 12.5 Rollback

Rollback triggers:
- Incorrect asset published (detected post-publication via user report or automated audit).
- Security vulnerability discovered in published asset (e.g., malicious content embedded in image metadata).
- Model error detected through continuous monitoring.

Rollback process:
1. Mark asset status `rolled_back` in database.
2. Update CDN to serve previous version (if exists) or display error message.
3. Log rollback event with reason.
4. If previous version unavailable, asset removed from production (404 response).

---

## 12.6 Asset Lifecycle

| Stage | Duration | Action |
|---|---|---|
| Staging | Variable | Processing, review |
| Published | Permanent (until rollback) | Available to renderer |
| Archived | 7 years | Long-term audit storage |
| Deleted | Only on explicit admin action | Removed from all systems (audit log retained) |

---

## 12.7 Engineering Rationale

Publishing must be atomic (database + storage + CDN consistent) and reversible. Versioning ensures every published state is recoverable. CDN invalidation ensures global consistency within acceptable time.
