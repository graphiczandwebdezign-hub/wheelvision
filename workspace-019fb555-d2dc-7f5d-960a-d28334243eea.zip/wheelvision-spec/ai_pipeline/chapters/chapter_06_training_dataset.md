# CHAPTER 6 — TRAINING DATASET SPECIFICATION

## 6.1 Purpose

Defines dataset requirements, sources, annotation standards, quality control, versioning, and storage for training all pipeline models.

---

## 6.2 Dataset Sources

| Source | Type | Volume | License | Quality |
|---|---|---|---|---|
| Dealer Uploads (Historical) | Real-world | 50,000+ images | Proprietary | Variable |
| Professional Photography | Real-world | 10,000 images | Licensed | High |
| Synthetic Generation (3D Rendering) | Synthetic | 100,000+ images | Owned | Perfect labels |
| Public Automotive Datasets (COCO, Cityscapes) | Real-world | Adapted subsets | Open | Moderate |

---

## 6.3 Annotation Standards

Every image requires annotations following a strict schema:

- **Vehicle Polygon:** Pixel-level polygon defining vehicle body (excluding wheels).
- **Wheel Circles:** Per visible wheel: centre (x, y), radius (pixels).
- **Background Mask:** Binary mask (vehicle = 1, background = 0).
- **Tyre Mask:** Per wheel: tyre region mask.
- **Keypoints:** 12 structural points per vehicle (4 wheel centres, 4 corners, 4 roof/reference points).
- **Metadata:** Camera focal length (if known), vehicle manufacturer/model (if labeled), capture conditions (indoor/outdoor, lighting).

---

## 6.4 Annotation Tools

- **Primary:** LabelMe (polygon annotation) with custom plugins for circular wheel annotation.
- **Secondary:** CVAT (Computer Vision Annotation Tool) for large-scale collaborative annotation.
- **Quality Control:** Inter-annotator agreement computed; images with agreement < 0.90 IoU flagged for review by senior annotator.

---

## 6.5 Class Taxonomy

| Class ID | Class Name | Description | Parent | Annotation Type |
|---|---|---|---|---|
| 1 | vehicle_body | Vehicle body (excluding wheels) | root | Polygon |
| 2 | wheel | Visible wheel (rim + tyre) | root | Circle |
| 3 | tyre | Tyre sidewall region | wheel | Mask |
| 4 | background | Non-vehicle region | root | Binary mask |
| 5 | occlusion_object | Overlapping non-vehicle object | root | Bounding box + class |
| 6 | reflection_region | Significant reflection area | root | Polygon |
| 7 | shadow_region | Vehicle cast shadow | root | Polygon |

---

## 6.6 Dataset Balancing

Dataset must represent diverse conditions:

- Vehicle categories: passenger (30%), commercial (40%), performance (15%), offroad (15%).
- Lighting: daylight (60%), overcast (20%), indoor/studio (15%), low light (5%).
- Background types: urban (35%), rural (25%), studio (20%), natural (20%).
- Vehicle angles: front (25%), side (25%), front-three-quarter (25%), rear-three-quarter (25%).

Synthetic augmentation used to balance underrepresented categories.

---

## 6.7 Augmentation

Standard augmentation pipeline (applied with probability):

- Horizontal flip (p=0.5) — must update keypoint labels.
- Random rotation (±10°) with bilinear interpolation.
- Brightness/contrast adjustment (±20%).
- Gaussian noise injection (simulating low-quality sensors).
- Random crop and resize (maintaining aspect ratio within ±15%).

Synthetic augmentation: 3D rendered vehicles with random backgrounds, lighting conditions, and camera angles added to real dataset.

---

## 6.8 Dataset Versioning

Every dataset version identified by semantic version (`v1.0.0`) and dataset hash (SHA-256 of all annotation files + image list). Dataset registry links version to model training runs. Changes between versions documented in changelog.

---

## 6.9 Dataset Storage

Images stored in object storage (`/datasets/v{version}/images/`). Annotations in JSON format (`/datasets/v{version}/annotations/`). Metadata in CSV or database table linking image, dataset version, split (train/val/test), and annotations.

---

## 6.10 Quality Control

Every dataset release requires:
- Manual review of 5% random sample.
- Inter-annotator agreement >= 0.90.
- Zero missing annotations for required classes.
- Annotation completeness check (all images have all required annotations).
- Schema validation for all annotation files.

---

## 6.11 Engineering Rationale (Dataset)

High-quality, balanced, well-annotated datasets are the primary determinant of model performance. Synthetic augmentation expands diversity without manual labeling cost. Strict versioning ensures reproducibility.

---

*Chapter 6 complete. Dataset specification fully defined with taxonomy, balancing, augmentation, and quality control.*
