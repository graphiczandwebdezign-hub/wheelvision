# CHAPTER 8 — INFERENCE PIPELINE

## 8.1 Purpose

Defines the complete inference lifecycle, batch and real-time processing modes, GPU scheduling, CPU fallback, memory management, latency targets, timeout handling, and retry logic.

---

## 8.2 Inference Lifecycle

```mermaid
sequenceDiagram
    participant Queue as Inference Queue
    participant GPU as GPU Scheduler
    participant Model as Model Registry
    participant Engine as CV Engine
    participant Conf as Confidence Engine
    participant DB as Pipeline Database
    Queue->>GPU: Request Image + Model Version
    GPU->>Model: Load Weights
    Model-->>GPU: Weights Loaded
    GPU->>Engine: Execute Inference
    Engine->>Conf: Output Predictions + Scores
    Conf->>DB: Record Results
    DB-->>Queue: Acknowledge Complete
```

---

## 8.3 Batch Processing

Batch mode: Images grouped into batches (batch size 4–16 depending on model memory requirements). Batch processing maximizes GPU utilization and throughput. Batch results returned as aggregated JSON array.

---

## 8.4 Real-Time Processing

Real-time mode: Single image processed immediately (low latency, no batching). Used for admin preview uploads or urgent corrections. Real-time mode reserves dedicated GPU capacity or uses CPU fallback if GPU unavailable.

---

## 8.5 GPU Scheduling

Scheduler assigns inference requests to available GPU nodes based on:
- GPU memory availability.
- Current load (requests per second).
- Model version (some nodes dedicated to specific versions).
- Priority (high-priority requests bypass standard queue).

---

## 8.6 CPU Fallback

If GPU nodes unavailable (failure, overload, maintenance), pipeline falls back to CPU inference. CPU mode is slower (latency increases 5–10x) but ensures pipeline continuity. Fallback triggered automatically; alert sent to operations team. CPU inference uses optimized ONNX Runtime with threading.

---

## 8.7 Memory Management

Every inference process monitors GPU memory usage. If memory exceeds 90% of capacity, new requests queued rather than accepted (prevent out-of-memory crashes). Memory released after each batch through explicit tensor deletion and garbage collection trigger.

---

## 8.8 Latency Targets

| Mode | Target p95 | Target p99 | Timeout | Retry |
|---|---|---|---|---|
| Real-Time (GPU) | 2.5s | 4.0s | 5.0s | 2 retries |
| Batch (GPU) | 3.0s per image | 5.0s per image | 10.0s per batch | 1 retry |
| Real-Time (CPU Fallback) | 15.0s | 25.0s | 30.0s | 1 retry |

---

## 8.9 Timeout Handling

If inference exceeds timeout threshold, request canceled; error logged; image queued for retry or moved to dead-letter queue (after retries exhausted). Timeout prevents resource blocking.

---

## 8.10 Retry Logic

Every failed inference retries with exponential backoff (2s, 4s). After maximum retries (2 for GPU, 1 for CPU), request marked as failed. Failed requests reviewed manually; root cause analyzed (model error, data corruption, GPU failure).

---

## 8.11 Engineering Rationale (Inference)

Inference is the production-critical path. Latency targets ensure user experience for real-time previews. Batch processing optimizes cost. CPU fallback ensures resilience. Timeout and retry logic prevent cascade failures.

---

## 8.12 Implementation Notes (Inference)

- Inference service must expose health checks (`/health`) including GPU status.
- Every inference produces audit log: request ID, model version, input hash, output hash, latency, memory usage, result (success/failure/retry).
- Model weights cached in GPU memory for frequently used versions; less frequent versions loaded on demand (slight latency increase acceptable).

---

*Chapter 8 complete. Inference pipeline fully defined with scheduling, fallback, and performance targets.*
