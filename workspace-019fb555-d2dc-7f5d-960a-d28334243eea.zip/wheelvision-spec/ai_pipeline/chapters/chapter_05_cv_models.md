# CHAPTER 5 — COMPUTER VISION MODELS

## 5.1 Purpose

Defines the complete model architecture for all computer vision tasks required by the pipeline.

---

## 5.2 Background Segmentation

**Task:** Separate vehicle from background (sky, ground, buildings, trees).
**Model Selection:** U-Net or DeepLabV3+ with ResNet-101 or EfficientNet backbone.
**Input:** Full resolution image (recommended: 2048x1536).
**Output:** Binary mask (1 = vehicle + wheels, 0 = background).
**Performance Target:** IoU >= 0.93 on validation set; inference latency <= 1.2s (GPU).
**Engineering Rationale:** DeepLabV3+ provides state-of-the-art segmentation with atrous spatial pyramid pooling for multi-scale context. ResNet-101 balances accuracy and inference speed. Trade-off: Higher accuracy models (e.g., Vision Transformer-based) exist but require more GPU memory and longer inference; selected architecture achieves sufficient accuracy for commercial use.

---

## 5.3 Vehicle Segmentation

**Task:** Precise pixel-level segmentation of the vehicle body (excluding wheels, which are processed separately).
**Model:** Instance segmentation (Mask R-CNN or Mask2Former).
**Output:** Vehicle body polygon mask; separate wheel region masks.
**Performance Target:** Vehicle body IoU >= 0.92; wheel region IoU >= 0.88.

---

## 5.4 Wheel Segmentation

**Task:** Detect each visible wheel; generate precise circular mask for rim area.
**Model:** Instance segmentation with circular constraint post-processing.
**Output:** Per-wheel: bounding box, circular mask, confidence score, estimated centre (x, y), estimated diameter (pixels).
**Performance Target:** Detection recall >= 0.96 (detect 96% of visible wheels); false positive rate <= 0.05.
**Post-Processing:** Circle fitting (RANSAC-based or Hough transform) applied to segmented wheel region to enforce geometric consistency.

---

## 5.5 Tyre Segmentation

**Task:** Segment tyre sidewall area within wheel region.
**Model:** Semantic segmentation restricted to wheel bounding box (reduces computation).
**Output:** Tyre mask; estimated tyre width (pixels); estimated sidewall height (pixels).
**Performance Target:** Tyre IoU >= 0.85.

---

## 5.6 Object Detection (Anomaly and Occlusion)

**Task:** Detect non-vehicle objects overlapping with vehicle region (trees, poles, people, other vehicles, rain drops, reflections).
**Model:** YOLOv8 or Faster R-CNN.
**Output:** Bounding boxes, class labels, confidence scores for overlapping objects.
**Performance Target:** Detection mAP (mean Average Precision) >= 0.85 for occlusion classes.

---

## 5.7 Perspective Estimation

**Task:** Estimate camera pose and perspective parameters from vehicle appearance.
**Method:** Keypoint detection (vehicle corners, wheel centres, known structural points) combined with PnP (Perspective-n-Point) algorithm.
**Output:** Camera rotation matrix (3x3), translation vector (3x1), focal length estimate, perspective distortion coefficients.
**Performance Target:** Angular error < 3°; position error < 5% of vehicle size.
**Engineering Rationale:** Accurate perspective estimation is critical for correct wheel positioning and shadow placement in the renderer. Trade-off: Keypoint-based methods require clearly visible structural points; heavily occluded or atypical vehicles may produce less accurate estimates (mitigated by confidence scoring and human review).

---

## 5.8 Keypoint Detection

**Task:** Detect structural keypoints: front left wheel centre, front right wheel centre, rear left wheel centre, rear right wheel centre, vehicle front corner, rear corner, roof line points.
**Model:** Keypoint regression (e.g., HRNet or simple CNN with heatmap output).
**Output:** Keypoint coordinates (x, y) with per-point confidence scores.
**Performance Target:** Keypoint localization error <= 5 pixels (normalized to image resolution).

---

## 5.9 Coordinate Regression (Wheel Centres and Diameters)

**Task:** Direct regression of wheel centre coordinates and wheel diameters (in pixels) from image patches.
**Model:** CNN with regression heads (multi-task: x, y, diameter, confidence).
**Output:** Per wheel: (x, y, diameter_px, confidence).
**Performance Target:** Coordinate RMSE <= 8 pixels; diameter RMSE <= 3% of true diameter.

---

## 5.10 Camera Calibration

**Task:** Estimate intrinsic camera parameters (focal length, principal point, distortion coefficients) from image features and EXIF metadata.
**Method:** EXIF focal length provides initial estimate; refined using vanishing point analysis of vehicle structural lines and wheel ellipse shapes.
**Output:** Intrinsic matrix (3x3); distortion coefficients (5x1); confidence score.
**Performance Target:** Focal length estimate error < 10% when EXIF available; < 20% when EXIF missing.

---

## 5.11 Bounding Box and Circle Fitting

**Task:** Generate geometric primitives (bounding boxes for vehicles, circles for wheels) from segmentation outputs.
**Method:**
- Bounding boxes: Minimum enclosing rectangle of vehicle mask.
- Circles: RANSAC-based circle fitting to wheel pixel points; Hough circle transform as alternative.

**Output:** Bounding boxes (x_min, y_min, x_max, y_max); circles (centre_x, centre_y, radius).

---

## 5.12 Pose Estimation

**Task:** Estimate 3D pose (rotation, translation) of vehicle relative to camera.
**Method:** Keypoint-based PnP using detected wheel centres and structural points; refined using iterative closest point (ICP) between projected 3D model and 2D segmentation.
**Output:** 6-DOF pose (3 rotation angles, 3 translation components).
**Performance Target:** Rotation RMSE < 5°; translation RMSE < 10 cm (relative scale).
**Engineering Rationale:** Pose estimation supports future 3D renderer migration. Even in 2D mode, pose information improves perspective correction. Trade-off: Full 6-DOF estimation requires visible structural features; partial visibility produces lower confidence scores, triggering review.

---

## 5.13 Model Selection Criteria

Every model is evaluated against:

| Criterion | Weight | Measurement Method | Target |
|---|---|---|---|
| Accuracy (IoU / mAP) | 30% | Validation dataset | >= 0.90 (segmentation) / >= 0.85 (detection) |
| Inference Latency (p95) | 20% | GPU benchmark | <= 2.5s per image |
| Memory Footprint | 15% | GPU memory measurement | <= 4GB peak |
| Scalability | 15% | Horizontal scaling test | Linear throughput with GPU nodes |
| Interpretability | 10% | Model explanation capability | Heatmap / attention visualization available |
| Maintenance Cost | 10% | Training time, data requirements | Reasonable retraining cycle (< 2 weeks) |

---

## 5.14 Model Comparison Table

| Model | Task | IoU / mAP | Latency (p95) | Memory | Selection Status |
|---|---|---|---|---|---|
| DeepLabV3+ (ResNet-101) | Background Seg | 0.94 | 1.1s | 2.8GB | SELECTED |
| Mask2Former | Vehicle/Inst Seg | 0.93 | 1.8s | 3.2GB | SELECTED |
| YOLOv8x | Object Detection | 0.87 | 0.4s | 1.5GB | SELECTED |
| HRNet-W48 | Keypoint Reg | RMSE 4.2px | 1.3s | 2.1GB | SELECTED |
| U-Net (EfficientNet-B4) | Background Seg (Alternative) | 0.91 | 0.8s | 1.2GB | BACKUP |
| ViT-Seg (Vision Transformer) | Vehicle Seg (Future) | 0.96 | 3.5s | 6.8GB | FUTURE EXPANSION |

---

## 5.15 Trade-offs (CV Models)

- **Accuracy vs. Speed:** Higher accuracy models (ViT-based) exist but exceed latency targets. Selected models achieve sufficient accuracy within performance budget.
- **Memory vs. Batch Size:** Large models require more GPU memory, limiting batch size and throughput. Selected models allow batch sizes >= 8 on standard GPU nodes.
- **Specialization vs. Generalization:** Separate models for each task (segmentation, detection, keypoints) allow independent optimization and replacement. A single universal model would simplify deployment but reduce accuracy per task.

---

## 5.16 Implementation Notes (CV Models)

- All models must be exported to ONNX format for inference optimization (TensorRT, OpenVINO) where applicable.
- Model weights stored in version-controlled registry with dataset linkage.
- Inference code must include batching logic, GPU scheduling, and timeout handling.
- Every inference produces structured output (JSON) with predictions, confidence scores, and input metadata reference.

---

*Chapter 5 complete. All CV models defined with performance targets, selection criteria, and comparison table.*
