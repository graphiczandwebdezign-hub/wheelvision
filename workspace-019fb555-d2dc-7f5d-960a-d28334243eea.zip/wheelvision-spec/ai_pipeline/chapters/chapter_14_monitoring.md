# CHAPTER 14 — MONITORING

## 14.1 Purpose

Defines latency, GPU utilisation, memory, inference time, queue length, failure rate, accuracy metrics (IoU, precision, recall, F1), drift detection, alerting, and dashboards.

---

## 14.2 Metrics Definitions

| Metric | Measurement Method | Target | Alert Threshold |
|---|---|---|---|
| Latency (p95) | Per-request timestamp | <= 2.5s | > 4.0s |
| GPU Utilisation | NVIDIA SMI / nvidia-ml-py | >= 70% (optimal) | < 30% (underutilised) or > 95% (near overload) |
| Memory Usage | GPU memory monitoring | <= 80% capacity | > 90% |
| Queue Length | Queue depth measurement | <= 100 items | > 500 items |
| Failure Rate | Failed requests / Total | <= 0.5% | > 1% |
| Accuracy IoU | Validation dataset evaluation | >= 0.90 (segmentation) | < 0.85 |
| Precision | TP / (TP + FP) | >= 0.92 | < 0.88 |
| Recall | TP / (TP + FN) | >= 0.94 | < 0.90 |
| F1 Score | Harmonic mean of P and R | >= 0.93 | < 0.89 |

---

## 14.3 Drift Detection

Model drift monitored continuously:
- **Data Drift:** Distribution of input features (brightness, contrast, resolution) compared to training dataset. Alert if statistical distance exceeds threshold.
- **Concept Drift:** Model performance on golden dataset (fixed validation set) measured weekly. Alert if IoU drops > 3% relative to baseline.
- **Prediction Drift:** Distribution of model outputs (predicted coordinates, diameters) compared to historical production outputs. Alert if mean shifts > 10%.

---

## 14.4 Alerting

Alert levels:
- **Warning:** Metric approaches threshold (e.g., latency p95 = 3.5s, approaching 4.0s alert).
- **Critical:** Metric exceeds threshold; requires immediate response.
- **Emergency:** Pipeline failure rate > 5% or complete service outage; requires CTO-level escalation.

Alert channels: Email, SMS (for critical/emergency), Slack/Teams integration, dashboard notification.

---

## 14.5 Dashboards

Real-time dashboard displays:
- Pipeline throughput (images/minute).
- Queue depth per stage.
- GPU utilisation per node.
- Model performance metrics (latest evaluation).
- Quality metrics (approval rate, review rate, rejection rate).
- Drift indicators.

---

## 14.6 Engineering Rationale

Monitoring provides visibility into system health and model performance. Drift detection prevents silent degradation. Alert thresholds balance noise (false alerts) against urgency (missed problems).
