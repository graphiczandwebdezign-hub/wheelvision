# CHAPTER 10 — CONFIDENCE SCORING

## 10.1 Purpose

Defines how individual model outputs are combined into composite confidence scores that determine pipeline decisions (approve, review, reject).

---

## 10.2 Confidence Calculations

Every model stage produces a confidence score:

- Background segmentation: `conf_seg_bg` (IoU-based confidence estimate).
- Vehicle segmentation: `conf_seg_veh`.
- Wheel detection: `conf_wheel` (per wheel; lowest wheel score used).
- Keypoint detection: `conf_key` (mean of all keypoint confidences).
- Perspective estimation: `conf_persp` (based on keypoint residual error).
- Metadata validation: `conf_meta` (binary: 1.0 if passes, 0.0 if fails).

---

## 10.3 Weighted Composite Score

`Composite = (w1 × conf_seg_bg) + (w2 × conf_seg_veh) + (w3 × conf_wheel) + (w4 × conf_key) + (w5 × conf_persp) + (w6 × conf_meta) + (w7 × conf_quality)`

Weights:

| Component | Weight | Justification |
|---|---|---|
| Background Segmentation | 0.15 | Critical for mask quality |
| Vehicle Segmentation | 0.15 | Critical for body accuracy |
| Wheel Detection | 0.20 | Highest impact on rendering |
| Keypoint Detection | 0.15 | Critical for perspective |
| Perspective Estimation | 0.10 | Important but recoverable |
| Metadata Validation | 0.15 | Binary gate; must pass |
| Image Quality | 0.10 | Affects all downstream stages |

---

## 10.4 Thresholds and Business Rules

```mermaid
graph TD
    A[Compute Composite Score] --> B{Score >= 0.92?}
    B -->|Yes| C[Automatic Approval]
    B -->|No| D{Score >= 0.75?}
    D -->|Yes| E[Manual Review Queue]
    D -->|No| F[Reject - Log Reason]
    F --> G[Notify Admin / User]
```

- **Automatic Approval:** Composite >= 0.92; all individual component scores >= 0.80; quality score >= 0.85; no anomalies detected.
- **Manual Review:** Composite >= 0.75 but < 0.92; OR any component score < 0.80; OR quality score < 0.85; OR anomalies detected.
- **Automatic Rejection:** Composite < 0.75; OR metadata validation fails; OR image quality below minimum; OR corruption detected.

---

## 10.5 Failure Scenarios (Confidence)

| Scenario | Detection | Response |
|---|---|---|
| Model produces NaN confidence | NaN check in calculation | Replace with 0.0; trigger review |
| Composite score calculation error | Schema validation of score object | Log error; default to manual review |
| Threshold database unavailable | Connection timeout | Use cached thresholds (max 24h old); alert ops |

---

## 10.6 Engineering Rationale

Weighted composite scoring balances multiple quality dimensions. Binary gates (metadata validation) prevent structural errors. Tiered thresholds balance automation efficiency with commercial quality requirements.

---

*Chapter 10 complete. Confidence scoring fully defined with weights, thresholds, and decision logic.*
