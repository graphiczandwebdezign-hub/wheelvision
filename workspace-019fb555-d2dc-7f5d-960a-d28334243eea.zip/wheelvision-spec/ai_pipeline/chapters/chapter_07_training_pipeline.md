# CHAPTER 7 — TRAINING PIPELINE

## 7.1 Purpose

Defines the complete training workflow, validation, hyperparameter tuning, checkpointing, experiment tracking, hardware requirements, and promotion/rollback strategies.

---

## 7.2 Training Workflow

```mermaid
graph LR
    A[Load Dataset vX.Y.Z] --> B[Split Train/Val/Test]
    B --> C[Initialize Model]
    C --> D[Train Epoch]
    D --> E[Validate]
    E --> F{Improvement?}
    F -->|Yes| G[Checkpoint]
    F -->|No| H[Early Stop?]
    H -->|No| D
    H -->|Yes| I[Select Best Checkpoint]
    I --> J[Evaluate Test Set]
    J --> K[Generate Metrics Report]
    K --> L[Promote to Registry]
```

---

## 7.3 Validation Workflow

Every training epoch produces validation metrics (IoU, mAP, RMSE). Best model selected based on primary metric (composite score combining accuracy and latency predictions). Validation performed on held-out dataset (never seen during training).

---

## 7.4 Hyperparameter Tuning

Search method: Bayesian optimization (Optuna) over hyperparameter space:

| Hyperparameter | Range | Type | Impact |
|---|---|---|---|
| Learning Rate | 1e-5 to 1e-3 | Log scale | Convergence speed |
| Batch Size | 4 to 32 | Integer | Memory, gradient stability |
| Backbone Freeze | 0% to 100% | Percentage | Transfer learning strength |
| Augmentation Intensity | 0.0 to 1.0 | Continuous | Generalization |

---

## 7.5 Checkpoint Strategy

Checkpoints saved every epoch with best model retained separately. Checkpoints include: model weights, optimizer state, epoch number, training metrics, dataset version hash, random seed. Storage: `/checkpoints/{experiment_id}/`.

---

## 7.6 Experiment Tracking

Every training run tracked in experiment registry (MLflow or equivalent):

- Experiment ID
- Dataset version
- Model architecture
- Hyperparameters
- Training duration
- GPU utilization
- Final metrics (validation and test)
- Model weights path
- Promotion status

---

## 7.7 GPU Requirements

| Component | GPU Model | Memory | Nodes Required |
|---|---|---|---|
| Training (Large Models) | NVIDIA A100 or H100 | 40GB+ | 4 (distributed) |
| Training (Medium Models) | NVIDIA V100 | 32GB | 2 |
| Validation / Testing | NVIDIA A10G | 24GB | 1 |
| Inference (Production) | NVIDIA T4 or A10G | 16–24GB | Auto-scaled |

---

## 7.8 Model Registry

Every promoted model includes:
- Semantic version number.
- Dataset version linkage.
- Performance metrics.
- Training configuration.
- Rollback reference (previous version).
- Compatibility matrix (supported image formats, minimum resolutions, known limitations).

---

## 7.9 Promotion Rules

Model promoted from training to registry when:
- Validation metric exceeds previous production model by >= 2% relative improvement OR matches with >= 5% latency reduction.
- No degradation in any secondary metric (recall must not drop > 1%).
- Security review passed (no data leakage in weights).
- Human review of sample outputs confirms quality.

Rollback triggered when:
- Production error rate increases > 0.5% above baseline.
- Customer reports of incorrect assets exceed threshold.
- Security vulnerability discovered in model.

---

## 7.10 Engineering Rationale (Training)

Reproducible training requires dataset linkage, checkpoint persistence, and experiment tracking. Promotion rules prevent deploying models that improve one metric at the expense of others. GPU requirements are specified for capacity planning.

---

*Chapter 7 complete. Training pipeline fully specified with tuning, tracking, promotion, and rollback.*
