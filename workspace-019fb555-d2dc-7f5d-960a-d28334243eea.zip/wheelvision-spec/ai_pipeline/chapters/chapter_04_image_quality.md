# CHAPTER 4 — IMAGE QUALITY ASSESSMENT

## 4.1 Purpose

Defines the complete quality assessment architecture that determines whether an image is suitable for automated processing.

---

## 4.2 Image Quality Metrics

Every image receives a quantitative quality score (0.0–1.0) derived from sub-metrics:

| Metric | Method | Weight | Threshold (Auto-Approve) | Threshold (Review Required) |
|---|---|---|---|---|
| Sharpness | Laplacian variance | 0.20 | >= 0.85 | < 0.70 |
| Noise Level | Standard deviation of flat regions | 0.15 | <= 0.15 (low noise) | > 0.30 (high noise) |
| Exposure | Histogram analysis (mean brightness) | 0.15 | 0.35 <= mean <= 0.75 | Outside range |
| Contrast | Michelson contrast of edges | 0.10 | >= 0.40 | < 0.20 |
| Occlusion | Object detection overlap score | 0.15 | <= 0.10 (minimal occlusion) | > 0.30 (significant occlusion) |
| Reflection | Highlight detection + classification | 0.10 | <= 0.05 (no significant reflection) | > 0.20 |
| Rain / Water Drops | Edge texture + droplet detection | 0.05 | <= 0.05 | > 0.15 |
| Night / Low Light | Mean brightness + noise correlation | 0.10 | Mean > 0.15 (not night) | Mean < 0.10 (night) |

---

## 4.3 Blur Detection

**Method:** Laplacian variance. Higher variance = sharper image. Low variance (< 100) indicates significant blur.

**Engineering Rationale:** Laplacian variance is computationally efficient and well-correlated with human perception of sharpness. Trade-off: May misclassify intentionally soft-focus artistic images as blurry; acceptable because pipeline requires sharp technical images.

**Implementation:** Compute `cv2.Laplacian(image, cv2.CV_64F).var()`. Normalize against image resolution and content complexity.

---

## 4.4 Noise Detection

**Method:** Measure standard deviation of pixel values in flat (low-gradient) regions identified by edge detection.

**Engineering Rationale:** Flat regions should have low variance; high variance indicates noise. Trade-off: Textured surfaces (e.g., rough ground) may falsely indicate noise; mitigated by selecting flat regions via gradient threshold.

---

## 4.5 Occlusion Detection

**Method:** Instance segmentation model detects non-vehicle objects (trees, poles, people, other vehicles) overlapping with the primary vehicle bounding box. Overlap ratio computed as intersection area / vehicle bounding box area.

**Thresholds:** Overlap < 10%: minimal occlusion (auto-approve). Overlap 10–30%: moderate occlusion (review). Overlap > 30%: significant occlusion (reject or manual processing).

---

## 4.6 Reflection Detection

**Method:** Highlight detection (pixels > 250 in all RGB channels) combined with geometric analysis. Large bright regions with sharp boundaries that align with known reflective surfaces (glass, metal) are classified as reflections.

**Engineering Rationale:** Reflections distort vehicle appearance and interfere with segmentation accuracy. Trade-off: Bright sunlight spots may be misclassified as reflections; mitigated by shape analysis (reflections tend to have elongated or irregular shapes).

---

## 4.7 Image Scoring Aggregation

Composite quality score = weighted sum of normalized sub-metrics:

`Q_total = Σ (w_i × q_i_normalized)`

Where `w_i` are the weights from Section 4.2 and `q_i_normalized` are scores normalized to [0, 1].

---

## 4.8 Quality Decision Logic

```mermaid
graph TD
    A[Compute Sub-Metrics] --> B[Calculate Q_total]
    B --> C{Q_total >= 0.85?}
    C -->|Yes| D[Proceed to CV Pipeline]
    C -->|No| E{Q_total >= 0.65?}
    E -->|Yes| F[Flag for Review - Continue with Warning]
    E -->|No| G[Reject Image - Log Reason]
    G --> H[Notify User / Admin]
```

---

## 4.9 Validation Rules

Every quality assessment must include:
- Individual metric scores (not just composite).
- Normalized values for comparison.
- Threshold comparison results.
- Final decision (approve/review/reject) with justification.
- Audit log entry with all scores and decision.

---

## 4.10 Performance Targets

- Quality assessment latency: < 500ms per image (CPU-based, no GPU required).
- Memory usage: < 512MB during assessment.
- Batch throughput: >= 100 images per minute per instance.

---

## 4.11 Failure Scenarios (Quality Assessment)

| Scenario | Detection | Response | Recovery |
|---|---|---|---|
| Corrupt EXIF | EXIF parser exception | Use default values; reduce confidence | Log warning; proceed |
| Extremely dark image | Mean brightness < 0.05 | Reject; notify user | User provides alternative image |
| Highly occluded vehicle | Overlap > 50% | Reject; log occlusion type | Manual processing or new upload |
| Reflection dominates | Reflection score > 0.40 | Flag for manual correction of mask | Human review |
| Quality assessment service crash | Health check failure | Restart service; replay queue | Service recovery |

---

## 4.12 Engineering Rationale (Quality Assessment)

Quality assessment acts as the defensive gate protecting expensive GPU processing from low-quality inputs. Without this stage, poor images would consume CV resources and produce unreliable outputs. The weighted scoring system provides granular control and auditability.

---

## 4.13 Trade-offs and Alternatives

**Alternative A — Single Metric (Sharpness Only):** Simpler but misses occlusion, exposure, reflection. Selected approach uses multiple metrics for robustness.
**Alternative B — Deep Learning Quality Estimator:** Train a model to predict image suitability. Trade-off: Higher accuracy but requires labeled training data, longer inference time, and less interpretability. Selected approach uses classical CV metrics for speed and transparency.

---

*Chapter 4 complete. Quality assessment fully defined with 8 sub-metrics, aggregation formula, and decision logic.*
