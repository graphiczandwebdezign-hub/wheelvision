# APPENDIX G: COMPLETE COMPONENT HIERARCHY DOCUMENTATION

## G.1 Root Layout Component (`app/layout.tsx`)

**Props:** None (server component with children)
**Providers:** `TenantProvider`, `AuthProvider`, `ThemeProvider`
**Output:** HTML shell with meta tags, font loading, global CSS
**Performance:** Server-rendered; no JavaScript required for initial paint

---

## G.2 PreviewCanvas Component (`components/PreviewCanvas.tsx`)

**Props:**
- `vehicle: VehicleData`
- `wheelVariant: WheelVariantData`
- `tyreSize: TyreSizeData`
- `showLabels: boolean` (default: true)
- `onExport: () => void`

**State:** Internal Konva stage reference; layer list
**Side Effects:** Loads asset URLs; constructs scene graph; applies transformations
**Performance:** Caches layer pixels; disables event listening on static layers
**Error Handling:** Displays placeholder image for missing assets; logs error to console and analytics

---

## G.3 VehicleSelector Component (`components/VehicleSelector.tsx`)

**Props:**
- `selectedVehicleId: string | null`
- `onSelect: (vehicleId: string) => void`
- `categoryFilter: string[]`

**Data Source:** TanStack Query (`useVehicles` hook)
**UI:** Dropdown or grid gallery using shadcn/ui components
**Accessibility:** ARIA labels, keyboard navigation, focus management

---

## G.4 QuoteGenerator Component (`components/QuoteGenerator.tsx`)

**Props:**
- `quoteData: QuoteData`
- `dealerBranding: BrandConfig`
- `format: 'pdf' | 'email' | 'whatsapp'`

**Output:** Generated file, email payload, or WhatsApp message payload
**Validation:** Zod schema validation on quote data before generation
**Performance:** Uses server-side rendering for PDF; async processing for email/WhatsApp

Every component includes props definitions, state behavior, data sources, performance characteristics, accessibility requirements, and error handling rules.
