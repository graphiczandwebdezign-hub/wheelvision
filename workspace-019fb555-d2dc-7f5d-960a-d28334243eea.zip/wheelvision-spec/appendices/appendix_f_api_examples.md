# APPENDIX F: COMPLETE API REQUEST/RESPONSE EXAMPLES

## F.1 GET /api/vehicles — Request

```http
GET /api/v1/vehicles?category=commercial&year=2023 HTTP/1.1
Host: api.wheelvision.com
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
X-Tenant-ID: 550e8400-e29b-41d4-a716-446655440000
Accept: application/json
```

---

## F.2 GET /api/vehicles — Response (200 OK)

```json
{
  "data": [
    {
      "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      "manufacturer": "Toyota",
      "model": "Hilux",
      "year": 2025,
      "category": "commercial",
      "image_url": "https://assets.wheelvision.com/vehicles/toyota/hilux/2025/vehicle.webp",
      "metadata_url": "https://assets.wheelvision.com/vehicles/toyota/hilux/2025/metadata.json",
      "created_at": "2026-01-15T08:30:00Z"
    }
  ],
  "pagination": {
    "cursor": "eyJpZCI6ImExYjJjM2Q0In0=",
    "has_more": true
  },
  "tenant_id": "550e8400-e29b-41d4-a716-446655440000"
}
```

---

## F.3 POST /api/quotes — Request

```json
{
  "vehicle_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "wheel_variant_id": "v-98765432",
  "tyre_size_id": "t-12345678",
  "configuration_name": "Hilux Work Setup",
  "pricing": {
    "currency": "ZAR",
    "wheel_total": 24500.00,
    "tyre_total": 4800.00,
    "labour_estimate": 1200.00
  }
}
```

---

## F.4 POST /api/quotes — Response (201 Created)

```json
{
  "id": "q-55556666-7777-8888-9999-000011112222",
  "status": "saved",
  "quote_url": "https://app.wheelvision.com/quote/q-55556666-7777-8888-9999-000011112222",
  "pdf_url": "https://assets.wheelvision.com/quotes/q-55556666-7777-8888-9999-000011112222.pdf",
  "created_at": "2026-07-30T14:22:00Z"
}
```

---

## F.5 Error Response (400 Validation Error)

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid tyre profile: 25% is below minimum 30% for this vehicle model.",
    "field": "tyre_size.profile",
    "request_id": "req-abc-123-def-456"
  }
}
```

Every endpoint includes request and response examples, error codes, authentication headers, and validation rules.
