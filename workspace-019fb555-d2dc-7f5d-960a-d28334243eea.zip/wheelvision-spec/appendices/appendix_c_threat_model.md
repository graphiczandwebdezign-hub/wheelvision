# APPENDIX C: SECURITY THREAT MODEL

## C.1 Threat: Cross-Tenant Data Access (Critical)

**Attack Vector:** Malicious user modifies `tenant_id` in API request.  
**Defense:** RLS policies enforce `tenant_id = current_setting('app.current_tenant_id')` on every query. Middleware validates JWT claim against subdomain/header.  
**Verification:** pgTap automated tests confirm unauthorized SELECT returns zero rows.

---

## C.2 Threat: SQL Injection (Critical)

**Attack Vector:** User input embedded in SQL query string.  
**Defense:** All queries use parameterized statements via Supabase client (`db.from(...).select(...)`). No string concatenation for query construction.

---

## C.3 Threat: Cross-Site Scripting (XSS) (High)

**Attack Vector:** Malicious script injected through user input (quote name, brand name).  
**Defense:** React automatic escaping. Zod validation rejects unexpected types. Content Security Policy restricts script sources.

---

## C.4 Threat: Server-Side Request Forgery (SSRF) (Medium)

**Attack Vector:** Asset URL points to internal service (`http://localhost/admin`).  
**Defense:** All URLs validated against allowlist patterns. Server-side fetch restricted to `https://` URLs with allowed hostnames.

---

## C.5 Threat: File Upload Malware (Medium)

**Attack Vector:** User uploads executable disguised as WebP.  
**Defense:** File type verified by magic bytes, not extension. Size limits enforced. Virus scanning integrated.
