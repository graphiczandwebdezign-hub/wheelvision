# APPENDIX D: SYSTEM INTEGRATION PROTOCOL SPECIFICATION

## D.1 Purpose

This appendix defines every integration protocol, message format, authentication mechanism, error response, retry strategy, timeout value, and data transformation rule for all external systems interacting with WheelVision. There is zero ambiguity regarding how the platform communicates with the outside world.

---

## D.2 Supabase Integration Protocol

### D.2.1 Connection Protocol

- **Protocol:** PostgreSQL wire protocol over TLS 1.3
- **Host:** Configured via `SUPABASE_DB_HOST` environment variable
- **Port:** 5432
- **SSL Mode:** `require` (enforced)
- **Connection Pool Size:** 25 per application instance
- **Connection Timeout:** 5,000ms
- **Idle Timeout:** 30,000ms
- **Query Timeout:** 10,000ms (enforced by middleware; queries exceeding this return 408 Request Timeout)

### D.2.2 Authentication Protocol (Supabase Auth)

- **JWT Algorithm:** HS256 (HMAC with SHA-256)
- **JWT Secret:** Stored in `SUPABASE_JWT_SECRET` (never exposed to clients)
- **Access Token Lifetime:** 3,600 seconds (1 hour)
- **Refresh Token Lifetime:** 604,800 seconds (7 days)
- **Refresh Rotation:** Enabled (new refresh token issued on every refresh)
- **Cookie Attributes:** `HttpOnly`, `Secure`, `SameSite=Lax`, `Path=/`
- **Session Storage:** Client cookie only (no server-side session store for stateless operation)

### D.2.3 Row-Level Security Protocol

Every query executed through the Supabase client includes an implicit `WHERE tenant_id = ...` clause enforced by PostgreSQL RLS. The middleware sets `request.headers.set('x-tenant-id', tenantId)` which is translated to `SET app.current_tenant_id = '...'` before query execution. If the middleware fails to set this value, the query executes with `null` and RLS denies all access (default deny policy).

---

## D.3 Cloudflare R2 Integration Protocol

### D.3.1 Storage Protocol

- **API Compatibility:** Amazon S3 API v4 (compatible with AWS SDK, boto3, and native `fetch` with signed headers)
- **Endpoint Pattern:** `https://<account-id>.r2.cloudflarestorage.com/wheelvision-assets/<bucket-path>`
- **Authentication:** Signed URLs using HMAC-SHA256 (temporary credentials generated server-side)
- **URL Expiration:** 3,600 seconds (1 hour) for public assets; 300 seconds (5 minutes) for admin uploads
- **Content-Type Validation:** All uploads validated against `Content-Type` header and file magic bytes; mismatches result in immediate rejection (HTTP 400)
- **Maximum Object Size:** 50MB (vehicle images must not exceed this; videos, if added in future, have separate limits)
- **Bucket Naming:** `wheelvision-assets-production`, `wheelvision-assets-staging`
- **Lifecycle Policy:** Objects in `staging/` deleted after 30 days of inactivity. Objects in `archive/` retained for 7 years.

### D.3.2 CDN Delivery Protocol

- **Cache Key Pattern:** `<asset-path>?v=<version-hash>`
- **Cache-Control Headers:** `public, max-age=31536000, immutable` for versioned assets; `public, max-age=3600, must-revalidate` for unversioned assets
- **Edge Cache Purge:** Triggered via Cloudflare API (`POST /zones/{zone_id}/purge_cache`) upon asset update
- **Compression:** Brotli compression (`br`) preferred; Gzip (`gzip`) fallback; uncompressed available for clients without compression support
- **Image Optimization:** Cloudflare Polish (WebP conversion) enabled for all image assets

---

## D.4 Email Service Integration Protocol

### D.4.1 SMTP Protocol Configuration

- **Server:** `smtp.sendgrid.net` (primary) or `smtp.mailgun.org` (failover)
- **Port:** 587 (TLS/STARTTLS required; port 465 SSL deprecated)
- **Authentication:** API Key (SendGrid) or Domain Key + API Key (Mailgun)
- **Connection Timeout:** 10,000ms
- **Send Timeout:** 30,000ms per message
- **Retry Strategy:** Exponential backoff: 2s, 4s, 8s, 16s (4 retries maximum before message queued for manual review)

### D.4.2 Email Template Format

Templates are stored as JSON objects in the database (`email_templates` table) with the following structure:

```json
{
  "template_id": "quote_email_v1",
  "subject": "Your WheelVision Quotation — {{dealer_name}}",
  "body_html": "<html>...</html>",
  "body_text": "Plain text version...",
  "variables": ["dealer_name", "quote_id", "vehicle_model", "total_price"],
  "tenant_id": "uuid"
}
```

Variables are substituted server-side using safe string interpolation (no template injection permitted). HTML is sanitized using a strict allowlist of tags (`<a>`, `<b>`, `<i>`, `<br>`, `<table>`, `<tr>`, `<td>`, `<img>` with `src` restricted to `https://`).

---

## D.5 WhatsApp Business API Integration Protocol

### D.5.1 API Endpoint

- **Base URL:** `https://graph.facebook.com/v18.0/{phone-number-id}/messages`
- **Authentication:** Bearer token (`WHATSAPP_ACCESS_TOKEN`) included in `Authorization` header
- **Content-Type:** `application/json`
- **Rate Limit:** 80 messages per minute per phone number (enforced by Meta; WheelVision implements additional client-side rate limiting of 60/min)

### D.5.2 Message Format

Every WhatsApp quotation message must include:
1. A text header: `"Your WheelVision quote from {{dealer_name}} is ready!"`
2. A link preview: URL pointing to the saved quote (`https://wheelvision.com/quote/{quote_uuid}`)
3. Optional image attachment: Quotation preview image (JPEG, max 5MB, max resolution 1280x960)

The message payload structure:

```json
{
  "messaging_product": "whatsapp",
  "to": "{{customer_phone_number}}",
  "type": "text",
  "text": {
    "preview_url": true,
    "body": "Your quote from {{dealer_name}}: {{quote_link}}"
  }
}
```

Phone numbers must be validated against E.164 format (`+27123456789`) before sending. Invalid numbers return HTTP 400 with error code `invalid_phone_number`.

---

## D.6 PDF Generation Integration Protocol

### D.6.1 Generation Service

PDF generation uses a server-side headless browser (Puppeteer or Playwright) running in a dedicated Vercel Edge Function or separate container.

- **Engine:** Chromium (headless mode, `--no-sandbox` for containerized environments)
- **Page Size:** A4 (210mm x 297mm) or Letter (8.5in x 11in) based on tenant locale setting
- **Margin:** 10mm on all sides
- **DPI:** 300 (high quality for commercial printing)
- **CSS Print Media:** Custom `@media print` rules hide interactive elements, expand quote details, and include footer branding

### D.6.2 Generation Pipeline

1. Client requests PDF (`POST /api/quotes/{id}/pdf`)
2. Server retrieves quote data and renders HTML template
3. HTML passed to headless browser
4. Browser renders at 300 DPI
5. PDF saved temporarily to `/tmp/` (auto-deleted after 24 hours)
6. PDF returned to client as `Content-Type: application/pdf` with `Content-Disposition: attachment; filename="quote-{{id}}.pdf"`

---

## D.7 Engineering Rationale (Integration)

Every integration protocol is fully specified to eliminate ambiguity during development and maintenance. Protocol specifications include timeouts, retry strategies, error codes, authentication mechanisms, and message formats. This ensures that new developers or AI agents can implement or modify integrations without consulting external documentation.
