# APPENDIX E: VISUAL DESIGN SYSTEM SPECIFICATION

## E.1 Color Tokens

| Token | HEX | RGB | Usage |
|---|---|---|---|
| `--color-primary` | `#1e293b` | 30,41,59 | Primary text, headers |
| `--color-secondary` | `#475569` | 71,85,105 | Secondary text |
| `--color-accent` | `#f59e0b` | 245,158,11 | Action buttons, highlights |
| `--color-background` | `#f8fafc` | 248,250,252 | Page background |
| `--color-surface` | `#ffffff` | 255,255,255 | Cards, panels |
| `--color-border` | `#e2e8f0` | 226,232,240 | Dividers, borders |

---

## E.2 Typography Scale

| Token | Size (rem) | Weight | Line Height | Usage |
|---|---|---|---|---|
| `text-xs` | 0.75 | 400 | 1.5 | Captions, labels |
| `text-sm` | 0.875 | 400 | 1.5 | Body text |
| `text-base` | 1.0 | 400 | 1.6 | Default body |
| `text-lg` | 1.125 | 500 | 1.5 | Subheadings |
| `text-xl` | 1.25 | 600 | 1.4 | Section headings |
| `text-2xl` | 1.5 | 700 | 1.3 | Page titles |

---

## E.3 Spacing Scale

| Token | Rem | Pixels | Usage |
|---|---|---|---|
| `space-1` | 0.25 | 4px | Minimal gaps |
| `space-2` | 0.5 | 8px | Component padding |
| `space-3` | 0.75 | 12px | Small margins |
| `space-4` | 1.0 | 16px | Standard spacing |
| `space-6` | 1.5 | 24px | Section gaps |
| `space-8` | 2.0 | 32px | Large sections |

---

## E.4 Component Variants

Every shadcn/ui component includes variants:
- `default`: Standard appearance
- `destructive`: Error/warning actions (red accent)
- `outline`: Secondary actions (border only)
- `ghost`: Minimal actions (no background)
- `link`: Inline text links

---

## E.5 Engineering Rationale (Design System)

A defined design system eliminates visual inconsistency. Token-based styling ensures that any theme change (e.g., white-label customization) only requires updating token values, not individual component styles. The scale is mathematically consistent (base 4, multiples of 2).
