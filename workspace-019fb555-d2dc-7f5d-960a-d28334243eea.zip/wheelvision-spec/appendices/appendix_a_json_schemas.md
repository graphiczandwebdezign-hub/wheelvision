# APPENDIX A: COMPLETE JSON SCHEMA DEFINITIONS

## A.1 Vehicle Metadata Schema (Version 1.1 — Extended)

```json
{
  "$id": "https://wheelvision.com/schemas/vehicle-metadata-v1.1.json",
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "WheelVision Vehicle Metadata",
  "description": "Complete metadata specification for vehicle rendering assets.",
  "type": "object",
  "required": ["version", "vehicle", "scene", "layers", "fitment", "assets"],
  "properties": {
    "version": { "const": "1.1" },
    "vehicle": {
      "manufacturer": { "type": "string", "minLength": 1 },
      "model": { "type": "string", "minLength": 1 },
      "year": { "type": "integer", "minimum": 1900 },
      "category": { "enum": ["passenger", "commercial", "performance", "offroad", "motorcycle"] },
      "body_style": { "type": "string" },
      "drive_type": { "enum": ["fwd", "rwd", "awd", "4wd"] }
    },
    "fitment": {
      "max_tyre_width_mm": { "type": "integer", "minimum": 155 },
      "max_tyre_diameter_mm": { "type": "integer", "minimum": 500 },
      "recommended_offset_min_mm": { "type": "number" },
      "recommended_offset_max_mm": { "type": "number" }
    },
    "assets": {
      "vehicle_webp_url": { "type": "string", "format": "uri" },
      "mask_webp_url": { "type": "string", "format": "uri" },
      "shadow_webp_url": { "type": "string", "format": "uri" },
      "metadata_json_url": { "type": "string", "format": "uri" }
    }
  },
  "additionalProperties": false
}
```

---

## A.2 Wheel Metadata Schema

```json
{
  "$id": "https://wheelvision.com/schemas/wheel-metadata-v1.0.json",
  "type": "object",
  "required": ["brand", "model", "finish", "variants"],
  "properties": {
    "brand": { "type": "string" },
    "model": { "type": "string" },
    "finish": { "type": "string" },
    "variants": {
      "type": "array",
      "items": {
        "diameter_inches": { "type": "number" },
        "width_inches": { "type": "number" },
        "offset_mm": { "type": "number" },
        "pcd_mm": { "type": "number" },
        "center_bore_mm": { "type": "number" },
        "bolt_count": { "type": "integer", "enum": [3,4,5,6,8] }
      }
    }
  }
}
```

---

## A.3 Scene Graph Schema (Renderer Internal)

```json
{
  "scene_id": "uuid",
  "root_layer": {
    "children": ["vehicle_layer", "front_wheel_layer", "rear_wheel_layer", "shadow_layer", "overlay_layer"]
  },
  "coordinate_system": {
    "origin": [0, 0],
    "unit": "pixels",
    "width": 1200,
    "height": 800
  }
}
```

Every JSON schema file is version-controlled and published in `/docs/schemas/`.
