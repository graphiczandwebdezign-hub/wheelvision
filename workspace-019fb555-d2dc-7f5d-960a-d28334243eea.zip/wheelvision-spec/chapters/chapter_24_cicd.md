# CHAPTER 24

# CI/CD

## 24.1 Purpose

Defines the complete continuous integration and continuous deployment pipeline: GitHub Actions, linting, formatting, testing, preview deployments, production deployments, and rollback strategies.

---

## 24.2 GitHub Actions

Every pull request triggers: lint (`ESLint`), format (`Prettier`), type check (`tsc --noEmit`), unit tests, integration tests, and security tests (`pgTap`).

---

## 24.3 Preview Deployments

Every branch creates a Vercel preview deployment with a unique URL. Preview deployments allow manual testing before merging.

---

## 24.4 Production Deployments

Merges to `main` trigger production builds on Vercel. The deployment is atomic — no partial updates are visible to users.

---

## 24.5 Rollback Strategy

If a production deployment fails, Vercel enables instant rollback to the previous version. Database migrations include `down` scripts for emergency rollback.

---

## 24.6 Engineering Rationale

Automated CI/CD eliminates human error in deployment. Every change is validated before reaching production. Rollback capability ensures rapid recovery.

*Chapter 24 complete.*
