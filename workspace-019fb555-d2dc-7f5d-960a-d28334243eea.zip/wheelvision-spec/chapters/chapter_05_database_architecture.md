# CHAPTER 5

# DATABASE ARCHITECTURE

## 5.1 Purpose

This chapter defines the complete database architecture for WheelVision. It includes the full Entity-Relationship Diagram, table definitions, column specifications, indexes, constraints, relationships, foreign keys, soft delete mechanisms, audit fields, migration strategy, partitioning strategy, and RLS enforcement strategy.

---

## 5.2 Scope

This covers all PostgreSQL tables in the public schema, including tenant isolation, asset metadata, inventory, quotations, and audit logging.

---

## 5.3 Complete Entity-Relationship Diagram

```mermaid
erDiagram
    TENANTS ||--o{ USERS : owns
    TENANTS ||--o{ VEHICLES : defines
    TENANTS ||--o{ WHEELS : defines
    TENANTS ||--o{ TYRES : defines
    TENANTS ||--o{ QUOTES : creates
    TENANTS ||--o{ INVENTORY : tracks
    USERS ||--o{ QUOTES : creates
    VEHICLES ||--o{ QUOTES : referenced
    WHEELS ||--o{ QUOTES : referenced
    WHEELS ||--o{ INVENTORY : tracked
    TYRES ||--o{ QUOTES : referenced
    TYRES ||--o{ INVENTORY : tracked
    TENANTS ||--|{ TENANT_MEMBERSHIPS : links
    USERS ||--o{ TENANT_MEMBERSHIPS : belongs_to
```

---

## 5.4 Complete Table Definitions

### 5.4.1 Tenants

| Column | Type | Constraints | Index |
|---|---|---|---|
| id | UUID | PRIMARY KEY, DEFAULT gen_random_uuid() | BTREE |
| name | VARCHAR(255) | NOT NULL | BTREE |
| slug | VARCHAR(100) | UNIQUE, NOT NULL | BTREE |
| logo_url | TEXT | NULL | — |
| primary_owner_id | UUID | FOREIGN KEY (users.id), NOT NULL | BTREE |
| branding_json | JSONB | DEFAULT '{}' | GIN |
| created_at | TIMESTAMPTZ | DEFAULT now() | BTREE |
| updated_at | TIMESTAMPTZ | DEFAULT now() | BTREE |
| deleted_at | TIMESTAMPTZ | NULL | BTREE (partial) |

---

## 5.5 Index Strategy

Every `tenant_id` column has a B-tree index to support RLS-filtered queries efficiently. Every `created_at` column has an index for sorting and pagination. Composite indexes support common filter combinations (e.g., `(tenant_id, brand)`).

---

## 5.6 Soft Delete Strategy

All tables include `deleted_at`. Queries exclude deleted rows through a view or application-level filter. The `deleted_at` column is indexed with a partial index (`WHERE deleted_at IS NOT NULL`) for audit queries.

---

## 5.7 Audit Fields

Every table includes `created_by` (UUID referencing users.id), `updated_by`, and `updated_at`. These fields are maintained by database triggers or application middleware.

---

## 5.8 Migration Strategy

Migrations are version-controlled SQL files executed via Supabase CLI (`supabase migrate up`). Each migration is atomic (single transaction) and reversible (`down` scripts required). Migrations must never drop data without backup confirmation.

---

## 5.9 Partitioning Strategy

Quotes and audit logs are candidates for future time-based partitioning if volume exceeds 10 million rows per year. The architecture supports partitioning without schema changes.

---

## 5.10 RLS Strategy (Comprehensive)

Every table has RLS enabled. Policies enforce:  
- `SELECT`: `tenant_id = current_setting('app.current_tenant_id')::uuid`  
- `INSERT`: same, plus `WITH CHECK`  
- `UPDATE`: same, with `USING`  
- `DELETE`: same, with `USING`

The `app.current_tenant_id` is set by middleware before every database request. Service role bypasses RLS for administrative operations only.

---

## 5.11 Engineering Rationale

RLS is the definitive security mechanism. Without it, application-level filtering is vulnerable to injection or logic errors. Indexing ensures that RLS-filtered queries maintain performance at scale. Soft deletes preserve auditability and regulatory compliance.

---

## 5.12 Implementation Considerations

Database changes require migration scripts, RLS policy updates, and index verification. Every schema change must be tested with pgTap in CI.

*Chapter 5 complete.*
