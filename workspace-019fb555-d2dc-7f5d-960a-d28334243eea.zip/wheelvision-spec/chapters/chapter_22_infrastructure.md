# CHAPTER 22

# INFRASTRUCTURE

## 22.1 Purpose

Defines deployment infrastructure: Vercel hosting, Supabase database, Cloudflare R2 storage, DNS configuration, environment variables, monitoring, logging, backups, and disaster recovery.

---

## 22.2 Vercel

Vercel hosts the Next.js application. It provides automatic deployments, preview URLs, and serverless function scaling.

---

## 22.3 Supabase

Supabase provides PostgreSQL hosting, authentication, and storage (initially; R2 replaces storage for assets). Continuous backups are enabled.

---

## 22.4 Cloudflare R2

R2 provides scalable, zero-egress object storage for assets.

---

## 22.5 DNS and Environment Variables

DNS is managed through a domain registrar with CNAME/A records pointing to Vercel. Environment variables are managed in Vercel dashboard and never exposed to clients.

---

## 22.6 Monitoring and Logging

Sentry monitors front-end errors. Supabase logs track database performance. Vercel Analytics tracks request metrics.

---

## 22.7 Backups and Disaster Recovery

Database backups: daily full, continuous WAL archiving. Asset backups: R2 replication. Disaster recovery plan: restore database from point-in-time, redeploy application, redirect DNS.

---

## 22.8 Engineering Rationale

Infrastructure choices prioritise reliability, scalability, and cost efficiency. Vercel eliminates server maintenance. R2 eliminates egress costs. Supabase provides managed PostgreSQL with built-in security.

*Chapter 22 complete.*
