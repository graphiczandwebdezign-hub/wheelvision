# CHAPTER 6

# METADATA SPECIFICATION

## 6.1 Purpose

This chapter defines the complete JSON metadata schema that drives the rendering engine. Every vehicle, wheel, and configuration must be fully described by metadata — no code references allowed.

---

## 6.2 Scope

Covers: vehicle metadata, wheel metadata, scene metadata, versioning strategy, validation rules, backward compatibility, and future extensibility.

---

## 6.3 Complete JSON Schema — Vehicle Metadata

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["version", "vehicle", "scene", "layers"],
  "properties": {
    "version": { "type": "string", "enum": ["1.0", "1.1"] },
    "vehicle": {
      "manufacturer": { "type": "string" },
      "model": { "type": "string" },
      "year": { "type": "integer" },
      "category": { "type": "string", "enum": ["passenger", "commercial", "performance", "offroad"] }
    },
    "scene": {
      "width": { "type": "integer" },
      "height": { "type": "integer" },
      "background_color": { "type": "string" }
    },
    "layers": {
      "vehicle": { "image_url": { "type": "string" }, "mask_url": { "type": "string" } },
      "front_wheel": { "x": { "type": "number" }, "y": { "type": "number" }, "scale_reference": { "type": "number" } },
      "rear_wheel": { "x": { "type": "number" }, "y": { "type": "number" }, "scale_reference": { "type": "number" } },
      "shadow": { "image_url": { "type": "string" }, "opacity": { "type": "number" } }
    },
    "wheels": {
      "diameter_pixels": { "type": "number" },
      "rotation_angle_degrees": { "type": "number" }
    }
  }
}
```

---

## 6.4 Example — Complete Vehicle Metadata

```json
{
  "version": "1.0",
  "vehicle": { "manufacturer": "Toyota", "model": "Hilux", "year": 2025, "category": "commercial" },
  "scene": { "width": 1200, "height": 800, "background_color": "#f8fafc" },
  "layers": {
    "vehicle": { "image_url": "/assets/vehicles/toyota/hilux/2025/vehicle.webp", "mask_url": "/assets/vehicles/toyota/hilux/2025/mask.webp" },
    "front_wheel": { "x": 420, "y": 520, "scale_reference": 1.0 },
    "rear_wheel": { "x": 780, "y": 520, "scale_reference": 1.0 },
    "shadow": { "image_url": "/assets/vehicles/toyota/hilux/2025/shadow.webp", "opacity": 0.35 }
  },
  "wheels": { "diameter_pixels": 340, "rotation_angle_degrees": 0 }
}
```

---

## 6.5 Validation Rules

Every metadata file must pass:
1. JSON Schema validation against the versioned schema.
2. URL validation for all image references (must resolve within 5 seconds).
3. Coordinate validation (all values within scene dimensions).
4. Version compatibility check.

---

## 6.6 Versioning and Backward Compatibility

The schema includes a `version` field. New versions are additive only. Old versions remain supported indefinitely. Migration scripts convert old metadata to new versions automatically.

---

## 6.7 Future Vehicle Support

To add a new vehicle:
1. Upload assets to `/assets/vehicles/{manufacturer}/{model}/{year}/`.
2. Create `metadata.json` according to the schema.
3. Insert database record referencing the asset paths.
4. No renderer code is modified. The renderer loads the new metadata and renders the scene automatically.

---

## 6.8 Engineering Rationale

A strict JSON Schema eliminates ambiguity. Version control ensures future compatibility. The example demonstrates how a complete vehicle is defined purely by data. This architecture eliminates the need for per-vehicle engineering work.

---

## 6.9 Implementation Considerations

Validation must run on asset upload. Metadata files must be stored in version control (Git) as well as referenced in the database. The renderer must handle missing assets gracefully (show placeholder, log error).

*Chapter 6 complete.*
