# CHAPTER 2

# PRODUCT REQUIREMENTS SPECIFICATION

## 2.1 Purpose

This chapter defines the complete functional and non-functional requirements for the WheelVision Enterprise Multi-Tenant SaaS platform. It provides the authoritative reference for all engineering, product, and quality assurance activities. Every requirement is numbered, traceable, and validated against business goals.

---

## 2.2 Scope

This specification covers:
- Functional requirements for all user-facing features.
- Non-functional requirements including performance, reliability, scalability, accessibility, and compliance.
- Business rules governing quotation validity, inventory management, and multi-tenant isolation.
- Performance benchmarks derived from commercial requirements.
- Availability and reliability targets required for dealer operations.
- Assumptions and constraints that bound the engineering solution space.

---

## 2.3 Functional Requirements

### 2.3.1 Vehicle Selection Module

**FR-VS-001:** The system must present a searchable, filterable catalogue of vehicles to the user.  
**FR-VS-002:** Each vehicle selection must load the complete metadata package (image assets, coordinate definitions, wheel positioning parameters) without requiring page reload.  
**FR-VS-003:** Vehicle selection must trigger the rendering pipeline to update the scene graph within 500 milliseconds.  
**FR-VS-004:** The system must support vehicles across passenger, commercial, off-road, and performance categories.  
**FR-VS-005:** New vehicles must be added to the catalogue exclusively through asset upload and metadata definition — no code deployment permitted.

### 2.3.2 Colour Selection Module

**FR-CS-001:** The system must provide a colour picker interface displaying available vehicle colours defined in metadata.  
**FR-CS-002:** Colour selection must update the vehicle layer in the rendering pipeline immediately.  
**FR-CS-003:** Colour definitions must support HEX, RGB, and named colour values stored in metadata.

### 2.3.3 Rim Brand Selection

**FR-RB-001:** The system must display available rim brands filtered by compatibility with the selected vehicle.  
**FR-RB-002:** Brand selection must filter the available model list.  
**FR-RB-003:** Each brand must be associated with a logo asset and branding colour defined in the database.

### 2.3.4 Rim Model Selection

**FR-RM-001:** The system must display available rim models for the selected brand.  
**FR-RM-002:** Each rim model must include image assets for all supported finishes and diameters.  
**FR-RM-003:** Model selection must load the appropriate asset set into the renderer.

### 2.3.5 Rim Finish Selection

**FR-RF-001:** The system must present finish options (e.g., Matte Black, Gloss Silver, Polished) as defined for the selected model.  
**FR-RF-002:** Finish selection must load the corresponding image asset without reloading other layers.

### 2.3.6 Wheel Diameter Selection

**FR-WD-001:** The system must support standard wheel diameters (14–24 inches, incremented by 0.5 inches).  
**FR-WD-002:** Diameter selection must trigger the scaling transformation pipeline (Chapter 12).  
**FR-WD-003:** Diameter selection must validate against tyre compatibility rules.

### 2.3.7 Tyre Width Selection

**FR-TW-001:** The system must support standard tyre widths (155mm–355mm, incremented by 5mm or 10mm).  
**FR-TW-002:** Width selection must update the tyre layer dimensions in the scene graph.

### 2.3.8 Tyre Profile Selection

**FR-TP-001:** The system must support standard aspect ratios (25–85%).  
**FR-TP-002:** Profile selection must recalculate the tyre sidewall dimensions using the mathematical pipeline defined in Chapter 12.

### 2.3.9 Tyre Diameter Selection

**FR-TD-001:** The system must support standard tyre diameters.  
**FR-TD-002:** Tyre diameter selection combined with profile and width must maintain consistent rolling diameter calculations.

### 2.3.10 Visualisation Engine

**FR-VE-001:** The renderer must display the selected vehicle, rim, and tyre combination with accurate scaling, positioning, and masking.  
**FR-VE-002:** The renderer must support real-time updates when any selection parameter changes.  
**FR-VE-003:** The renderer must generate a visually realistic representation sufficient for commercial quotation purposes.

### 2.3.11 Configuration Saving

**FR-SV-001:** The system must allow users to save configurations with a unique name.  
**FR-SV-002:** Saved configurations must store the complete parameter set (vehicle, colour, brand, model, finish, diameter, width, profile, diameter).  
**FR-SV-003:** Saved configurations must be retrievable by the user and associated with their tenant.

### 2.3.12 Quotation System

**FR-QT-001:** The system must generate quotations from saved configurations including pricing, branding, and dealer information.  
**FR-QT-002:** Quotations must be printable through standard browser print functionality.  
**FR-QT-003:** Quotations must be exportable to PDF format with dealer branding overlays.

### 2.3.13 Email Quotation Delivery

**FR-EM-001:** The system must support sending quotations via email using SMTP integration or third-party email service APIs.  
**FR-EM-002:** Email templates must be customisable per tenant.

### 2.3.14 WhatsApp Quotation Delivery

**FR-WA-001:** The system must generate WhatsApp share messages containing quotation links.  
**FR-WA-002:** WhatsApp messages must include a preview image and direct link to the saved configuration.

### 2.3.15 Inventory Management

**FR-IM-001:** The system must track inventory quantities per wheel and tyre SKU per tenant.  
**FR-IM-002:** Inventory updates must trigger audit log entries.  
**FR-IM-003:** The system must support low-stock notifications.

### 2.3.16 Branding Management

**FR-BM-001:** Each tenant must have customizable branding (logo, colour palette, company name).  
**FR-BM-002:** Branding must be rendered on quotations, PDFs, and the user interface.

### 2.3.17 Multi-Tenant Isolation

**FR-MT-001:** Every data query must be filtered by the current tenant identifier.  
**FR-MT-002:** Users must not be able to access configurations, inventory, or branding data belonging to other tenants.

---

## 2.4 Non-Functional Requirements

### 2.4.1 Performance Requirements

| Requirement ID | Description | Target |
|---|---|---|
| NFR-PRF-001 | Page load time (initial) | < 2.5s |
| NFR-PRF-002 | Interactive rendering response | < 500ms |
| NFR-PRF-003 | Quotation PDF generation | < 3s |
| NFR-PRF-004 | Concurrent users per tenant | > 50 |
| NFR-PRF-005 | Concurrent users platform-wide | > 5,000 |

### 2.4.2 Availability

**NFR-AVL-001:** The platform must achieve 99.95% uptime during business hours (06:00–22:00 in all active time zones).  
**NFR-AVL-002:** Scheduled maintenance windows must not exceed 4 hours per month and must be announced 7 days in advance.

### 2.4.3 Reliability

**NFR-REL-001:** The database must support point-in-time recovery with a maximum data loss window of 15 minutes.  
**NFR-REL-002:** All asset uploads must be validated before persistence. Corrupt assets must be rejected with clear error messages.

### 2.4.4 Scalability

**NFR-SCL-001:** The architecture must support 10,000 active tenants without schema changes.  
**NFR-SCL-002:** Asset storage must scale linearly with upload volume.  
**NFR-SCL-003:** The rendering pipeline must maintain sub-500ms response time regardless of tenant count.

### 2.4.5 Accessibility

**NFR-ACC-001:** The platform must conform to WCAG 2.1 Level AA.  
**NFR-ACC-002:** All interactive elements must be keyboard navigable.  
**NFR-ACC-003:** All images must include descriptive alt text.

---

## 2.5 Business Rules

### 2.5.1 Quotation Validity Rules

**BR-QV-001:** A quotation is valid only if the selected tyre width, profile, and diameter are compatible with the selected wheel diameter and vehicle model.  
**BR-QV-002:** A quotation must include dealer branding to be considered official.  
**BR-QV-003:** A quotation must include pricing information to be considered complete.

### 2.5.2 Inventory Rules

**BR-INV-001:** Inventory quantities must never fall below zero.  
**BR-INV-002:** Inventory updates require audit trail entries including user, timestamp, and quantity change.

---

## 2.6 Performance Requirements (Detailed)

### 2.6.1 Rendering Performance Budget

Every rendering operation must complete within a defined budget:

- Scene graph construction: 50ms
- Image loading (cached): 20ms
- Image loading (uncached): 300ms
- Transformation pipeline: 30ms
- Layer compositing: 100ms

Total budget: 500ms maximum per update cycle.

---

## 2.7 Assumptions

- Dealers have modern web browsers with HTML5 Canvas and WebGL support.
- Dealers have reliable internet connectivity sufficient for image downloads.
- Vehicle manufacturers do not restrict the reproduction of vehicle images for quotation purposes.
- The regulatory environment permits digital quotations without physical signatures.

---

## 2.8 Constraints

- The technology stack is fixed: Next.js 15, React 19, TypeScript, Tailwind CSS, shadcn/ui, React Konva, Supabase, PostgreSQL, TanStack Query.
- No server-side rendering of the Konva canvas; the renderer operates client-side.
- All new vehicles must be added without code deployment.
- The renderer must not include hardcoded logic for any vehicle model.

---

## 2.9 Engineering Rationale (Chapter 2)

The requirements are structured to enforce the core architecture principles. The metadata-driven constraint (FR-VS-005) protects against hardcoding. The isolation requirements (FR-MT-001, FR-MT-002) enforce the multi-tenant design. The performance budget protects against rendering degradation at scale.

---

## 2.10 Implementation Notes (Chapter 2)

Every functional requirement must have a corresponding test case in Chapter 23. Non-functional requirements must have automated performance benchmarks in CI/CD. Business rules must be enforced in database constraints and Zod validation schemas.

*Chapter 2 complete. All requirements are numbered, traceable, and validated.*
