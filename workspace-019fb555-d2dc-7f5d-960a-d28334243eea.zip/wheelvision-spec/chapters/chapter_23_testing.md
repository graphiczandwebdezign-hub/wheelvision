# CHAPTER 23

# TESTING

## 23.1 Purpose

Defines the complete testing strategy: unit tests, integration tests, end-to-end tests, renderer tests, performance tests, security tests (pgTap), visual regression tests, and load testing.

---

## 23.2 Unit Tests

Jest + React Testing Library for components. Every component must have tests for rendering, interaction, and error states.

---

## 23.3 Integration Tests

Tests cover multi-step flows: select vehicle → select wheel → save quote → generate PDF. Playwright or Cypress is used for browser-based integration testing.

---

## 23.4 End-to-End Tests

E2E tests cover critical user journeys on staging deployments before production releases.

---

## 23.5 Renderer Tests

Renderer tests verify scene construction, layer order, mask application, and transformation accuracy using mock metadata.

---

## 23.6 Performance Tests

Performance budgets are validated by automated benchmarks in CI. Tests fail if rendering exceeds 500ms.

---

## 23.7 Security Tests (pgTap)

PostgreSQL security tests use pgTap to verify RLS policies. Every policy is tested against unauthorized access attempts.

---

## 23.8 Visual Regression

Visual regression tests compare rendered output against approved baseline images. Differences exceeding a threshold trigger review.

---

## 23.9 Load Testing

Load tests simulate concurrent user access to verify database and rendering performance at scale.

---

## 23.10 Engineering Rationale

Testing is not optional. Every critical path — security, rendering, quotation — requires automated verification. The combination of unit, integration, security, and performance tests provides comprehensive coverage.

*Chapter 23 complete.*
