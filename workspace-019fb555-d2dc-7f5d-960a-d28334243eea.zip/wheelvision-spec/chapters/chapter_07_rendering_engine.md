# CHAPTER 7

# RENDERING ENGINE

## 7.1 Purpose

This chapter defines the complete rendering engine architecture. It describes the scene graph, layer architecture, transformation pipeline, masking, lighting simulation, performance budget, caching strategy, animation scheduling, memory management, export pipeline, and the future 3D migration strategy. Every engineering decision is justified.

---

## 7.2 Scope

The renderer is a 2D canvas-based engine using React Konva. It operates entirely client-side. It must be metadata-driven, performance-optimized, and capable of producing publication-quality output for commercial quotations.

---

## 7.3 Scene Graph Architecture

```mermaid
graph TD
    A[Scene Root] --> B[Vehicle Layer Group]
    A --> C[Wheel Layer Group]
    A --> D[Shadow Layer Group]
    A --> E[Overlay Layer Group]
    B --> F[Vehicle Image]
    B --> G[Mask Shape]
    C --> H[Front Wheel Image]
    C --> I[Rear Wheel Image]
    D --> J[Shadow Image]
    E --> K[Text Overlays]
```

---

## 7.4 Layer Architecture (Detailed)

**Table 7.4.1 — Layer Definitions.**

| Layer | Konva Component | Purpose | Listening | Caching |
|---|---|---|---|---|
| Vehicle Layer | `<Layer>` with `<Image>` + `<Shape>` (mask) | Base vehicle image with wheel well masking | false | true |
| Front Wheel | `<Layer>` with `<Image>` + `<Circle>` (mask) | Rim image masked to circular form | false | true |
| Rear Wheel | `<Layer>` with `<Image>` + `<Circle>` (mask) | Rim image masked to circular form | false | true |
| Shadow Layer | `<Layer>` with `<Image>` (low opacity) | Ground shadow for realism | false | true |
| Overlay Layer | `<Layer>` with `<Text>` and `<Rect>` | Branding, pricing, labels | false | false |

---

## 7.5 Render Pipeline

1. **Load Phase:** Load metadata JSON and asset URLs.
2. **Parse Phase:** Build scene graph objects.
3. **Transform Phase:** Apply scaling, rotation, translation.
4. **Mask Phase:** Apply circular masks to wheel images.
5. **Composite Phase:** Render all layers to Konva Stage.
6. **Display Phase:** Output to canvas element.

---

## 7.6 Transformation Pipeline

Every wheel image undergoes:
- Scale: `scale = selected_diameter / reference_diameter`
- Translation: `x = metadata.front_wheel.x`, `y = metadata.front_wheel.y`
- Rotation: `rotation = metadata.wheels.rotation_angle_degrees`

---

## 7.7 Scaling, Perspective, and Coordinate System

The scene uses a pixel-based coordinate system with origin at top-left. Scale is uniform to prevent distortion. Perspective is simulated through shadow positioning and size differentials between front and rear wheels.

---

## 7.8 Masking

Wheel layers use Konva `<Circle>` masks to clip wheel images to circular form. Mask radius scales with wheel diameter.

---

## 7.9 Lighting and Shadows

Realistic lighting is simulated through pre-rendered shadow images with adjustable opacity (default 0.35). No dynamic lighting calculation is performed to maintain performance.

---

## 7.10 Performance

Performance budget: 500ms per full render cycle. Layers have `listening(false)` to disable event processing. Images use Konva `cache()` for pixel-level caching after initial render. Memory usage is monitored; images are released when layers are destroyed.

---

## 7.11 Caching Strategy

Image assets are cached by browser and CDN. Konva caches rendered layer pixels. TanStack Query caches metadata and asset URLs. No redundant network requests occur within the same session for the same asset.

---

## 7.12 Animation

Selection changes trigger Framer Motion animations on UI elements. Konva animations (tweens) handle smooth wheel rotation or scale transitions. Animation duration is capped at 300ms.

---

## 7.13 Memory Management

Components unmount properly via React cleanup functions. Konva nodes are destroyed explicitly to release canvas memory. Large image objects are dereferenced to assist garbage collection.

---

## 7.14 Export Pipeline

The export function creates a new Konva stage off-screen, renders the scene, and converts the canvas to PNG or PDF using `html2canvas` or native canvas `toDataURL()` followed by PDF generation.

---

## 7.15 Future 3D Migration Strategy

The scene graph abstraction remains independent of the rendering technology. Metadata fields will expand to include 3D rotation axes, camera positions, and lighting parameters. When a 3D renderer is adopted, the same metadata drives a Three.js or WebGL engine without structural changes.

---

## 7.16 Engineering Rationale

Konva provides the best balance of performance, React integration, and canvas control. The layer architecture separates concerns (vehicle, wheels, shadow, overlay) allowing independent updates. The transformation pipeline is mathematically rigorous, ensuring commercial accuracy. The future 3D strategy protects long-term investment.

---

## 7.17 Implementation Considerations

Every renderer component must include error boundaries. Asset loading failures must display placeholder images. Performance budgets must be enforced by automated tests. Memory leaks must be detected through profiling in development.

*Chapter 7 complete.*
