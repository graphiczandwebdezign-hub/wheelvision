# CHAPTER 12

# RENDERING MATHEMATICS

## 12.1 Purpose

Defines every mathematical operation performed by the rendering engine. Every formula is explicitly stated. Every variable is defined. There is no ambiguity.

---

## 12.2 Scaling Formula

`scale_factor = selected_wheel_diameter / reference_wheel_diameter`

Where `reference_wheel_diameter` is the diameter (in pixels) of the wheel image at its native resolution, as defined in metadata (`wheels.diameter_pixels`).

---

## 12.3 Coordinate Transformations

The renderer uses a 2D Cartesian coordinate system with origin (0,0) at the top-left of the scene. Positive x extends right. Positive y extends down.

Translation transformations apply directly to Konva node `x` and `y` properties.

---

## 12.4 Aspect Ratio Preservation

To maintain aspect ratio: `scale_x = scale_y = scale_factor`. Non-uniform scaling is prohibited.

---

## 12.5 Rotation

Rotation is applied around the center point of the wheel image (`offsetX = width/2`, `offsetY = height/2`). Rotation angle is defined in degrees and converted to radians for Konva's `rotation()` method.

---

## 12.6 Perspective Simulation

Perspective is simulated through:
- Size differential: rear wheels are scaled by `0.92` relative to front wheels.
- Vertical offset: rear wheels are positioned lower in the scene (`y_rear = y_front + 10`).
- Shadow offset: shadow layers use reduced opacity (`0.35`) and slight displacement.

---

## 12.7 Wheel Position Calculations

Front wheel position: `(x_front, y_front)` from metadata.  
Rear wheel position: `(x_rear, y_rear)` from metadata.  
Both are absolute pixel coordinates in the scene coordinate system.

---

## 12.8 Tyre Diameter Calculations

Tyre outer diameter (in mm):
`D = (Width × Profile / 100) × 2 + Diameter_rim`

Where `Diameter_rim` is the selected wheel diameter converted to mm (`diameter_inches × 25.4`).

---

## 12.9 Export Calculations

Export resolution: `scale = export_dpi / 72` (for PDF at 300 DPI). Canvas dimensions are multiplied by scale. Images are re-rendered at high resolution using the same transformation pipeline with scaled parameters.

---

## 12.10 Engineering Rationale

Every visual output is derived from mathematical formulas rather than manual positioning. This ensures consistency across all vehicles, eliminates human error in asset creation, and allows automated validation.

---

## 12.11 Implementation Notes

All calculations are performed in JavaScript using `Number` (double-precision floating point). Results are validated against physical constraints (e.g., tyre diameter must be positive, scale must not exceed 5.0 to prevent image distortion).

*Chapter 12 complete.*
