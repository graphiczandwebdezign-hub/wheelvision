# CHAPTER 25

# DEVELOPMENT STANDARDS

## 25.1 Purpose

Defines folder structure, naming conventions, coding standards, architecture rules, documentation standards, branch strategy, commit conventions, definition of done, and code review checklist.

---

## 25.2 Folder Structure

As defined in Chapter 1: `app/`, `components/`, `lib/`, `contexts/`, `hooks/`, `public/`, asset directories, `tests/`, migrations.

---

## 25.3 Naming Standards

Components: PascalCase. Hooks: `use` prefix, camelCase. Variables: camelCase. Types/Interfaces: PascalCase with `I` or `Type` suffix optional. Files: kebab-case for pages, PascalCase for components.

---

## 25.4 Coding Standards

TypeScript strict mode enabled. No `any` types without justification. All functions must include JSDoc. All components must include prop types (via TypeScript interfaces).

---

## 25.5 Architecture Rules

- No hardcoded renderer logic.
- No database access outside repositories.
- No direct environment variable access in components (use `lib/config`).
- All forms use React Hook Form + Zod.
- All async data uses TanStack Query.

---

## 25.6 Documentation Standards

Every module requires a README. Every public API requires OpenAPI documentation. Every component must include usage examples.

---

## 25.7 Branch Strategy

`main` (production), `develop` (integration), feature branches (`feature/name`), hotfix branches (`hotfix/name`).

---

## 25.8 Commit Conventions

Conventional Commits: `feat:`, `fix:`, `docs:`, `refactor:`, `test:`, `chore:`. Every commit must include a description explaining the engineering rationale.

---

## 25.9 Definition of Done

- Code passes all automated tests.
- Documentation is updated.
- Security review completed (if applicable).
- Performance budget verified.
- Peer review approved.

---

## 25.10 Code Review Checklist

- Does the code reference the architecture principles?
- Are all variables typed?
- Are errors handled?
- Are performance budgets respected?
- Is there unnecessary complexity?

---

## 25.11 Implementation Notes

Developers must read this specification before contributing. Every pull request description must reference the affected requirements.

*Chapter 25 complete.*
