# CHAPTER 20

# SECURITY

## 20.1 Purpose

Defines the complete security model covering OWASP Top 10 protections, RLS enforcement, encryption at rest and in transit, secret management, audit logging, rate limiting, CSRF, CSP, XSS prevention, SQL injection defense, SSRF prevention, and file upload security.

---

## 20.2 OWASP Alignment

The platform addresses all OWASP Top 10 risks through design and implementation controls.

---

## 20.3 RLS Enforcement

Every table has RLS enabled with policies enforcing tenant isolation. This is the primary defense against data leakage.

---

## 20.4 Encryption

Data in transit: TLS 1.3. Data at rest: PostgreSQL encryption (Supabase provides this). Sensitive fields use application-level encryption where required.

---

## 20.5 Secrets Management

Secrets (Supabase keys, email API keys) are stored in Vercel environment variables. They are never committed to Git.

---

## 20.6 Audit Logs

Every mutation (create, update, delete) generates an audit log entry. Audit logs include user ID, timestamp, action, and affected resource ID.

---

## 20.7 Rate Limiting

Rate limits are enforced at middleware layer (Chapter 14). Limits prevent brute-force attacks and resource exhaustion.

---

## 20.8 CSRF, CSP, XSS

CSRF: SameSite cookies and anti-CSRF tokens for state-changing operations.  
CSP: Strict Content Security Policy headers.  
XSS: All user input is sanitized using Zod validation and React's automatic escaping.

---

## 20.9 SQL Injection and SSRF

SQL injection: Prevented by parameterized queries (Supabase client) and RLS. SSRF: Prevented by URL validation and server-side fetch restrictions.

---

## 20.10 File Upload Security

File uploads are validated for type, size, and content. Virus scanning is performed. Uploaded files are stored in isolated buckets with no execution permissions.

---

## 20.11 Engineering Rationale

Security is a design constraint, not a feature. Every layer — database, middleware, API, UI, storage — must enforce security policies. Defense in depth ensures that no single failure results in compromise.

*Chapter 20 complete.*
