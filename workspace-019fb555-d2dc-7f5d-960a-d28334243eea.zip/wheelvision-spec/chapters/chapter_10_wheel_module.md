# CHAPTER 10

# WHEEL MODULE

## 10.1 Purpose

Defines the complete wheel domain model, including brands, models, finishes, bolt patterns, offsets, PCD (Pitch Circle Diameter), center bore, variants, inventory links, and filtering.

---

## 10.2 Wheel Domain Entities

**Brand:** name, logo URL, country of origin, active status.  
**Model:** brand reference, model name, description, weight, construction type.  
**Finish:** colour, texture, gloss level, image asset reference.  
**Variant:** diameter, width, offset, PCD, center bore, bolt count.

---

## 10.3 Bolt Patterns, Offsets, PCD, Center Bore

These are value objects defined in metadata and validated against vehicle compatibility rules. Incorrect combinations are rejected at the application layer and database constraint level.

---

## 10.4 Wheel Variants and Inventory

Each variant is an inventory-tracked SKU (`wheels_inventory` table). The module links variant IDs to inventory quantities per tenant.

---

## 10.5 Filtering Architecture

Filters operate through URL parameters processed by Next.js server components and TanStack Query. Filter combinations are validated against available inventory.

---

## 10.6 Engineering Rationale

The module separates the commercial definition (brand/model/finish) from the technical specification (offset/PCD). This allows dealers to browse by aesthetics while the system enforces technical compatibility.

*Chapter 10 complete.*
