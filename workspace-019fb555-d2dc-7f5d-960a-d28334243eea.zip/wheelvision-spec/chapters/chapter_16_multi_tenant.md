# CHAPTER 16

# MULTI-TENANT ARCHITECTURE

## 16.1 Purpose

Defines the complete multi-tenant architecture: shared database, RLS isolation, tenant branding, inventory isolation, billing, subscriptions, feature flags, white-label deployment, and custom domain mapping.

---

## 16.2 Tenant Model

Every dealer is a tenant (`tenants` table). Users belong to tenants (`tenant_memberships`). All data queries include `tenant_id` filtering.

---

## 16.3 Isolation

Isolation is enforced at the database layer (RLS), the middleware layer (`X-Tenant-ID`), and the application layer (filtering in queries). No single layer is relied upon exclusively.

---

## 16.4 Branding

Branding is stored in `branding_json` per tenant. The renderer applies branding overlays (logo, colour) based on the current tenant context.

---

## 16.5 Inventory Isolation

Inventory records reference `tenant_id` and `wheel_id` or `tyre_id`. Dealers see only their own inventory.

---

## 16.6 Billing and Subscriptions

Subscription tiers (Basic, Professional, Enterprise) define feature access. Billing records reference tenant IDs. Integration with Stripe or similar is planned for Sprint 10.

---

## 16.7 Feature Flags

Feature access is controlled by `feature_flags` JSON per tenant. Flags are checked by middleware before rendering protected UI elements.

---

## 16.8 White Label and Custom Domains

Enterprise tenants can configure custom domains (`dealer.com`). The middleware routes requests to the correct tenant based on domain mapping.

---

## 16.9 Engineering Rationale

Shared-database multi-tenancy minimizes operational complexity while maintaining strict isolation. Feature flags allow tiered service without code branching. White-label support expands the addressable market.

*Chapter 16 complete.*
