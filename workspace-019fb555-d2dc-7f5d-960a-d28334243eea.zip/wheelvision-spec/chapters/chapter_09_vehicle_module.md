# CHAPTER 9

# VEHICLE MODULE

## 9.1 Purpose

Defines the architecture, asset loading, metadata loading, validation, caching, rendering integration, and future expansion for the Vehicle Module.

---

## 9.2 Architecture

The Vehicle Module consists of:
- `VehicleSelector` component (UI).
- `useVehicle` hook (data fetching via TanStack Query).
- `VehicleRenderer` component (Konva layer construction).
- `VehicleValidator` service (metadata validation).

---

## 9.3 Asset Loading

Assets load from R2 via signed URLs. Metadata loads from Supabase. The module handles loading states, error states, and retry logic.

---

## 9.4 Metadata Loading

Metadata is fetched once per vehicle selection and cached by TanStack Query with a 24-hour stale time. Updates to metadata invalidate the cache.

---

## 9.5 Validation

Every loaded metadata file must pass JSON Schema validation. Missing required fields trigger error states with user-facing messages.

---

## 9.6 Rendering Integration

The Vehicle Module provides props (`vehicleData`, `layerConfig`) to the PreviewCanvas component. It does not manage rendering directly, maintaining separation of concerns.

---

## 9.7 Future Expansion

Future expansion includes vehicle animation sequences (e.g., rotating 360° view), interior view modes, and custom colour application beyond predefined options. The metadata schema supports these through additive fields.

---

## 9.8 Engineering Rationale

Separating data loading (Vehicle Module) from rendering (PreviewCanvas) ensures that rendering logic remains universal. The module is responsible for one domain concept only: vehicle selection and loading.

*Chapter 9 complete.*
