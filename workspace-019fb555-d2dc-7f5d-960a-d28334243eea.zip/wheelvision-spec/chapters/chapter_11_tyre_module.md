# CHAPTER 11

# TYRE MODULE

## 11.1 Purpose

Defines the tyre domain, sizing conventions, rolling diameter calculations, sidewall dimensions, width and profile relationships, fitment rules, validation, and mathematical calculations.

---

## 11.2 Sizing Standards

Tyre sizes follow the standard format: `[Width]/[Profile] R[Diameter]`. Example: `265/65 R18`.

---

## 11.3 Rolling Diameter Calculations

Rolling diameter = `(Width × Profile / 100 × 2 / 25.4) + Diameter`. This formula ensures that changing width or profile maintains consistent rolling characteristics.

---

## 11.4 Sidewall Dimensions

Sidewall height = Width × Profile / 100 (in mm). This determines the visual size of the tyre relative to the wheel.

---

## 11.5 Fitment Rules

A tyre must not exceed the vehicle's maximum recommended width or diameter. These limits are defined in the vehicle metadata (`fitment_limits` field) and enforced by the ConfigurationValidationService.

---

## 11.6 Implementation Notes

All calculations use floating-point arithmetic with 2-decimal precision. Results are validated against database-stored limits before quotation generation.

*Chapter 11 complete.*
