# CHAPTER 19

# QUOTE SYSTEM

## 19.1 Purpose

Defines quotation creation, saving, loading, PDF export, printing, email delivery, and WhatsApp sharing.

---

## 19.2 Save and Load

Quotes store full configuration parameters in `quotes` table (`json_payload`). Users retrieve quotes through `GET /api/quotes`.

---

## 19.3 PDF Export

PDF generation uses a server-side renderer (e.g., Puppeteer or html2canvas) to convert the Konva canvas to a high-resolution image embedded in a branded PDF template.

---

## 19.4 Print

Standard browser print functionality supports quotation printing with CSS print media queries.

---

## 19.5 Email and WhatsApp

Email uses SMTP or SendGrid API with tenant-branded templates. WhatsApp uses the WhatsApp Business API with a link to the saved quote.

---

## 19.6 Engineering Rationale

Quotations are commercial outputs. They must be accurate, branded, and shareable. The system integrates with standard communication channels to maximize dealer efficiency.

*Chapter 19 complete.*
