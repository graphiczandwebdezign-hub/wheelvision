# CHAPTER 4

# DOMAIN DRIVEN DESIGN

## 4.1 Purpose

This chapter establishes the domain model for WheelVision using Domain-Driven Design principles. It defines bounded contexts, aggregates, entities, value objects, repositories, domain services, and application services. Every definition eliminates ambiguity for future developers.

---

## 4.2 Scope

The domain covers: tenant management, vehicle assets, wheel assets, tyre assets, configuration state, quotation processes, inventory tracking, branding, and multi-tenant isolation.

---

## 4.3 Bounded Contexts

```mermaid
graph LR
    A[Tenant Context] --> B[Asset Context]
    A --> C[Quotation Context]
    A --> D[Inventory Context]
    B --> E[Rendering Context]
    C --> D
    D --> E
```

**Table 4.3.1 — Bounded Context Definitions.**

| Context | Responsibility | Entities | Value Objects |
|---|---|---|---|
| Tenant Context | Dealer identity, branding, users | Tenant, User | BrandConfig |
| Asset Context | Vehicle, wheel, tyre definitions | Vehicle, Wheel, Tyre | ImageReference, Metadata |
| Rendering Context | Scene graph, layer management | SceneGraph | Coordinate, ScaleFactor |
| Quotation Context | Quote generation, export, delivery | Quote, LineItem | Price, ConfigurationID |
| Inventory Context | Stock tracking, updates, audit | InventoryItem | StockLevel |

---

## 4.4 Aggregates

### 4.4.1 Tenant Aggregate
Root: `Tenant`  
Includes: `TenantMembership`, `BrandConfig`  
Invariants: A tenant must have exactly one primary owner. A tenant's branding must include a valid logo URL.

### 4.4.2 Asset Aggregate
Root: `Vehicle`, `Wheel`, `Tyre`  
Invariants: A vehicle must have valid metadata JSON. A wheel must reference a valid brand and model.

---

## 4.5 Entities and Value Objects (Detailed)

**Entity — Vehicle:**  
- id: UUID  
- manufacturer: String  
- model: String  
- year: Integer  
- metadata_json: JSONB  
- image_url: URL  
- tenant_id: UUID (for tenant-specific vehicles; null for global)

**Value Object — Coordinate:**  
- x: Float  
- y: Float  
- unit: String (pixels, percentage)  
Invariants: x and y must be non-negative when in pixel mode.

**Value Object — ScaleFactor:**  
- scale_x: Float  
- scale_y: Float  
Invariants: Both values must be positive.

---

## 4.6 Repositories

Every aggregate has a repository interface implemented by Supabase queries with RLS enforcement.

---

## 4.7 Domain Services

**ConfigurationValidationService:** Validates that selected wheel and tyre combinations are compatible with the selected vehicle based on metadata rules.  
**QuotationGenerationService:** Produces quote documents from configuration aggregates.  
**InventoryUpdateService:** Manages stock adjustments with audit trail guarantees.

---

## 4.8 Engineering Rationale

Bounded contexts prevent domain model pollution. The asset context remains independent from the quotation context, ensuring that quotation logic does not corrupt asset definitions. Aggregates enforce invariants that database constraints alone cannot express fully.

---

## 4.9 Implementation Considerations

Repositories are implemented as TypeScript functions using TanStack Query hooks. Domain services are pure TypeScript modules without framework dependencies, ensuring testability and portability.

*Chapter 4 complete.*
