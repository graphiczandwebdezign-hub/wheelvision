# CHAPTER 15

# AUTHENTICATION

## 15.1 Purpose

Defines authentication architecture using Supabase Auth, JWT session management, refresh token rotation, tenant resolution, RBAC, and permissions matrix.

---

## 15.2 Supabase Auth Integration

Supabase Auth provides email/password and OAuth providers. User accounts link to the `users` table via `auth_uid`.

---

## 15.3 JWT and Sessions

Access tokens expire after 60 minutes. Refresh tokens rotate on every use. Cookies use `HttpOnly`, `Secure`, and `SameSite=Strict` attributes.

---

## 15.4 Refresh Tokens

Refresh tokens are stored server-side in a secure cookie. Rotation prevents replay attacks.

---

## 15.5 Tenant Resolution

Middleware reads `tenant_id` from JWT claim or subdomain header (`X-Tenant-ID`). The session variable `app.current_tenant_id` is set before database access.

---

## 15.6 RBAC

**Table 15.6.1 — Permissions Matrix.**

| Role | Read Assets | Write Assets | Manage Inventory | Manage Users | View Quotes | Create Quotes |
|---|---|---|---|---|---|---|
| Dealer User | Yes | No | No | No | Own | Yes |
| Dealer Admin | Yes | Yes | Yes | No | All | Yes |
| Dealer Owner | Yes | Yes | Yes | Yes | All | Yes |
| Platform Admin | Yes (all) | Yes (all) | Yes (all) | Yes | Yes | Yes |

---

## 15.7 Engineering Rationale

RBAC ensures principle of least privilege. RLS provides defense-in-depth. JWT claims allow stateless authorization checks.

*Chapter 15 complete.*
