# CHAPTER 18

# AI ASSET PIPELINE

## 18.1 Purpose

Defines the automated pipeline for background removal, wheel detection, perspective detection, metadata generation, validation, human review, and publishing.

---

## 18.2 Background Removal

Uses an AI model (e.g., remove.bg API or custom segmentation model) to isolate the vehicle from background.

---

## 18.3 Wheel Detection

Computer vision detects wheel regions, generates bounding boxes, and creates circular masks.

---

## 18.4 Perspective Detection

AI estimates camera angle and perspective parameters. These inform the scene metadata (shadow placement, rotation angles).

---

## 18.5 Metadata Generation

The AI proposes `metadata.json` values based on image analysis. Human admins review and adjust before approval.

---

## 18.6 Validation and Review

All AI outputs pass automated validation (Chapter 6). Human review is mandatory before publishing.

---

## 18.7 Engineering Rationale

AI accelerates asset onboarding but does not replace human oversight. The pipeline is modular — individual stages can be replaced or upgraded without affecting other stages.

*Chapter 18 complete.*
