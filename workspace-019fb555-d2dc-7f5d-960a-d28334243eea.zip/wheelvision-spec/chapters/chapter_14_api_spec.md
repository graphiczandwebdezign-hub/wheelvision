# CHAPTER 14

# API SPECIFICATION

## 14.1 Purpose

Defines every REST endpoint with request/response schemas, authentication requirements, authorization rules, validation rules, error codes, rate limits, pagination, caching headers, and API versioning.

---

## 14.2 Scope

Includes all `/api/*` routes in the Next.js App Router, Supabase direct queries, and external integrations (email, WhatsApp, PDF).

---

## 14.3 REST Endpoints

**Table 14.3.1 — Core Endpoints.**

| Method | Endpoint | Auth | Description | Rate Limit |
|---|---|---|---|---|
| GET | /api/vehicles | JWT + RLS | List vehicles for tenant | 60/min |
| GET | /api/vehicles/{id} | JWT + RLS | Get vehicle with metadata | 60/min |
| POST | /api/vehicles | JWT + Admin | Upload new vehicle assets | 10/min |
| GET | /api/wheels | JWT + RLS | Filtered wheel list | 60/min |
| GET | /api/tyres | JWT + RLS | Filtered tyre list | 60/min |
| POST | /api/quotes | JWT | Save configuration quote | 30/min |
| GET | /api/quotes | JWT + RLS | List saved quotes | 60/min |
| GET | /api/admin/inventory | JWT + Admin | Inventory status | 60/min |

---

## 14.4 OpenAPI Specification

OpenAPI 3.1 definitions are stored in `/docs/openapi.yaml`. All endpoints include request/response schemas using Zod-derived types.

---

## 14.5 Authentication and Authorization

Every endpoint requires a valid JWT cookie (Supabase Auth). Middleware resolves the tenant and applies RLS. Admin endpoints require the `admin` role claim.

---

## 14.6 Validation

Request bodies are validated using Zod schemas. Invalid requests return `400` with a structured error object: `{ "code": "VALIDATION_ERROR", "message": "...", "field": "..." }`.

---

## 14.7 Error Handling

Standard error codes: 400 (validation), 401 (unauthenticated), 403 (forbidden by RLS), 404 (not found), 429 (rate limited), 500 (internal error). All errors are logged with correlation IDs.

---

## 14.8 Rate Limiting

Rate limits are enforced by middleware using an in-memory store (scalable to Redis for multi-instance deployments). Limits are per-user, per-tenant, and global.

---

## 14.9 Pagination

List endpoints use cursor-based pagination (`cursor` parameter) to avoid offset performance issues at scale.

---

## 14.10 Caching

Responses include `Cache-Control` headers. `GET` endpoints for static data use `max-age=300`. Dynamic endpoints include `no-cache`.

---

## 14.11 Versioning

API version is included in the URL path: `/api/v1/*`. New versions are added as `/api/v2/*`. Old versions are deprecated with 6-month notice.

---

## 14.12 Engineering Rationale

A well-defined API contract eliminates ambiguity between front-end and back-end development. Zod validation provides runtime type safety. Rate limiting protects database performance.

*Chapter 14 complete.*
