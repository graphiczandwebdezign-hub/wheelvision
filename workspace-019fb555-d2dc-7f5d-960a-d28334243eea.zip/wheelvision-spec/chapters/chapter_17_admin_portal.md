# CHAPTER 17

# ADMIN PORTAL

## 17.1 Purpose

Defines the complete admin portal architecture for managing vehicles, wheels, tyres, users, inventory, dealer settings, approvals, and publishing.

---

## 17.2 Architecture

Protected routes (`/admin/*`) use Next.js middleware with role verification. Admin components reuse shadcn/ui components with extended permissions.

---

## 17.3 Vehicle Management

Admins upload assets, edit metadata, and approve new vehicles for publication. The AI pipeline (Chapter 18) supports automated processing.

---

## 17.4 Wheel and Tyre Management

Admins manage brand definitions, model details, finish images, and inventory quantities.

---

## 17.5 User and Inventory Management

Admins invite users (`POST /api/admin/users`), assign roles, and manage inventory adjustments with audit trails.

---

## 17.6 Publishing Workflow

Assets start in `draft` status. After admin approval, status changes to `published`. Published assets are available to the renderer.

---

## 17.7 Engineering Rationale

The admin portal is a first-class feature, not an afterthought. It uses the same authentication, authorization, and validation layers as the public application. Publishing workflows ensure quality control.

*Chapter 17 complete.*
