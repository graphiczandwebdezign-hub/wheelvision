# CHAPTER 13

# STATE MANAGEMENT

## 13.1 Purpose

Defines the complete state management architecture using TanStack Query, React Context, and local component state. Every state transition is documented.

---

## 13.2 Scope

Includes server state (queries, mutations), client state (selections, UI), caching strategy, optimistic updates, and state transition diagrams.

---

## 13.3 TanStack Query Architecture

Every server interaction uses TanStack Query hooks (`useQuery`, `useMutation`, `useQueryClient`). Queries are keyed by resource type and parameters. Mutations include invalidation rules.

---

## 13.4 React Context

`TenantContext` provides current tenant, branding, and user role. `ConfigurationContext` provides selected vehicle, wheel, and tyre parameters. These contexts eliminate prop drilling.

---

## 13.5 Caching Strategy

Stale time: 5 minutes for vehicle lists, 24 hours for assets. Cache keys include tenant ID. Invalidation is triggered by mutations on the related resource.

---

## 13.6 Optimistic Updates

Quotation saves use optimistic updates: the UI updates immediately with the new quote before server confirmation. If the server rejects the save, the UI rolls back to the previous state.

---

## 13.7 State Diagrams

```mermaid
stateDiagram-v2
    [*] --> Idle
    Idle --> LoadingVehicle: Select Vehicle
    LoadingVehicle --> VehicleLoaded: Data Fetched
    VehicleLoaded --> LoadingWheel: Select Brand
    LoadingWheel --> WheelLoaded: Brand Filtered
    WheelLoaded --> ConfigurationComplete: Select Size
    ConfigurationComplete --> QuoteSaved: Save Quote
    QuoteSaved --> [*]
```

---

## 13.8 Implementation Notes

State must never be duplicated between TanStack Query and React Context. The source of truth for server data is the query cache. The source of truth for user selections is Context.

*Chapter 13 complete.*
