# CHAPTER 3

# SYSTEM ARCHITECTURE

## 3.1 Purpose

This chapter defines the complete system architecture for WheelVision. It provides unambiguous reference diagrams, component definitions, communication flows, deployment topologies, and architecture decision records. Every engineer must understand exactly how data flows from user interaction to database persistence to rendered output.

---

## 3.2 Scope

This chapter covers:
- System context diagram.
- Container architecture diagram.
- Component architecture diagram.
- Deployment architecture diagram.
- Sequence diagrams for critical operations.
- Communication flow descriptions.
- Architecture Decision Records (ADRs).
- Tradeoffs and risks.

---

## 3.3 System Context Diagram

```mermaid
graph TD
    A[Dealer User] -->|Selects Vehicle, Wheel, Tyre| B[WheelVision Web App]
    B -->|Queries Assets| C[Cloudflare R2 Storage]
    B -->|Reads/Writes Data| D[Supabase PostgreSQL]
    B -->|Authentication| E[Supabase Auth]
    B -->|Generates PDF| F[PDF Service]
    F -->|Sends Email| G[Email Service]
    B -->|Shares Link| H[WhatsApp API]
    I[Admin User] -->|Uploads Assets| B
    J[Tenant Branding] --> B
```

**Figure 3.3.1 — System Context Diagram.** The system interacts with dealers, administrators, external storage, authentication services, PDF generation, email services, and messaging APIs. Every interaction is mediated through the WheelVision application layer.

---

## 3.4 Container Diagram

```mermaid
C4Container
    title Container Diagram — WheelVision SaaS
    
    Person(dealer, "Dealer User", "Selects configuration, generates quote")
    Person(admin, "Admin User", "Manages assets, inventory, branding")
    
    System_Ext(r2, "Cloudflare R2", "Asset storage: vehicles, wheels, tyres, masks")
    System_Ext(supabase, "Supabase", "PostgreSQL DB, Auth, RLS enforcement")
    System_Ext(email, "Email Provider", "SMTP/SendGrid integration")
    System_Ext(whatsapp, "WhatsApp Business", "Message delivery API")
    
    System_Boundary(wheelvision, "WheelVision Platform") {
        Container(web, "Next.js 15 Web App", "Next.js App Router, React 19, TypeScript", "SSR + Client Rendering")
        Container(renderer, "React Konva Renderer", "Canvas-based scene graph engine", "Client-side only")
        Container(api, "API Routes", "Next.js Route Handlers", "RESTful endpoints")
        Container(admin_ui, "Admin Portal", "Asset upload, metadata editing, inventory management", "Protected routes")
    }
    
    Rel(dealer, web, "HTTPS requests", "Browser")
    Rel(admin, admin_ui, "HTTPS requests", "Browser")
    Rel(web, renderer, "Prop updates", "React state changes")
    Rel(web, api, "REST calls", "Fetch / Axios")
    Rel(web, supabase, "DB queries", "Supabase Client")
    Rel(web, r2, "Asset URLs", "Direct download")
    Rel(api, supabase, "DB operations", "Supabase Client")
    Rel(web, email, "Quotation delivery", "SMTP / API")
    Rel(web, whatsapp, "Message delivery", "WhatsApp API")
```

**Figure 3.4.1 — Container Diagram.** The platform consists of four primary containers: the Next.js web application, the React Konva renderer, the API route layer, and the admin portal. All containers interact with external services for persistence, storage, and communication.

---

## 3.5 Component Diagram (Renderer Focus)

```mermaid
graph TB
    A[VehicleSelector Component] -->|Sets State| B[Configuration Context]
    B -->|Prop Changes| C[PreviewCanvas Component]
    C -->|Creates Layers| D[Konva Stage]
    D --> E[Vehicle Layer]
    D --> F[Front Wheel Layer]
    D --> G[Rear Wheel Layer]
    D --> H[Shadow Layer]
    D --> I[Overlay Layer]
    C -->|Loads Assets| J[Asset Loader]
    J --> K[Cloudflare R2]
    B --> L[TanStack Query Cache]
    L --> M[Supabase DB]
    C --> N[Scaling Pipeline]
    C --> O[Masking Pipeline]
```

---

## 3.6 Deployment Diagram

```mermaid
graph TD
    A[Vercel Edge Network] --> B[Next.js 15 App]
    B --> C[Cloudflare R2]
    B --> D[Supabase Hosted PostgreSQL]
    D --> E[Supabase Auth]
    D --> F[Row-Level Security Policies]
    B --> G[Monitoring & Logging]
    H[GitHub Actions] -->|Build & Test| B
    I[Developer Machine] --> H
```

**Table 3.6.1 — Deployment Nodes.**

| Node | Technology | Purpose | Scaling Strategy |
|---|---|---|---|
| Edge Network | Vercel | Global CDN, SSR, routing | Auto-scale |
| Application | Next.js 15 | Web server, API, rendering | Serverless functions |
| Database | Supabase PostgreSQL 15 | Persistent storage, RLS | Vertical + read replicas |
| Storage | Cloudflare R2 | Asset files (images, JSON) | Horizontal (object store) |
| CI/CD | GitHub Actions | Build, test, deploy | Parallel jobs |

---

## 3.7 Sequence Diagrams

### 3.7.1 Vehicle Selection Flow

```mermaid
sequenceDiagram
    participant U as User
    participant W as Next.js App
    participant R as Konva Renderer
    participant DB as Supabase DB
    participant R2 as Cloudflare R2
    
    U->>W: Click vehicle
    W->>DB: Query metadata (RLS)
    DB-->>W: Metadata JSON
    W->>R2: Request asset URLs
    R2-->>W: Signed URLs
    W->>R: Update props (vehicle, images)
    R->>R: Reconstruct scene graph
    R->>U: Rendered preview
```

---

## 3.8 Communication Flow

All communication follows a secure, authenticated pattern:
1. User request includes JWT cookie.
2. Middleware resolves tenant from JWT claim or subdomain.
3. Middleware sets `app.current_tenant_id` session variable.
4. Database queries execute with RLS policies enforcing `tenant_id` filter.
5. Renderer requests assets using signed URLs from R2.
6. All responses include appropriate CORS headers and CSP directives.

---

## 3.9 Architecture Decisions (ADR Format)

### ADR-001: Shared Database with Row-Level Security

**Status:** ACCEPTED  
**Context:** Multi-tenant isolation must be mathematically enforced.  
**Decision:** Shared PostgreSQL schema with RLS policies on every table.  
**Consequences:** Simplified migrations; guaranteed isolation; requires rigorous security testing.

---

## 3.10 Tradeoffs

Shared database introduces a single point of failure but eliminates schema drift. The renderer operates client-side, reducing server compute but requiring robust asset delivery. Next.js App Router introduces server components that improve SEO but require careful separation from Konva's client-side rendering.

---

## 3.11 Future Expansion

The architecture supports future 3D rendering by maintaining the scene graph abstraction independently of the rendering technology. The deployment supports dedicated database instances for premium tiers. The API layer supports GraphQL migration if required.

---

## 3.12 Engineering Rationale

Every architecture decision is justified by scalability, security, and maintainability requirements. The container separation protects renderer performance from database latency. The deployment on Vercel eliminates server maintenance overhead. The use of Cloudflare R2 eliminates egress costs at scale.

*Chapter 3 complete with full diagrams and architecture justification.*
