# CHAPTER 21

# PERFORMANCE ENGINEERING

## 21.1 Purpose

Defines performance budgets, caching strategies, lazy loading, image optimisation, CDN configuration, query optimisation, database indexing, memory usage targets, rendering performance targets, and monitoring.

---

## 21.2 Caching Strategy

Multiple caching layers: browser cache, CDN edge cache, Konva pixel cache, TanStack Query cache, database query cache (PostgreSQL).

---

## 21.3 Lazy Loading

Images load lazily using `loading="lazy"` and IntersectionObserver. Components load via React lazy and Suspense.

---

## 21.4 Image Optimisation

Images are served in WebP format with responsive sizing (`srcset`). The renderer uses the smallest adequate resolution.

---

## 21.5 Query Optimisation

Database queries use selective column retrieval, proper indexing, and pagination. N+1 queries are eliminated by joining where appropriate.

---

## 21.6 Memory Usage

Memory budgets are enforced in development profiling. Memory leaks are detected by monitoring heap growth over time.

---

## 21.7 Rendering Performance

The renderer targets 500ms per update. Performance budgets are enforced by automated benchmarks in CI.

---

## 21.8 Engineering Rationale

Performance is an architecture property. Every design decision — from database indexing to layer caching — is evaluated against performance budgets.

*Chapter 21 complete.*
