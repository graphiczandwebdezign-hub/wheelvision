# RUNBOOK: OPERATIONAL PROCEDURES AND INCIDENT RESPONSE

## R.1 Deployment Runbook

### R.1.1 Pre-Deployment Checklist

- [ ] All automated tests pass (unit, integration, security, performance)
- [ ] TypeScript strict mode passes (`tsc --noEmit`)
- [ ] ESLint and Prettier checks pass
- [ ] Database migrations have `down` scripts
- [ ] Environment variables verified in Vercel dashboard
- [ ] Feature flags for new features set to `false` (canary deployment)

### R.1.2 Deployment Command Sequence

```bash
git checkout main
git pull origin main
git checkout -b release/v{version}
# ... commit changes ...
git push origin release/v{version}
# Create Pull Request
# After review and CI pass:
git checkout main
git merge --no-ff release/v{version}
git push origin main
# Vercel deploys automatically
```

---

## R.2 Incident Response Protocol

### R.2.1 Severity Levels

| Severity | Definition | Response Time | Escalation |
|---|---|---|---|
| SEV-1 | Complete platform outage; data loss; security breach | 5 minutes | CTO, Security Lead |
| SEV-2 | Major feature failure; multi-tenant impact | 15 minutes | Engineering Lead |
| SEV-3 | Single tenant issue; performance degradation | 1 hour | On-call Engineer |
| SEV-4 | Minor bug; cosmetic issue | 24 hours | Scheduled fix |

### R.2.2 Incident Response Steps

1. **Detect:** Monitoring alerts trigger (Sentry, Vercel Analytics, custom health checks).
2. **Assess:** Determine severity using criteria above.
3. **Communicate:** Post status to status page; notify affected tenants if SEV-1 or SEV-2.
4. **Mitigate:** Apply temporary fix (feature flag disable, rollback to previous version).
5. **Resolve:** Deploy permanent fix through standard CI/CD pipeline.
6. **Post-Mortem:** Document root cause, timeline, and prevention measures within 48 hours.

---

## R.3 Rollback Procedure

### R.3.1 Immediate Rollback (Vercel)

In Vercel dashboard: Select previous deployment → Click "Promote to Production". Rollback completes within 30 seconds.

### R.3.2 Database Rollback

If a destructive migration was applied:
```sql
-- Execute down script
\i migrations/down/YYYYMMDD_description.sql
```
Rollback must be tested in staging before production execution.

---

## R.4 Monitoring and Alerting Protocol

### R.4.1 Metrics Collected

- Request latency (p50, p95, p99)
- Error rate (per endpoint)
- Database query duration (per query pattern)
- Rendering time (per scene update)
- Memory usage (per server instance)
- Asset download failure rate
- Quotation generation failure rate

### R.4.2 Alert Thresholds

- **Latency p95 > 500ms:** Warning alert
- **Latency p99 > 1,000ms:** Critical alert
- **Error rate > 1% for 5 minutes:** Warning alert
- **Error rate > 5% for 2 minutes:** Critical alert
- **Memory usage > 80% for 10 minutes:** Warning alert

---

## R.5 Engineering Rationale (Operational)

Operational procedures eliminate ambiguity during emergency situations. Every engineer knows exactly what steps to take, in what order, with what authority. The severity levels prevent overreaction to minor issues while ensuring rapid response to critical failures. The rollback procedures are tested and verified.
