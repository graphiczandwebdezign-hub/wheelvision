# AI PIPELINE ENGINEERING SPECIFICATION

## 1. Purpose

Defines model lifecycle, confidence thresholds, human review workflows, versioning, and automated publishing for the AI asset pipeline.

---

## 2. Model Lifecycle

| Stage | Action | Entry Criteria | Exit Criteria |
|---|---|---|---|
| Ingest | Raw image upload | File validated | Asset stored in staging |
| Segmentation | Background removal | Image in staging | Mask generated |
| Detection | Wheel region identification | Mask available | Bounding box + circle mask |
| Metadata Gen | JSON proposal | Detection complete | Metadata JSON draft |
| Validation | Schema + logic check | JSON draft | Passes all rules |
| Human Review | Admin approval/rejection | Validation passed | Published or rejected |
| Publishing | Copy to production | Approved | Live asset |

---

## 3. Confidence Thresholds

Every AI stage produces a confidence score (0.0–1.0). Thresholds:
- Background removal: >= 0.92
- Wheel detection: >= 0.88
- Metadata coordinate proposal: >= 0.85

Any score below threshold triggers automatic human review queue (no automatic publish).

---

## 4. Human Review Workflow

Admin interface (`/admin/review`) displays AI-proposed assets with side-by-side comparison: original vs processed. Admin actions: Approve (publish), Reject (delete from staging), Edit (modify metadata manually then approve). Review decisions are audited (`review_log` table) with admin ID, timestamp, and action.

---

## 5. Versioning

Every AI model version is tracked (`ai_model_versions` table): version number, training dataset hash, deployment timestamp, performance metrics on validation set. Rollback to previous model version is supported via feature flag (`use_ai_version` in tenant settings).

---

## 6. Publishing Gates

Automatic publishing is only permitted when ALL confidence thresholds are met AND no validation errors exist. Otherwise, asset remains in `pending_review` status until human approval.

---

## 7. Engineering Rationale

AI accelerates asset onboarding but does not replace quality assurance. Confidence thresholds prevent low-quality outputs from reaching production. Version control ensures model changes are traceable and reversible. Human review provides final quality gate.
