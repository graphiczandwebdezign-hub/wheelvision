# OPERATIONAL EXCELLENCE SPECIFICATION

## 1. Purpose

Defines observability, metrics, tracing, SLOs, incident response, and disaster recovery for production operations.

---

## 2. Observability Architecture

```mermaid
graph TD
    A[Application] --> B[Sentry - Errors]
    A --> C[Vercel Analytics - Requests]
    D[PostgreSQL] --> E[Supabase Metrics - DB]
    A --> F[Custom Metrics - Rendering Time]
    F --> G[Dashboard - Grafana/Custom]
```

---

## 3. Metrics and SLOs

| SLO | Target | Measurement Window | Alert Threshold |
|---|---|---|---|
| Availability | 99.95% | Monthly | < 99.9% |
| Request Latency p95 | < 200ms | 5 minutes | > 300ms |
| Rendering Time p99 | < 1,000ms | 5 minutes | > 1,500ms |
| Quotation Success Rate | > 99.9% | Hourly | < 99.5% |

---

## 4. Logging Protocol

Every request includes correlation ID (`X-Request-ID`). Logs structured in JSON with fields: `timestamp`, `level`, `service`, `message`, `correlation_id`, `tenant_id`, `user_id`. Logs retained for 90 days in hot storage; 7 years in cold archive.

---

## 5. Tracing

Distributed tracing via OpenTelemetry. Every API request, database query, and rendering cycle produces a trace span. Parent-child relationships maintained across service boundaries.

---

## 6. Incident Response (Expanded)

SEV-1 (Outage): 5-minute response, CTO notified automatically. SEV-2 (Major feature failure): 15-minute response. SEV-3 (Single tenant): 1-hour response. SEV-4 (Cosmetic): 24-hour scheduled fix.

---

## 7. Disaster Recovery

RPO (Recovery Point Objective): 15 minutes (continuous WAL archiving). RTO (Recovery Time Objective): 30 minutes (automated database restore + redeploy to backup region). Monthly DR drills executed; results logged.

---

## 8. Engineering Rationale

Operational excellence is engineered, not improvised. SLOs are quantitative contracts. Tracing provides root-cause visibility. Incident response timelines prevent ambiguity during emergencies.
