# ENTERPRISE BILLING & SUBSCRIPTION ARCHITECTURE

## 1. Purpose

Defines subscription plans, entitlements, metering, invoicing, lifecycle, and multi-currency support.

---

## 2. Subscription Plans

| Plan | Monthly Price (ZAR) | Dealers | Quotes/Month | Inventory SKUs | White Label |
|---|---|---|---|---|---|
| Free | 0 | 1 | 50 | 10 | No |
| Basic | 499 | 1 | 500 | 100 | No |
| Professional | 1,499 | 5 | 5,000 | 1,000 | Partial |
| Enterprise | 4,999+ | Unlimited | Unlimited | Unlimited | Full |

---

## 3. Entitlements and Feature Flags

Every feature is protected by an entitlement check against the tenant's subscription tier. Feature flags (`feature_flags` JSON) are evaluated at middleware level before rendering protected UI or allowing API access.

---

## 4. Usage Metering

Usage metrics (quotes generated, assets uploaded, API calls) are tracked per tenant in the `usage_metrics` table. Metering runs hourly via scheduled job. Overages trigger automated email notifications and optional throttling (not blocking) for Professional/Enterprise tiers.

---

## 5. Invoicing Lifecycle

Invoices generated monthly via integration with billing provider (Stripe recommended). Invoice items derived from `subscription_tier` + overage calculations. PDF invoices stored in R2; email delivery via SMTP integration (Chapter 14 protocol). Failed payments trigger dunning sequence: Day 3 (reminder), Day 7 (warning), Day 14 (service suspension warning), Day 21 (suspension — data retained but access blocked until payment resolved).

---

## 6. Multi-Currency

Primary currency: ZAR (South Africa, user location: Durban). Secondary currencies supported: USD, EUR, GBP. Currency conversion rates fetched from external API (e.g., Open Exchange Rates) and cached for 24 hours. All transactions stored in primary currency with conversion rate at time of transaction.

---

## 7. Engineering Rationale

Subscription architecture separates commercial logic from application logic. Entitlements enforce tier restrictions at the database and middleware levels. Metering provides data for billing and capacity planning. Multi-currency support prepares for international dealer networks.
