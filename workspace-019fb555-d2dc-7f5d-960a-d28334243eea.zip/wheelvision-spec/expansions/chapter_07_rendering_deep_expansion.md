# CHAPTER 7 — EXPANSION: RENDERING ENGINE DEEP ARCHITECTURE

## 7.EXP.1 Shader Pipeline Concept (Future-Proof)

Even though the current engine uses Konva (2D canvas), the layer abstraction is designed to support future WebGL shader pipelines. Each layer maps to a shader program:

- **Vehicle Shader:** Texture sampling from WebP source, alpha masking from mask texture.
- **Wheel Shader:** Circular mask using fragment shader distance calculation (`discard` if distance > radius).
- **Shadow Shader:** Blend mode `multiply` with opacity uniform.
- **Overlay Shader:** Text rendering via signed-distance field fonts.

This abstraction ensures that migrating to Three.js requires only shader program replacement, not scene graph restructuring.

---

## 7.EXP.2 Memory Management Protocol

Every Konva layer implements a `dispose()` method:

```typescript
function disposeLayer(node: Konva.Layer): void {
    node.destroy();
    node.destroyChildren();
    if (node.cache) {
        node.cache.clear();
    }
}
```

Memory profiling is required in development. Heap snapshots must be captured before and after scene updates. Memory leaks (growing heap without release) block deployment.

---

## 7.EXP.3 Performance Monitoring Integration

The renderer reports metrics to the application layer:
- `render_start_time`
- `render_end_time`
- `layer_count`
- `image_load_duration`
- `memory_usage_before_bytes`
- `memory_usage_after_bytes`

These metrics are sent to the analytics endpoint for performance budget verification.
