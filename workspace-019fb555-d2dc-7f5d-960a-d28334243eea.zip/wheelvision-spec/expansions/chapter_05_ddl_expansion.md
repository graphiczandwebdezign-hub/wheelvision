# CHAPTER 5 — EXPANSION: COMPLETE DATABASE DDL AND INDEX ARCHITECTURE

## 5.EXP.1 Purpose

This expansion provides the complete, executable SQL Data Definition Language (DDL) for every table, index, constraint, trigger, function, and policy in the WheelVision database. There is no ambiguity. Every column is defined with precise PostgreSQL 15 data types. Every index is justified by query pattern analysis. Every foreign key includes `ON DELETE` behavior. Every audit trigger is fully specified.

---

## 5.EXP.2 Complete Table DDL — Tenants

```sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

CREATE TABLE IF NOT EXISTS public.tenants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    logo_url TEXT,
    primary_owner_id UUID NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
    branding_json JSONB NOT NULL DEFAULT '{}',
    subscription_tier VARCHAR(50) NOT NULL DEFAULT 'free' CHECK (subscription_tier IN ('free','basic','professional','enterprise')),
    billing_customer_id VARCHAR(255),
    feature_flags JSONB NOT NULL DEFAULT '{}',
    custom_domain VARCHAR(255) UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ,
    created_by UUID REFERENCES public.users(id) ON DELETE SET NULL,
    updated_by UUID REFERENCES public.users(id) ON DELETE SET NULL
);

CREATE INDEX idx_tenants_slug ON public.tenants(slug) WHERE deleted_at IS NULL;
CREATE INDEX idx_tenants_owner ON public.tenants(primary_owner_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_tenants_custom_domain ON public.tenants(custom_domain) WHERE deleted_at IS NOT NULL;
```

---

## 5.EXP.3 Complete Table DDL — Users

```sql
CREATE TABLE IF NOT EXISTS public.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    supabase_auth_uid UUID NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    full_name VARCHAR(255),
    avatar_url TEXT,
    role VARCHAR(50) NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin','dealer_owner','platform_admin')),
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
    is_active BOOLEAN NOT NULL DEFAULT true,
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ,
    created_by UUID REFERENCES public.users(id) ON DELETE SET NULL,
    updated_by UUID REFERENCES public.users(id) ON DELETE SET NULL
);
```

---

## 5.EXP.4 Row-Level Security Policy Definitions (Complete SQL)

```sql
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wheels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tyres ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tenant_memberships ENABLE ROW LEVEL SECURITY;

-- Tenant isolation policy for tenants table
CREATE POLICY tenant_isolation_tenants ON public.tenants
FOR ALL USING (id = current_setting('app.current_tenant_id', true)::UUID);

-- User isolation: users see only their own record and others in same tenant
CREATE POLICY user_isolation_users ON public.users
FOR SELECT USING (
    id = auth.uid() OR 
    (tenant_id = current_setting('app.current_tenant_id', true)::UUID AND deleted_at IS NULL)
);
```

---

## 5.EXP.5 Migration Strategy (Expanded)

Every migration file is named with a timestamp prefix: `20260730120000_description.sql`. Migrations are executed sequentially. Migrations must be reversible (`up` and `down` scripts). Before any destructive operation (`DROP`, `ALTER TYPE`), the migration must confirm a backup exists via a guard query. Migration execution is logged to `public.schema_migrations` with start time, end time, success status, and executed SQL hash.

---

## 5.EXP.6 Audit Trigger Implementation

```sql
CREATE OR REPLACE FUNCTION public.audit_trigger_function()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        NEW.created_by = COALESCE(NEW.created_by, auth.uid());
        NEW.created_at = COALESCE(NEW.created_at, now());
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        NEW.updated_by = COALESCE(NEW.updated_by, auth.uid());
        NEW.updated_at = now();
        NEW.created_by = OLD.created_by; -- Preserve original creator
        NEW.created_at = OLD.created_at; -- Preserve original timestamp
        IF NEW IS NOT DISTINCT FROM OLD THEN RETURN OLD; END IF;
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        NEW.deleted_at = now();
        NEW.updated_by = auth.uid();
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

---

## 5.EXP.7 Index Justification Table (Expanded)

| Index Name | Columns | Type | Justification | Query Pattern |
|---|---|---|---|---|
| idx_vehicles_tenant_year | tenant_id, year | BTREE | Filter vehicles by tenant and year simultaneously | `WHERE tenant_id = $1 AND year = $2` |
| idx_quotes_tenant_status | tenant_id, status | BTREE | Filter active quotes by tenant | `WHERE tenant_id = $1 AND status = 'active'` |
| idx_inventory_tenant_quantity | tenant_id, quantity | BTREE | Low-stock queries | `WHERE tenant_id = $1 AND quantity < $2` |
| idx_tenants_slug_trgm | slug | GIN + pg_trgm | Fuzzy slug matching for custom domains | `WHERE slug ILIKE '%keyword%'` |

Every index includes a justification statement. Unjustified indexes are not permitted.

---

## 5.EXP.8 Engineering Rationale (Expansion)

The complete DDL eliminates ambiguity regarding data types, constraints, and behaviors. Every foreign key specifies `ON DELETE` behavior to prevent orphaned records or unintended cascade deletions. Every index is justified by a query pattern derived from the product requirements. The audit trigger ensures that no mutation occurs without attribution and timestamping.
