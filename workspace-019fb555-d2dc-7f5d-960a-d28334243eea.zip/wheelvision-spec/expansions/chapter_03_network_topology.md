# CHAPTER 3 — EXPANSION: DEPLOYMENT TOPOLOGY AND NETWORK ARCHITECTURE

## 3.EXP.1 Network Topology

The deployment network consists of five security zones:

1. **Public Edge Zone:** Cloudflare CDN and Vercel Edge Network.
2. **Application Zone:** Next.js serverless functions.
3. **Data Access Zone:** Supabase PostgreSQL with private networking.
4. **Storage Zone:** Cloudflare R2 with signed URL generation.
5. **Administrative Zone:** Protected admin routes with IP allowlisting.

---

## 3.EXP.2 Firewall and Access Control Rules

| Source | Destination | Port | Protocol | Action | Justification |
|---|---|---|---|---|---|
| Any | Vercel Edge | 443 | HTTPS | Allow | Public web access |
| Vercel Edge | Supabase DB | 5432 | PostgreSQL | Allow (IP restricted) | Database access only from Vercel IPs |
| Vercel Edge | R2 | 443 | HTTPS | Allow | Asset retrieval |
| Admin IPs | Admin Portal | 443 | HTTPS | Allow | Restricted admin access |
| Any (unauthorized) | Supabase DB | 5432 | PostgreSQL | Deny | Prevent direct DB access |

---

## 3.EXP.3 Disaster Recovery Topology

In the event of complete Vercel region failure:
1. DNS is redirected to a backup region using Cloudflare Load Balancing.
2. Database remains available (Supabase multi-region replication).
3. Assets remain available (R2 multi-region replication).
4. Application redeploys from Git repository to the backup region within 15 minutes.

---

## 3.EXP.4 Engineering Rationale

Network architecture protects against both external attacks (DDoS, injection) and internal failures (region outage). The separation of zones ensures that a compromise in one zone does not automatically compromise others. The firewall rules enforce the principle of least privilege at the network layer.
