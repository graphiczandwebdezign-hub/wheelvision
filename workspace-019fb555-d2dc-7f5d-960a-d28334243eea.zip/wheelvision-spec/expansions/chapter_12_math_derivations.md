# CHAPTER 12 — EXPANSION: MATHEMATICAL DERIVATIONS AND PROOFS

## 12.EXP.1 Scaling Formula Derivation

Given:
- Native wheel image width: `W_native` (pixels)
- Native wheel image height: `H_native` (pixels)
- Reference diameter: `D_ref` (pixels) — the diameter of the wheel as defined in metadata
- Selected wheel diameter: `D_sel` (pixels) — derived from user selection (e.g., 18 inches converted to pixel scale)

The scale factor `S` is defined as the ratio of selected diameter to reference diameter:

`S = D_sel / D_ref`

This preserves aspect ratio because:
`W_scaled = W_native × S`
`H_scaled = H_native × S`
`W_scaled / H_scaled = W_native / H_native`

Therefore, aspect ratio is invariant under uniform scaling.

---

## 12.EXP.2 Tyre Diameter Derivation

Given standard tyre notation: `Width / Profile R Diameter`

Where:
- `Width` = section width in millimeters (e.g., 265)
- `Profile` = aspect ratio as percentage (e.g., 65 means 65%)
- `Diameter` = rim diameter in inches (e.g., 18)

Sidewall height (`H_sidewall`) = `(Width × Profile) / 100` (in millimeters)

Total tyre outer diameter (`D_total`) = `(H_sidewall × 2) + (Diameter × 25.4)` (in millimeters)

Proof: The tyre forms a circle around the rim. The radius of the rim is `Diameter × 25.4 / 2`. The sidewall extends outward by `H_sidewall` on both sides. Therefore, total diameter = rim diameter + 2 × sidewall height.

---

## 12.EXP.3 Perspective Simulation Mathematics

Perspective is simulated through non-uniform vertical displacement and scale differentials.

Given:
- Front wheel scale: `S_front`
- Rear wheel scale: `S_rear = S_front × 0.92`
- Front wheel y-coordinate: `Y_front`
- Rear wheel y-coordinate: `Y_rear = Y_front + 10` (pixels lower to simulate perspective depth)

The perspective angle `θ` (approximate) can be derived from scale differential:
`cos(θ) ≈ S_rear / S_front = 0.92`
`θ ≈ arccos(0.92) ≈ 23.1°`

This provides a consistent perspective approximation without full 3D projection.

---

## 12.EXP.4 Export Resolution Mathematics

Given:
- Target DPI: `300`
- Base resolution (pixels): `W_base × H_base`
- Scale factor for export: `S_export = 300 / 72` (since base canvas resolution is 72 DPI equivalent)

Export dimensions:
`W_export = W_base × S_export`
`H_export = H_base × S_export`

Image assets must be resampled at this resolution. The Konva renderer creates a temporary stage at `W_export × H_export` and re-renders with the same transformation matrix scaled by `S_export`.

---

## 12.EXP.5 Engineering Rationale (Mathematics)

Every formula is derived from first principles rather than approximated. The derivations ensure that any engineer or AI agent can verify the mathematical correctness of the rendering output. The perspective simulation provides a consistent approximation that aligns with commercial visual expectations.
