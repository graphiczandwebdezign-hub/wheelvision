# CHAPTER 0 — SYSTEM PHILOSOPHY AND DESIGN PRINCIPLES (EXPANDED)

## 0.1 The Philosophy of Metadata-First Architecture

In conventional software engineering, the code is the product. In WheelVision, the data is the product. The renderer is not a program that understands vehicles; it is a universal interpreter of structured descriptions. This inversion has profound implications.

When a new Toyota Hilux is added, no developer opens an IDE. No pull request is created. No deployment is triggered. Instead, an administrator uploads images, writes JSON, and publishes. The platform expands not through engineering labor but through data accumulation. This is the fundamental economic advantage: linear cost of data creation versus exponential cost of feature development.

Every engineering decision in this specification supports this inversion. The database schema does not model vehicles as special cases; it treats them as rows in a generic `vehicles` table with JSON metadata. The renderer does not branch on manufacturer; it reads coordinate objects. The API does not define endpoints per model; it serves universal resource paths.

---

## 0.2 The Principle of Mathematical Certainty

Visual approximation is unacceptable in commercial quotation contexts. If a dealer presents a quotation to a customer, and the rendered wheel does not match the physical dimensions of the selected product, the platform has failed its commercial purpose. Therefore, every visual parameter must be derived from mathematical operations on input values.

The scaling pipeline is not approximate; it is exact: `scale_factor = selected_diameter / reference_diameter`. The coordinate system is not estimated; it is absolute pixel space. The rotation is not artistic; it is angular displacement in degrees. Every transformation is reversible and verifiable.

---

## 0.3 The Principle of Zero Trust Isolation

Multi-tenant isolation is not a feature; it is a mathematical guarantee enforced by PostgreSQL's row-level security mechanism. Every query operates within a constrained context. Every middleware layer validates tenant identity. Every application layer filters by tenant identifier. The defense does not rely on a single mechanism; it relies on overlapping, independent mechanisms that must all fail simultaneously for isolation to break. This is defense in depth.

---

## 0.4 The Principle of Production-Ready by Default

No feature is complete until it includes error handling, validation, audit logging, rollback capability, performance verification, and documentation. A quotation that saves but does not generate a PDF is incomplete. A renderer that renders but does not handle missing assets is incomplete. A database table that stores data but lacks RLS is incomplete. The definition of done requires all of these properties.

---

## 0.5 Engineering Rationale (Expanded)

The four principles above govern every chapter of this specification. When evaluating any design option, we ask: Does it support metadata-first architecture? Does it enforce mathematical certainty? Does it strengthen zero-trust isolation? Does it maintain production-ready completeness? Any option that fails one or more of these criteria is rejected.

This is not preference. This is engineering discipline.
